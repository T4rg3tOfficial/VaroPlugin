/*    */ package de.cuuky.varo.listener.saveable;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.VaroSaveable;
/*    */ import de.cuuky.varo.version.types.Sounds;
/*    */ import org.bukkit.Effect;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.BlockBreakEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockBreakListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onBlockBreak(BlockBreakEvent event) {
/* 24 */     if (!Main.getVaroGame().hasStarted() && event.getPlayer().getGameMode() != GameMode.CREATIVE) {
/* 25 */       event.setCancelled(true);
/*    */       
/*    */       return;
/*    */     } 
/* 29 */     Player player = event.getPlayer();
/* 30 */     VaroPlayer varoPlayer = VaroPlayer.getPlayer(player);
/* 31 */     Block block = event.getBlock();
/*    */     
/* 33 */     if (!(block.getState() instanceof org.bukkit.block.Chest) && !(block.getState() instanceof org.bukkit.block.Furnace)) {
/*    */       return;
/*    */     }
/* 36 */     if (!Main.getVaroGame().hasStarted() && (
/* 37 */       varoPlayer.getStats().isSpectator() || !player.hasPermission("varo.setup"))) {
/*    */       return;
/*    */     }
/* 40 */     Location loc = block.getLocation();
/* 41 */     VaroSaveable saveable = VaroSaveable.getByLocation(loc);
/*    */     
/* 43 */     if (saveable == null)
/*    */       return; 
/* 45 */     VaroPlayer holder = saveable.getPlayer();
/*    */     
/* 47 */     if (saveable.canModify(varoPlayer)) {
/* 48 */       player.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.CHEST_REMOVED_SAVEABLE.getValue().replace("%saveable%", (block.getState() instanceof org.bukkit.block.Chest) ? "Chest" : "Furnace"));
/* 49 */       player.playSound(player.getLocation(), Sounds.NOTE_BASS_DRUM.bukkitSound(), 1.0F, 1.0F);
/* 50 */       player.getWorld().playEffect(block.getLocation(), Effect.SMOKE, 1);
/* 51 */       player.getWorld().playEffect(block.getLocation(), Effect.SMOKE, 1);
/* 52 */       player.getWorld().playEffect(block.getLocation(), Effect.SMOKE, 1);
/* 53 */       saveable.remove();
/*    */       
/*    */       return;
/*    */     } 
/* 57 */     if (saveable.holderDead()) {
/*    */       return;
/*    */     }
/* 60 */     if (!player.hasPermission("varo.ignoreSaveable")) {
/* 61 */       player.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.CHEST_NOT_TEAM_CHEST.getValue().replace("%player%", holder.getName()));
/* 62 */       event.setCancelled(true);
/*    */     } else {
/* 64 */       player.sendMessage(String.valueOf(Main.getPrefix()) + "§7Diese Kiste gehoerte " + Main.getColorCode() + saveable.getPlayer().getName() + "§7 aber da du Rechte hast, konntest du sie dennoch zerstoeren!");
/* 65 */       saveable.remove();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\saveable\BlockBreakListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */