/*    */ package de.cuuky.varo.listener.saveable;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.VaroSaveable;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerInteractListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onPlayerInteract(PlayerInteractEvent e) {
/* 23 */     if (!Main.getVaroGame().hasStarted()) {
/*    */       return;
/*    */     }
/* 26 */     if (!Main.getVaroGame().hasStarted() && e.getPlayer().getGameMode() != GameMode.CREATIVE) {
/* 27 */       e.setCancelled(true);
/*    */       
/*    */       return;
/*    */     } 
/* 31 */     if (e.getAction() != Action.RIGHT_CLICK_BLOCK) {
/*    */       return;
/*    */     }
/* 34 */     Player player = e.getPlayer();
/* 35 */     Block block = e.getClickedBlock();
/*    */     
/* 37 */     if (!(block.getState() instanceof org.bukkit.block.Chest) && !(block.getState() instanceof org.bukkit.block.Furnace)) {
/*    */       return;
/*    */     }
/* 40 */     VaroPlayer varoPlayer = VaroPlayer.getPlayer(player);
/* 41 */     VaroSaveable saveable = VaroSaveable.getByLocation(block.getLocation());
/*    */     
/* 43 */     if (saveable == null || saveable.canModify(varoPlayer) || saveable.holderDead()) {
/*    */       return;
/*    */     }
/* 46 */     if (!player.hasPermission("varo.ignoreSaveable")) {
/* 47 */       player.sendMessage(String.valueOf(Main.getPrefix()) + ((saveable.getType() == VaroSaveable.SaveableType.CHEST) ? ConfigMessages.CHEST_NOT_TEAM_CHEST.getValue().replace("%player%", saveable.getPlayer().getName()) : ConfigMessages.CHEST_NOT_TEAM_FURNACE.getValue().replace("%player%", saveable.getPlayer().getName())));
/* 48 */       e.setCancelled(true);
/*    */     } else {
/* 50 */       player.sendMessage(String.valueOf(Main.getPrefix()) + "§7Diese Kiste gehoert " + Main.getColorCode() + saveable.getPlayer().getName() + "§7, doch durch deine Rechte konntest du sie trotzdem oeffnen!");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\saveable\PlayerInteractListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */