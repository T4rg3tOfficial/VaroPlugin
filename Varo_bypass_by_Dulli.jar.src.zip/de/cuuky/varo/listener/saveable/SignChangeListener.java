/*     */ package de.cuuky.varo.listener.saveable;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.stat.inventory.VaroSaveable;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import de.cuuky.varo.version.types.Sounds;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Effect;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.Chest;
/*     */ import org.bukkit.block.DoubleChest;
/*     */ import org.bukkit.block.Furnace;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.SignChangeEvent;
/*     */ import org.bukkit.inventory.InventoryHolder;
/*     */ import org.bukkit.material.Sign;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignChangeListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onSignChange(SignChangeEvent e) {
/*  30 */     Sign sign = (Sign)e.getBlock().getState().getData();
/*  31 */     if (e.getPlayer().isOp())
/*  32 */       for (int i = 0; i < (e.getLines()).length; i++) {
/*  33 */         e.setLine(i, e.getLines()[i].replace("&", "§"));
/*     */       } 
/*  35 */     if (e.getBlock().getType() != Materials.SIGN.parseMaterial() && e.getBlock().getType() != Materials.WALL_SIGN.parseMaterial()) {
/*     */       return;
/*     */     }
/*  38 */     if (!Main.getVaroGame().hasStarted()) {
/*     */       return;
/*     */     }
/*  41 */     Block attached = e.getBlock().getRelative(sign.getAttachedFace());
/*     */     
/*  43 */     if (attached.getState() instanceof Chest) {
/*  44 */       Chest chest = (Chest)attached.getState();
/*  45 */       InventoryHolder ih = chest.getInventory().getHolder();
/*  46 */       Chest secChest = (ih instanceof DoubleChest) ? (Chest)((DoubleChest)ih).getLeftSide() : null;
/*  47 */       if (chest.equals(secChest) && secChest != null) {
/*  48 */         secChest = (Chest)((DoubleChest)ih).getRightSide();
/*     */       }
/*  50 */       if (ConfigSetting.PLAYER_CHEST_LIMIT.getValueAsInt() == 0) {
/*  51 */         e.getPlayer().sendMessage(String.valueOf(Main.getPrefix()) + "§7Die Chestsicherung wurde in der Config §7deaktiviert!");
/*     */         
/*     */         return;
/*     */       } 
/*  55 */       Player p = e.getPlayer();
/*  56 */       VaroPlayer player = VaroPlayer.getPlayer(p);
/*  57 */       ArrayList<VaroSaveable> teamSaves = VaroSaveable.getSaveable(player);
/*  58 */       ArrayList<VaroSaveable> sorted = new ArrayList<>();
/*     */       
/*  60 */       for (VaroSaveable saves : teamSaves) {
/*  61 */         if (saves.getType() == VaroSaveable.SaveableType.CHEST) {
/*  62 */           sorted.add(saves);
/*     */         }
/*     */       } 
/*     */       
/*  66 */       if (sorted.size() >= ConfigSetting.PLAYER_CHEST_LIMIT.getValueAsInt() || (secChest != null && sorted.size() + 1 >= ConfigSetting.PLAYER_CHEST_LIMIT.getValueAsInt())) {
/*  67 */         p.sendMessage(String.valueOf(Main.getPrefix()) + "§7Die maximale Anzahl an gesetzten Kisten fuer das Team " + Main.getColorCode() + player.getTeam().getName() + " §7wurde bereits §7erreicht! (Anzahl: §6" + sorted.size() + " §7Max: §6" + ConfigSetting.PLAYER_CHEST_LIMIT.getValueAsInt() + "§7)");
/*  68 */         e.setCancelled(true);
/*     */         
/*     */         return;
/*     */       } 
/*  72 */       if (VaroSaveable.getByLocation(chest.getLocation()) != null || (secChest != null && VaroSaveable.getByLocation(secChest.getLocation()) != null)) {
/*  73 */         p.sendMessage(String.valueOf(Main.getPrefix()) + "§7Diese " + Main.getColorCode() + " Kiste §7ist bereits gesichert!");
/*  74 */         e.setCancelled(true);
/*     */         
/*     */         return;
/*     */       } 
/*  78 */       if (secChest != null);
/*     */ 
/*     */       
/*  81 */       e.setLine(0, "§8--------------");
/*  82 */       e.setLine(1, "§lSavedChest");
/*  83 */       e.setLine(2, String.valueOf(Main.getColorCode()) + ((player.getTeam() != null) ? player.getTeam().getDisplay() : player.getName()));
/*  84 */       e.setLine(3, "§8--------------");
/*  85 */       p.playSound(p.getLocation(), Sounds.NOTE_PLING.bukkitSound(), 1.0F, 1.0F);
/*  86 */       p.getWorld().playEffect(chest.getLocation(), Effect.ENDER_SIGNAL, 1);
/*  87 */       p.getWorld().playEffect(chest.getLocation(), Effect.ENDER_SIGNAL, 1);
/*  88 */       p.getWorld().playEffect(chest.getLocation(), Effect.ENDER_SIGNAL, 1);
/*  89 */       p.getWorld().playEffect(chest.getLocation(), Effect.ENDER_SIGNAL, 1);
/*  90 */       p.getWorld().playEffect(chest.getLocation(), Effect.ENDER_SIGNAL, 1);
/*  91 */       p.getWorld().playEffect(chest.getLocation(), Effect.ENDER_SIGNAL, 1);
/*     */ 
/*     */       
/*  94 */       p.sendMessage(String.valueOf(Main.getPrefix()) + "Kiste erfolgreich gesichert!");
/*  95 */     } else if (attached.getState() instanceof Furnace) {
/*  96 */       Furnace furnace = (Furnace)attached.getState();
/*     */       
/*  98 */       if (ConfigSetting.PLAYER_FURNACE_LIMIT.getValueAsInt() == 0) {
/*  99 */         e.getPlayer().sendMessage(String.valueOf(Main.getPrefix()) + "§7Die Furnacesicherung wurde in der Config §7deaktiviert!");
/*     */         
/*     */         return;
/*     */       } 
/* 103 */       Player p = e.getPlayer();
/* 104 */       VaroPlayer player = VaroPlayer.getPlayer(p);
/*     */       
/* 106 */       ArrayList<VaroSaveable> teamSaves = VaroSaveable.getSaveable(player);
/* 107 */       ArrayList<VaroSaveable> sorted = new ArrayList<>();
/*     */       
/* 109 */       for (VaroSaveable saves : teamSaves) {
/* 110 */         if (saves.getType() == VaroSaveable.SaveableType.FURNANCE) {
/* 111 */           sorted.add(saves);
/*     */         }
/*     */       } 
/*     */       
/* 115 */       if (VaroSaveable.getByLocation(furnace.getLocation()) != null) {
/* 116 */         p.sendMessage(String.valueOf(Main.getPrefix()) + "§7Diese " + Main.getColorCode() + " Furnace §7ist bereits gesichert!");
/* 117 */         e.setCancelled(true);
/*     */         
/*     */         return;
/*     */       } 
/* 121 */       if (ConfigSetting.PLAYER_FURNACE_LIMIT.isIntActivated() && 
/* 122 */         sorted.size() >= ConfigSetting.PLAYER_FURNACE_LIMIT.getValueAsInt()) {
/* 123 */         p.sendMessage(String.valueOf(Main.getPrefix()) + "§7Die maximale Anzahl an gesetzten Furnaces fuer das Team " + Main.getProjectName() + " " + player.getTeam().getDisplay() + " §7wurde bereits §7erreicht! (Anzahl: §6" + sorted.size() + " §7Max: §6" + ConfigSetting.PLAYER_FURNACE_LIMIT.getValueAsInt() + "§7)");
/* 124 */         e.setCancelled(true);
/*     */         
/*     */         return;
/*     */       } 
/* 128 */       e.setLine(0, "§8--------------");
/* 129 */       e.setLine(1, "§lSavedFurnace");
/* 130 */       e.setLine(2, String.valueOf(Main.getColorCode()) + ((player.getTeam() != null) ? player.getTeam().getDisplay() : player.getName()));
/* 131 */       e.setLine(3, "§8--------------");
/* 132 */       p.playSound(furnace.getLocation(), Sounds.NOTE_PLING.bukkitSound(), 1.0F, 1.0F);
/* 133 */       p.getWorld().playEffect(furnace.getLocation(), Effect.ENDER_SIGNAL, 1);
/* 134 */       p.getWorld().playEffect(furnace.getLocation(), Effect.ENDER_SIGNAL, 1);
/* 135 */       p.getWorld().playEffect(furnace.getLocation(), Effect.ENDER_SIGNAL, 1);
/* 136 */       p.getWorld().playEffect(furnace.getLocation(), Effect.ENDER_SIGNAL, 1);
/* 137 */       p.getWorld().playEffect(furnace.getLocation(), Effect.ENDER_SIGNAL, 1);
/* 138 */       p.getWorld().playEffect(furnace.getLocation(), Effect.ENDER_SIGNAL, 1);
/*     */       
/* 140 */       p.sendMessage(String.valueOf(Main.getPrefix()) + "Ofen erfolgreich gesichert!");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\saveable\SignChangeListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */