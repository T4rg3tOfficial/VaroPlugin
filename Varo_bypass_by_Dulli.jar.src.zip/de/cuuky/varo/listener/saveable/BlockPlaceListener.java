/*    */ package de.cuuky.varo.listener.saveable;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.VaroSaveable;
/*    */ import de.cuuky.varo.version.types.Sounds;
/*    */ import org.bukkit.Effect;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.block.Chest;
/*    */ import org.bukkit.block.DoubleChest;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.BlockPlaceEvent;
/*    */ import org.bukkit.inventory.InventoryHolder;
/*    */ 
/*    */ 
/*    */ public class BlockPlaceListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void onBlockPlace(BlockPlaceEvent e) {
/* 25 */     if (!Main.getVaroGame().hasStarted()) {
/*    */       return;
/*    */     }
/* 28 */     Block placed = e.getBlock();
/*    */     
/* 30 */     if (!(placed.getState() instanceof Chest)) {
/*    */       return;
/*    */     }
/* 33 */     Chest chest = (Chest)placed.getState();
/* 34 */     InventoryHolder ih = chest.getInventory().getHolder();
/*    */     
/* 36 */     if (!(ih instanceof DoubleChest)) {
/*    */       return;
/*    */     }
/* 39 */     Chest secChest = (Chest)((DoubleChest)ih).getLeftSide();
/*    */     
/* 41 */     if (chest.equals(secChest) && secChest != null) {
/* 42 */       secChest = (Chest)((DoubleChest)ih).getRightSide();
/*    */     }
/* 44 */     VaroSaveable saveable = VaroSaveable.getByLocation(secChest.getLocation());
/* 45 */     if (saveable == null || saveable.holderDead()) {
/*    */       return;
/*    */     }
/* 48 */     Player p = e.getPlayer();
/* 49 */     VaroPlayer player = VaroPlayer.getPlayer(p);
/*    */     
/* 51 */     if (saveable.canModify(player)) {
/*    */       
/* 53 */       player.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.CHEST_SAVED_SAVEABLE.getValue(player));
/* 54 */       p.playSound(p.getLocation(), Sounds.NOTE_PLING.bukkitSound(), 1.0F, 1.0F);
/* 55 */       p.getWorld().playEffect(chest.getLocation(), Effect.ENDER_SIGNAL, 1);
/*    */       
/*    */       return;
/*    */     } 
/* 59 */     e.setCancelled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\saveable\BlockPlaceListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */