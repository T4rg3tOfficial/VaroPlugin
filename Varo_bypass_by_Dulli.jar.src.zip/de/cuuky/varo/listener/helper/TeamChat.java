/*    */ package de.cuuky.varo.listener.helper;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.logger.logger.ChatLogger;
/*    */ 
/*    */ public class TeamChat
/*    */ {
/*    */   public TeamChat(VaroPlayer player, String message) {
/* 11 */     if (player.getTeam() == null) {
/* 12 */       player.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du bist in keinem Team!");
/*    */       
/*    */       return;
/*    */     } 
/* 16 */     if (message.isEmpty()) {
/*    */       return;
/*    */     }
/* 19 */     Main.getDataManager().getVaroLoggerManager().getChatLogger().println(ChatLogger.ChatLogType.TEAMCHAT, "#" + player.getTeam().getName() + " | " + player.getName() + " >> " + message);
/* 20 */     for (VaroPlayer pl : player.getTeam().getMember()) {
/* 21 */       if (!pl.isOnline()) {
/*    */         continue;
/*    */       }
/* 24 */       pl.sendMessage(ConfigMessages.CHAT_TEAMCHAT_FORMAT.getValue(player).replace("%message%", message));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\helper\TeamChat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */