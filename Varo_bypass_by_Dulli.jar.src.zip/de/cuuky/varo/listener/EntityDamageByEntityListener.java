/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import de.cuuky.varo.listener.helper.cancelable.CancelAbleType;
/*    */ import de.cuuky.varo.listener.helper.cancelable.VaroCancelAble;
/*    */ import de.cuuky.varo.listener.utils.EntityDamageByEntityUtil;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ 
/*    */ public class EntityDamageByEntityListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onEntityDamage(EntityDamageByEntityEvent event) {
/* 22 */     if (!(event.getEntity() instanceof Player)) {
/*    */       return;
/*    */     }
/* 25 */     if (Main.getVaroGame().getGameState() == GameState.END) {
/*    */       return;
/*    */     }
/* 28 */     Player p = (Player)event.getEntity();
/* 29 */     Player damager = (new EntityDamageByEntityUtil(event)).getDamager();
/* 30 */     if (Main.getVaroGame().getProtection() != null) {
/* 31 */       if (damager == null) {
/* 32 */         p.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.PROTECTION_TIME_RUNNING.getValue());
/*    */       } else {
/* 34 */         damager.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.PROTECTION_TIME_RUNNING.getValue());
/* 35 */       }  event.setCancelled(true);
/*    */       
/*    */       return;
/*    */     } 
/* 39 */     VaroPlayer vp = VaroPlayer.getPlayer(p);
/* 40 */     if (Main.getVaroGame().getGameState() == GameState.LOBBY || VaroCancelAble.getCancelAble(vp, CancelAbleType.PROTECTION) != null || vp.isInProtection()) {
/* 41 */       event.setCancelled(true);
/*    */       
/*    */       return;
/*    */     } 
/* 45 */     if (ConfigSetting.FRIENDLYFIRE.getValueAsBoolean() || damager == null) {
/*    */       return;
/*    */     }
/* 48 */     VaroPlayer vdamager = VaroPlayer.getPlayer(damager);
/* 49 */     if (VaroCancelAble.getCancelAble(vdamager, CancelAbleType.PROTECTION) != null || (vdamager.isInProtection() && !Main.getVaroGame().isFirstTime())) {
/* 50 */       event.setCancelled(true);
/*    */       
/*    */       return;
/*    */     } 
/* 54 */     if (damager.equals(p) || vp.getTeam() == null || vdamager.getTeam() == null || !vp.getTeam().equals(vdamager.getTeam())) {
/*    */       return;
/*    */     }
/* 57 */     event.setCancelled(true);
/* 58 */     damager.sendMessage(ConfigMessages.COMBAT_FRIENDLY_FIRE.getValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\EntityDamageByEntityListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */