/*     */ package de.cuuky.varo.listener.spectator;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.game.state.GameState;
/*     */ import de.cuuky.varo.vanish.Vanish;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.entity.Arrow;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
/*     */ import org.bukkit.event.entity.FoodLevelChangeEvent;
/*     */ import org.bukkit.event.inventory.InventoryDragEvent;
/*     */ import org.bukkit.event.player.PlayerDropItemEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ import org.bukkit.projectiles.ProjectileSource;
/*     */ 
/*     */ public class SpectatorListener
/*     */   implements Listener {
/*     */   @EventHandler
/*     */   public void onEntityDamage(EntityDamageByEntityEvent event) {
/*  32 */     Entity entityDamager = event.getDamager();
/*  33 */     Entity entityDamaged = event.getEntity();
/*     */     
/*  35 */     if (cancelEvent(event.getEntity()) && 
/*  36 */       entityDamager instanceof Arrow && (
/*  37 */       (Arrow)entityDamager).getShooter() instanceof Player) {
/*  38 */       Arrow arrow = (Arrow)entityDamager;
/*     */       
/*  40 */       Player shooter = (Player)arrow.getShooter();
/*  41 */       Player damaged = (Player)entityDamaged;
/*     */       
/*  43 */       if (Vanish.getVanish((Player)entityDamaged) != null) {
/*  44 */         damaged.teleport(entityDamaged.getLocation().add(0.0D, 5.0D, 0.0D));
/*     */         
/*  46 */         Arrow newArrow = (Arrow)arrow.getWorld().spawnEntity(arrow.getLocation(), EntityType.ARROW);
/*  47 */         newArrow.setShooter((ProjectileSource)shooter);
/*  48 */         newArrow.setVelocity(arrow.getVelocity());
/*  49 */         newArrow.setBounce(arrow.doesBounce());
/*     */         
/*  51 */         event.setCancelled(true);
/*  52 */         arrow.remove();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  58 */     if (cancelEvent(entityDamager))
/*  59 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityTarget(EntityTargetLivingEntityEvent event) {
/*  64 */     if (Main.getVaroGame().getGameState() == GameState.LOBBY) {
/*  65 */       event.setCancelled(true);
/*     */     }
/*  67 */     if (cancelEvent((Entity)event.getTarget()))
/*  68 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onFoodLose(FoodLevelChangeEvent event) {
/*  73 */     if (cancelEvent((Entity)event.getEntity()))
/*  74 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onHealthLose(EntityDamageEvent event) {
/*  79 */     if (cancelEvent(event.getEntity()))
/*  80 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInteractEntity(PlayerInteractEntityEvent event) {
/*  85 */     if (Main.getVaroGame().getGameState() == GameState.LOBBY && !event.getPlayer().isOp()) {
/*  86 */       event.setCancelled(true);
/*     */     }
/*  88 */     if (cancelEvent((Entity)event.getPlayer()))
/*  89 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInteract(PlayerInteractEvent event) {
/*  94 */     if (Main.getVaroGame().getGameState() == GameState.LOBBY && !event.getPlayer().isOp()) {
/*  95 */       event.setCancelled(true);
/*     */     }
/*  97 */     if (cancelEvent((Entity)event.getPlayer()))
/*  98 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryMove(InventoryDragEvent event) {
/* 103 */     if (cancelEvent((Entity)event.getWhoClicked()))
/* 104 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onItemDrop(PlayerPickupItemEvent event) {
/* 109 */     if (Main.getVaroGame().getGameState() == GameState.LOBBY && !event.getPlayer().isOp()) {
/* 110 */       event.setCancelled(true);
/*     */     }
/* 112 */     if (cancelEvent((Entity)event.getPlayer()))
/* 113 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onItemPickup(PlayerDropItemEvent event) {
/* 118 */     if (Main.getVaroGame().getGameState() == GameState.LOBBY && !event.getPlayer().isOp()) {
/* 119 */       event.setCancelled(true);
/*     */     }
/* 121 */     if (cancelEvent((Entity)event.getPlayer()))
/* 122 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerMove(PlayerMoveEvent event) {
/* 127 */     if (!event.getPlayer().isOp() && 
/* 128 */       cancelEvent((Entity)event.getPlayer()) && 
/* 129 */       event.getTo().getY() < ConfigSetting.MINIMAL_SPECTATOR_HEIGHT.getValueAsInt()) {
/* 130 */       Location tp = event.getFrom();
/* 131 */       tp.setY(ConfigSetting.MINIMAL_SPECTATOR_HEIGHT.getValueAsInt());
/* 132 */       event.setTo(tp);
/* 133 */       event.getPlayer().sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.NOPERMISSION_NO_LOWER_FLIGHT.getValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean cancelEvent(Entity interact) {
/* 140 */     if (!(interact instanceof Player)) {
/* 141 */       return false;
/*     */     }
/* 143 */     Player player = (Player)interact;
/*     */     
/* 145 */     if (Vanish.getVanish(player) == null || player.getGameMode() != GameMode.ADVENTURE) {
/* 146 */       return false;
/*     */     }
/* 148 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\spectator\SpectatorListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */