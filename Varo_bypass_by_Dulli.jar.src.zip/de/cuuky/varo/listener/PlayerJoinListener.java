/*     */ package de.cuuky.varo.listener;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*     */ import de.cuuky.varo.event.VaroEvent;
/*     */ import de.cuuky.varo.event.VaroEventType;
/*     */ import de.cuuky.varo.event.events.MassRecordingVaroEvent;
/*     */ import de.cuuky.varo.game.lobby.LobbyItem;
/*     */ import de.cuuky.varo.game.state.GameState;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import de.cuuky.varo.spawns.Spawn;
/*     */ import de.cuuky.varo.spigot.updater.VaroUpdateResultSet;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerJoinListener
/*     */   implements Listener
/*     */ {
/*     */   private boolean isOutsideOfBorder(Player p) {
/*  33 */     if (VersionUtils.getVersion() == BukkitVersion.ONE_7) {
/*  34 */       return false;
/*     */     }
/*     */     try {
/*  37 */       Location loc = p.getLocation();
/*  38 */       Object border = p.getWorld().getClass().getDeclaredMethod("getWorldBorder", new Class[0]).invoke(p.getWorld(), new Object[0]);
/*  39 */       double size = ((Double)border.getClass().getDeclaredMethod("getSize", new Class[0]).invoke(border, new Object[0])).doubleValue() / 2.0D;
/*  40 */       Location center = (Location)border.getClass().getDeclaredMethod("getCenter", new Class[0]).invoke(border, new Object[0]);
/*  41 */       double x = loc.getX() - center.getX(), z = loc.getZ() - center.getZ();
/*  42 */       return !(x <= size && -x <= size && z <= size && -z <= size);
/*  43 */     } catch (Exception e) {
/*  44 */       e.printStackTrace();
/*  45 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/*  51 */     Player player = event.getPlayer();
/*  52 */     final VaroPlayer vplayer = VaroPlayer.getPlayer(player);
/*     */     
/*  54 */     vplayer.setPlayer(player);
/*  55 */     vplayer.onEvent(BukkitEventType.JOINED);
/*     */     
/*  57 */     if (Main.getVaroGame().getGameState() == GameState.LOBBY) {
/*  58 */       player.getInventory().clear();
/*  59 */       player.getInventory().setArmorContents(new org.bukkit.inventory.ItemStack[0]);
/*  60 */       player.updateInventory();
/*     */       
/*  62 */       Spawn spawn = Spawn.getSpawn(vplayer);
/*  63 */       if (spawn != null && (ConfigSetting.SPAWN_TELEPORT_JOIN.getValueAsBoolean() || Main.getVaroGame().isStarting())) {
/*  64 */         player.teleport(spawn.getLocation());
/*     */       } else {
/*  66 */         player.teleport(Main.getVaroGame().getVaroWorldHandler().getTeleportLocation());
/*  67 */         LobbyItem.giveItems(player);
/*     */       } 
/*     */       
/*  70 */       if (ConfigSetting.START_AT_PLAYERS.isIntActivated()) {
/*  71 */         if (VaroPlayer.getOnlineAndAlivePlayer().size() >= ConfigSetting.START_AT_PLAYERS.getValueAsInt()) {
/*  72 */           Main.getVaroGame().start();
/*     */         } else {
/*  74 */           Bukkit.broadcastMessage(String.valueOf(Main.getPrefix()) + "Es werden noch " + (ConfigSetting.START_AT_PLAYERS.getValueAsInt() - VaroPlayer.getOnlineAndAlivePlayer().size()) + " Spieler zum Start benoetigt!");
/*     */         } 
/*     */       }
/*  77 */       if (player.isOp()) {
/*  78 */         VaroUpdateResultSet updater = Main.getVaroUpdater().getLastResult();
/*  79 */         if (updater != null) {
/*  80 */           VaroUpdateResultSet.UpdateResult result = updater.getUpdateResult();
/*  81 */           String updateVersion = updater.getVersionName();
/*     */           
/*  83 */           if (result == VaroUpdateResultSet.UpdateResult.UPDATE_AVAILABLE) {
/*  84 */             if (Main.getVaroGame().getGameState() == GameState.LOBBY) {
/*  85 */               vplayer.getNetworkManager().sendTitle("§cUpdate verfuegbar", "Deine Pluginversion ist nicht aktuell!");
/*     */             }
/*  87 */             player.sendMessage("§cUpdate auf Version " + updateVersion + " verfuegbar!§7 Mit §l/varo update§7 kannst du das Update installieren.");
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } else {
/*  92 */       MassRecordingVaroEvent massRecording = (MassRecordingVaroEvent)VaroEvent.getEvent(VaroEventType.MASS_RECORDING);
/*  93 */       if (vplayer.getStats().getSessionsPlayed() == 0) {
/*  94 */         int countdown = massRecording.isEnabled() ? massRecording.getCountdown(vplayer) : vplayer.getStats().getCountdown();
/*  95 */         if (countdown == ConfigSetting.PLAY_TIME.getValueAsInt() * 60 && ConfigSetting.PLAY_TIME.getValueAsInt() > 0) {
/*  96 */           player.teleport(Main.getVaroGame().getVaroWorldHandler().getMainWorld().getWorld().getSpawnLocation());
/*     */         }
/*     */       } 
/*     */       
/* 100 */       if (isOutsideOfBorder(player) && ConfigSetting.OUTSIDE_BORDER_SPAWN_TELEPORT.getValueAsBoolean()) {
/* 101 */         player.teleport(player.getWorld().getSpawnLocation());
/* 102 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.JOIN_LEAVE, ConfigMessages.ALERT_TELEPORTED_TO_MIDDLE.getValue(vplayer));
/*     */       } 
/*     */       
/* 105 */       if (vplayer.getStats().isSpectator() || vplayer.isAdminIgnore()) {
/* 106 */         event.setJoinMessage(ConfigMessages.JOIN_SPECTATOR.getValue(vplayer));
/* 107 */       } else if (Main.getVaroGame().getFinaleJoinStart()) {
/* 108 */         event.setJoinMessage(ConfigMessages.JOIN_FINALE.getValue(vplayer));
/* 109 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.JOIN_LEAVE, ConfigMessages.ALERT_JOIN_FINALE.getValue(vplayer));
/* 110 */         vplayer.sendMessage(String.valueOf(Main.getPrefix()) + "Das Finale beginnt bald. Bis zum Finalestart wurden alle gefreezed.");
/* 111 */         if (!player.isOp());
/*     */       
/*     */       }
/* 114 */       else if (!ConfigSetting.PLAY_TIME.isIntActivated()) {
/* 115 */         event.setJoinMessage(ConfigMessages.JOIN_MESSAGE.getValue(vplayer));
/* 116 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.JOIN_LEAVE, ConfigMessages.ALERT_PLAYER_JOIN_NORMAL.getValue(vplayer));
/* 117 */       } else if (massRecording.isEnabled()) {
/* 118 */         if (massRecording.getCountdown(vplayer) == ConfigSetting.PLAY_TIME.getValueAsInt() * 60) {
/* 119 */           vplayer.getStats().setCountdown(massRecording.getTimer());
/*     */         } else {
/* 121 */           vplayer.getStats().setCountdown(massRecording.getCountdown(vplayer) + massRecording.getTimer());
/*     */         } 
/*     */         
/* 124 */         if (!vplayer.getalreadyHadMassProtectionTime()) {
/* 125 */           vplayer.getStats().addSessionPlayed();
/* 126 */           event.setJoinMessage(ConfigMessages.JOIN_MASS_RECORDING.getValue(vplayer));
/* 127 */           Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.JOIN_LEAVE, ConfigMessages.ALERT_PLAYER_JOIN_MASSREC.getValue(vplayer));
/* 128 */           vplayer.setalreadyHadMassProtectionTime(true);
/* 129 */           vplayer.setinMassProtectionTime(true);
/* 130 */           Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */               {
/*     */                 public void run() {
/* 133 */                   vplayer.setinMassProtectionTime(false);
/* 134 */                   Bukkit.broadcastMessage(ConfigMessages.JOIN_PROTECTION_OVER.getValue(vplayer));
/*     */                 }
/* 136 */               },  (ConfigSetting.JOIN_PROTECTIONTIME.getValueAsInt() * 20));
/*     */         } else {
/* 138 */           event.setJoinMessage(ConfigMessages.JOIN_WITH_REMAINING_TIME.getValue(vplayer));
/* 139 */           Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.JOIN_LEAVE, ConfigMessages.ALERT_PLAYER_RECONNECT.getValue(vplayer));
/*     */         } 
/* 141 */       } else if (!vplayer.getStats().hasTimeLeft()) {
/* 142 */         event.setJoinMessage(ConfigMessages.JOIN_PROTECTION_TIME.getValue(vplayer));
/* 143 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.JOIN_LEAVE, ConfigMessages.ALERT_PLAYER_JOINED.getValue(vplayer));
/*     */       } else {
/* 145 */         event.setJoinMessage(ConfigMessages.JOIN_WITH_REMAINING_TIME.getValue(vplayer));
/* 146 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.JOIN_LEAVE, ConfigMessages.ALERT_PLAYER_RECONNECT.getValue(vplayer));
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 151 */     event.setJoinMessage(ConfigMessages.JOIN_MESSAGE.getValue(vplayer));
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\PlayerJoinListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */