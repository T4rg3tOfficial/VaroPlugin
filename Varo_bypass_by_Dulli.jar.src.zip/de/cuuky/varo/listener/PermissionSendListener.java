/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Map;
/*    */ import net.labymod.serverapi.Permission;
/*    */ import net.labymod.serverapi.bukkit.event.LabyModPlayerJoinEvent;
/*    */ import net.labymod.serverapi.bukkit.event.PermissionsSendEvent;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class PermissionSendListener
/*    */   implements Listener
/*    */ {
/* 20 */   public static ArrayList<Player> labyJoined = new ArrayList<>();
/*    */   
/*    */   @EventHandler
/*    */   public void labyModJoin(final LabyModPlayerJoinEvent event) {
/* 24 */     if (ConfigSetting.ONLY_LABYMOD_PLAYER.getValueAsBoolean()) {
/* 25 */       labyJoined.add(event.getPlayer());
/*    */     }
/* 27 */     if (ConfigSetting.KICK_LABYMOD_PLAYER.getValueAsBoolean())
/* 28 */       Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*    */           {
/*    */             public void run()
/*    */             {
/* 32 */               event.getPlayer().kickPlayer(ConfigMessages.LABYMOD_KICK.getValue());
/*    */             }
/* 34 */           },  1L); 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPermissionSend(PermissionsSendEvent event) {
/* 39 */     if (ConfigSetting.DISABLE_LABYMOD_FUNCTIONS.getValueAsBoolean())
/* 40 */       for (Map.Entry<Permission, Boolean> permissionEntry : (Iterable<Map.Entry<Permission, Boolean>>)event.getPermissions().entrySet())
/* 41 */         permissionEntry.setValue(Boolean.valueOf(false));  
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\PermissionSendListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */