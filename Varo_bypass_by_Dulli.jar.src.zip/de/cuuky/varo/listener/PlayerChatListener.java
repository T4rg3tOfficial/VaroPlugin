/*     */ package de.cuuky.varo.listener;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.gui.utils.chat.ChatHook;
/*     */ import de.cuuky.varo.listener.helper.ChatMessage;
/*     */ import de.cuuky.varo.listener.helper.cancelable.CancelAbleType;
/*     */ import de.cuuky.varo.listener.helper.cancelable.VaroCancelAble;
/*     */ import de.cuuky.varo.logger.logger.ChatLogger;
/*     */ import java.util.Date;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerChatListener
/*     */   implements Listener
/*     */ {
/*     */   private void sendMessageToAll(String msg, VaroPlayer vp, AsyncPlayerChatEvent event) {
/*  24 */     if (vp.getStats().getYoutubeLink() == null) {
/*  25 */       event.setCancelled(false);
/*  26 */       event.setFormat(msg);
/*     */       
/*     */       return;
/*     */     } 
/*  30 */     for (VaroPlayer vpo : VaroPlayer.getOnlinePlayer())
/*  31 */       vpo.getNetworkManager().sendLinkedMessage(msg, vp.getStats().getYoutubeLink()); 
/*  32 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerChat(AsyncPlayerChatEvent event) {
/*  37 */     if (event.isCancelled()) {
/*     */       return;
/*     */     }
/*  40 */     String message = event.getMessage();
/*  41 */     Player player = event.getPlayer();
/*  42 */     ChatHook hook = ChatHook.getChatHook(player);
/*  43 */     if (hook != null) {
/*  44 */       hook.run(message);
/*  45 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/*  49 */     if (message.contains("%")) {
/*  50 */       message = message.replace("%", "");
/*     */     }
/*  52 */     boolean mentionsHack = false;
/*  53 */     String[] hackMentions = { "hack", "cheat", "x-ray", "xray", "unlegit" }; byte b; int i; String[] arrayOfString1;
/*  54 */     for (i = (arrayOfString1 = hackMentions).length, b = 0; b < i; ) { String mention = arrayOfString1[b];
/*  55 */       if (message.toLowerCase().contains(mention))
/*  56 */         mentionsHack = true; 
/*     */       b++; }
/*     */     
/*  59 */     if (mentionsHack && ConfigSetting.REPORTSYSTEM_ENABLED.getValueAsBoolean()) {
/*  60 */       player.sendMessage(String.valueOf(Main.getPrefix()) + "§7Erinnerung: Reporte Hacks, Cheats und aehnliches mit §l/report");
/*     */     }
/*     */     
/*  63 */     VaroPlayer vp = VaroPlayer.getPlayer(player);
/*  64 */     String tc = ConfigSetting.CHAT_TRIGGER.getValueAsString();
/*  65 */     boolean globalTrigger = ConfigSetting.TRIGGER_FOR_GLOBAL.getValueAsBoolean();
/*  66 */     if ((message.startsWith(tc) && !globalTrigger) || (!message.startsWith(tc) && globalTrigger)) {
/*     */       
/*  68 */       event.setCancelled(true); return;
/*     */     } 
/*  70 */     if (message.startsWith(tc)) {
/*  71 */       message = message.replaceFirst("\\" + tc, "");
/*     */     }
/*     */     
/*  74 */     if (ConfigSetting.BLOCK_CHAT_ADS.getValueAsBoolean() && !player.isOp()) {
/*  75 */       if (message.matches("(?ui).*(w\\s*w\\s*w|h\\s*t\\s*t\\s*p\\s*s?|[.,;]\\s*(d\\s*e|n\\s*e\\s*t|c\\s*o\\s*m|t\\s*v)).*")) {
/*  76 */         player.sendMessage(String.valueOf(Main.getPrefix()) + "Du darfst keine Werbung senden - bitte sende keine Links.");
/*  77 */         player.sendMessage(String.valueOf(Main.getPrefix()) + "Falls dies ein Fehler sein sollte, frage einen Admin.");
/*  78 */         event.setCancelled(true);
/*     */         return;
/*     */       } 
/*  81 */       if (message.matches("(?iu).*(meins?e?m?n?)\\s*(Projekt|Plugin|Server|Netzwerk|Varo).*")) {
/*  82 */         player.sendMessage(String.valueOf(Main.getPrefix()) + "Du darfst keine Werbung senden - bitte sende keine Eigenwerbung.");
/*  83 */         player.sendMessage(String.valueOf(Main.getPrefix()) + "Falls dies ein Fehler sein sollte, frage einen Admin.");
/*  84 */         event.setCancelled(true);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*  89 */     if (VaroCancelAble.getCancelAble(vp, CancelAbleType.MUTE) != null) {
/*  90 */       player.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.CHAT_MUTED.getValue());
/*  91 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/*  95 */     if (!player.isOp()) {
/*  96 */       if ((ConfigSetting.CHAT_COOLDOWN_IF_STARTED.getValueAsBoolean() && Main.getVaroGame().hasStarted()) || !Main.getVaroGame().hasStarted()) {
/*  97 */         ChatMessage msg = ChatMessage.getMessage(player);
/*  98 */         if (msg != null) {
/*  99 */           long seconds = (msg.getWritten().getTime() - (new Date()).getTime()) / 1000L * -1L;
/* 100 */           if (seconds < ConfigSetting.CHAT_COOLDOWN_IN_SECONDS.getValueAsInt()) {
/* 101 */             player.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du kannst nur alle §7" + ConfigSetting.CHAT_COOLDOWN_IN_SECONDS.getValueAsInt() + " §7Sekunden schreiben!");
/* 102 */             event.setCancelled(true);
/*     */             return;
/*     */           } 
/* 105 */         } else if (!player.isOp()) {
/*     */         
/*     */         } 
/*     */       } 
/* 109 */       if (!Main.getVaroGame().hasStarted() && !ConfigSetting.CAN_CHAT_BEFORE_START.getValueAsBoolean()) {
/* 110 */         player.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.CHAT_WHEN_START.getValue());
/* 111 */         event.setCancelled(true);
/*     */         return;
/*     */       } 
/*     */     } else {
/* 115 */       message = message.replace("&", "§");
/*     */     } 
/* 117 */     Main.getDataManager().getVaroLoggerManager().getChatLogger().println(ChatLogger.ChatLogType.CHAT, String.valueOf(player.getName()) + "» '" + message + "'");
/* 118 */     sendMessageToAll(String.valueOf(vp.getPrefix()) + ConfigMessages.CHAT_FORMAT.getValue(vp) + message, vp, event);
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\PlayerChatListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */