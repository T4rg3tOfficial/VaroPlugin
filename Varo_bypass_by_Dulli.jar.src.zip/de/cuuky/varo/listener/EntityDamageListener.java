/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import de.cuuky.varo.listener.helper.cancelable.CancelAbleType;
/*    */ import de.cuuky.varo.listener.helper.cancelable.VaroCancelAble;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ 
/*    */ public class EntityDamageListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler(priority = EventPriority.HIGH)
/*    */   public void onEntityDamage(EntityDamageEvent event) {
/* 21 */     Entity e = event.getEntity();
/* 22 */     if (!(e instanceof Player)) {
/*    */       return;
/*    */     }
/* 25 */     if (Main.getVaroGame().getGameState() == GameState.END) {
/*    */       return;
/*    */     }
/* 28 */     Player pl = (Player)e;
/* 29 */     VaroPlayer vp = VaroPlayer.getPlayer(pl);
/*    */     
/* 31 */     if (Main.getVaroGame().getGameState() == GameState.LOBBY || VaroCancelAble.getCancelAble(vp, CancelAbleType.PROTECTION) != null || Main.getVaroGame().getProtection() != null) {
/* 32 */       event.setCancelled(true);
/*    */       
/*    */       return;
/*    */     } 
/* 36 */     if (!ConfigSetting.JOIN_PROTECTIONTIME.isIntActivated() || Main.getVaroGame().isStarting() || Main.getVaroGame().isFirstTime()) {
/*    */       return;
/*    */     }
/* 39 */     if (vp.isInProtection()) {
/* 40 */       event.setCancelled(true);
/*    */       return;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\EntityDamageListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */