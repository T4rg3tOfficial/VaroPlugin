/*    */ package de.cuuky.varo.listener.lists;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.inventory.CraftItemEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ 
/*    */ public class BlockedItemsListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onCraft(CraftItemEvent event) {
/* 16 */     if (event.getCurrentItem() == null) {
/*    */       return;
/*    */     }
/* 19 */     if (!Main.getDataManager().getListManager().getBlockedItems().isBlocked(event.getCurrentItem()) && !Main.getDataManager().getListManager().getBlockedRecipes().isBlocked(event.getCurrentItem())) {
/*    */       return;
/*    */     }
/* 22 */     event.setCancelled(true);
/* 23 */     ((Player)event.getWhoClicked()).sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.NOPERMISSION_NOT_ALLOWED_CRAFT.getValue());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onInteract(PlayerInteractEvent event) {
/* 28 */     if (event.getItem() == null) {
/*    */       return;
/*    */     }
/* 31 */     if (!Main.getDataManager().getListManager().getBlockedItems().isBlocked(event.getItem())) {
/*    */       return;
/*    */     }
/* 34 */     event.setCancelled(true);
/* 35 */     event.getPlayer().sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.NOPERMISSION_NOT_ALLOWED_CRAFT.getValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\lists\BlockedItemsListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */