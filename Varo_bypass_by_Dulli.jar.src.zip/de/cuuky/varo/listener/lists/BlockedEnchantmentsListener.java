/*    */ package de.cuuky.varo.listener.lists;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import org.bukkit.enchantments.Enchantment;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.enchantment.EnchantItemEvent;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.InventoryView;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class BlockedEnchantmentsListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onEnchant(EnchantItemEvent event) {
/* 22 */     if (event.getItem() == null) {
/*    */       return;
/*    */     }
/* 25 */     for (Enchantment enc : event.getEnchantsToAdd().keySet()) {
/* 26 */       if (Main.getDataManager().getListManager().getBlockedEnchantments().isBlocked(enc, ((Integer)event.getEnchantsToAdd().get(enc)).intValue())) {
/* 27 */         event.setCancelled(true);
/* 28 */         event.getEnchanter().sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.NOPERMISSION_NOT_ALLOWED_CRAFT.getValue());
/*    */         return;
/*    */       } 
/*    */     } 
/*    */   }
/*    */   @EventHandler(priority = EventPriority.MONITOR)
/*    */   public void onInventoryClick(InventoryClickEvent event) {
/* 35 */     if (event.isCancelled()) {
/*    */       return;
/*    */     }
/* 38 */     Inventory inv = event.getInventory();
/*    */     
/* 40 */     if (!(inv instanceof org.bukkit.inventory.AnvilInventory)) {
/*    */       return;
/*    */     }
/* 43 */     InventoryView view = event.getView();
/* 44 */     int rawSlot = event.getRawSlot();
/*    */     
/* 46 */     if (rawSlot != view.convertSlot(rawSlot) || rawSlot != 2) {
/*    */       return;
/*    */     }
/* 49 */     ItemStack item = event.getCurrentItem();
/* 50 */     if (item == null) {
/*    */       return;
/*    */     }
/* 53 */     for (Enchantment enc : item.getEnchantments().keySet()) {
/* 54 */       if (Main.getDataManager().getListManager().getBlockedEnchantments().isBlocked(enc, ((Integer)item.getEnchantments().get(enc)).intValue())) {
/* 55 */         event.setCancelled(true);
/* 56 */         ((Player)event.getWhoClicked()).sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.NOPERMISSION_NOT_ALLOWED_CRAFT.getValue());
/*    */         return;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\lists\BlockedEnchantmentsListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */