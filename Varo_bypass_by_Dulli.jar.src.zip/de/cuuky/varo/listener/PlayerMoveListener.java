/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import de.cuuky.varo.listener.helper.cancelable.CancelAbleType;
/*    */ import de.cuuky.varo.listener.helper.cancelable.VaroCancelAble;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerMoveEvent;
/*    */ 
/*    */ public class PlayerMoveListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onPlayerMove(PlayerMoveEvent event) {
/* 22 */     Location from = event.getFrom();
/* 23 */     Location to = event.getTo();
/*    */     
/* 25 */     if (from.getX() == to.getX() && from.getZ() == to.getZ()) {
/*    */       return;
/*    */     }
/* 28 */     Player player = event.getPlayer();
/* 29 */     VaroPlayer vp = VaroPlayer.getPlayer(player);
/*    */     
/* 31 */     if (VaroCancelAble.getCancelAble(vp, CancelAbleType.FREEZE) != null || (Main.getVaroGame().isStarting() && !vp.getStats().isSpectator())) {
/* 32 */       event.setTo(from);
/*    */       
/*    */       return;
/*    */     } 
/* 36 */     if (Main.getVaroGame().getGameState() == GameState.LOBBY) {
/* 37 */       if (ConfigSetting.CAN_MOVE_BEFORE_START.getValueAsBoolean() || player.isOp() || player.getGameMode() == GameMode.CREATIVE) {
/*    */         return;
/*    */       }
/* 40 */       event.setTo(from);
/* 41 */       player.sendMessage(ConfigMessages.PROTECTION_NO_MOVE_START.getValue()); return;
/*    */     } 
/* 43 */     if (Main.getVaroGame().getGameState() == GameState.STARTED) {
/* 44 */       if (Main.getVaroGame().isStarting() || vp.getStats().isSpectator() || ConfigSetting.CANWALK_PROTECTIONTIME.getValueAsBoolean() || !ConfigSetting.JOIN_PROTECTIONTIME.isIntActivated() || Main.getVaroGame().isFirstTime() || vp.isAdminIgnore()) {
/*    */         return;
/*    */       }
/*    */       
/* 48 */       if (vp.isInProtection()) {
/* 49 */         event.setTo(from);
/* 50 */         player.sendMessage(ConfigMessages.JOIN_NO_MOVE_IN_PROTECTION.getValue());
/*    */         return;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\PlayerMoveListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */