/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.FoodLevelChangeEvent;
/*    */ 
/*    */ public class PlayerHungerListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void on(FoodLevelChangeEvent e) {
/* 13 */     if (!Main.getVaroGame().hasStarted())
/* 14 */       e.setFoodLevel(40); 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\listener\PlayerHungerListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */