/*     */ package de.cuuky.varo;
/*     */ 
/*     */ import de.cuuky.varo.bot.BotLauncher;
/*     */ import de.cuuky.varo.configuration.ConfigFailureDetector;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.data.BukkitRegisterer;
/*     */ import de.cuuky.varo.data.DataManager;
/*     */ import de.cuuky.varo.game.VaroGame;
/*     */ import de.cuuky.varo.recovery.recoveries.VaroBugreport;
/*     */ import de.cuuky.varo.spigot.updater.VaroUpdater;
/*     */ import de.cuuky.varo.utils.JavaUtils;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import java.io.File;
/*     */ import javax.swing.JOptionPane;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Main
/*     */   extends JavaPlugin
/*     */ {
/*     */   private static final String CONSOLE_PREFIX = "[Varo] ";
/*     */   private static Main instance;
/*     */   private static BotLauncher botLauncher;
/*     */   private static DataManager dataManager;
/*     */   private static VaroUpdater varoUpdater;
/*     */   private static VaroGame varoGame;
/*     */   private boolean failed;
/*     */   
/*     */   public void onLoad() {
/*  43 */     this.failed = false;
/*  44 */     instance = this;
/*     */ 
/*     */     
/*  47 */     super.onLoad();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  52 */     long timestamp = System.currentTimeMillis();
/*     */     
/*  54 */     System.out.println("############################################################################");
/*  55 */     System.out.println("#                                                                          #");
/*  56 */     System.out.println("#  #     #                         ######                                  #");
/*  57 */     System.out.println("#  #     #   ##   #####   ####     #     # #      #    #  ####  # #    #   #");
/*  58 */     System.out.println("#  #     #  #  #  #    # #    #    #     # #      #    # #    # # ##   #   #");
/*  59 */     System.out.println("#  #     # #    # #    # #    #    ######  #      #    # #      # # #  #   #");
/*  60 */     System.out.println("#   #   #  ###### #####  #    #    #       #      #    # #  ### # #  # #   #");
/*  61 */     System.out.println("#    # #   #    # #   #  #    #    #       #      #    # #    # # #   ##   #");
/*  62 */     System.out.println("#     #    #    # #    #  ####     #       ######  ####   ####  # #    #   #");
/*  63 */     System.out.println("#                                                                          #");
/*  64 */     System.out.println("#                               by Cuuky                                   #");
/*  65 */     System.out.println("#                                                                          #");
/*  66 */     System.out.println("############################################################################");
/*     */     
/*  68 */     System.out.println("[Varo] ");
/*  69 */     System.out.println("[Varo] Enabling " + getPluginName() + "...");
/*  70 */     System.out.println("[Varo] Running on " + Bukkit.getVersion());
/*  71 */     System.out.println("[Varo] Other plugins enabled: " + ((Bukkit.getPluginManager().getPlugins()).length - 1));
/*     */     
/*  73 */     if (Bukkit.getVersion().contains("Bukkit")) {
/*  74 */       System.out.println("[Varo] It seems like you're using Bukkit. Bukkit has a worse performance and is lacking some features.");
/*  75 */       System.out.println("[Varo] Please use Spigot or Paper instead (https://getbukkit.org/download/spigot).");
/*     */     } 
/*     */     
/*     */     try {
/*  79 */       if ((new ConfigFailureDetector()).hasFailed()) {
/*  80 */         this.failed = true;
/*  81 */         Bukkit.getPluginManager().disablePlugin((Plugin)getInstance());
/*     */         
/*     */         return;
/*     */       } 
/*  85 */       long dataStamp = System.currentTimeMillis();
/*  86 */       dataManager = new DataManager();
/*  87 */       System.out.println("[Varo] Loaded all data (" + (System.currentTimeMillis() - dataStamp) + "ms)");
/*     */       
/*  89 */       varoUpdater = new VaroUpdater();
/*  90 */       botLauncher = new BotLauncher();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  95 */       BukkitRegisterer.registerEvents();
/*  96 */       BukkitRegisterer.registerCommands();
/*  97 */     } catch (Throwable e) {
/*  98 */       e.printStackTrace();
/*  99 */       this.failed = true;
/* 100 */       Bukkit.getPluginManager().disablePlugin((Plugin)this);
/*     */     } 
/*     */     
/* 103 */     if (this.failed) {
/*     */       return;
/*     */     }
/* 106 */     System.out.println("[Varo] Enabled! (" + (System.currentTimeMillis() - timestamp) + "ms)");
/* 107 */     System.out.println("[Varo]  ");
/* 108 */     System.out.println("[Varo] --------------------------------");
/* 109 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 114 */     long timestamp = System.currentTimeMillis();
/*     */     
/* 116 */     System.out.println("[Varo] --------------------------------");
/* 117 */     System.out.println("[Varo]  ");
/* 118 */     System.out.println("[Varo] Disabling " + getDescription().getName() + "...");
/*     */     
/* 120 */     if (dataManager != null && !this.failed) {
/* 121 */       System.out.println("[Varo] Saving data...");
/* 122 */       dataManager.save();
/*     */     } 
/*     */     
/* 125 */     if (botLauncher != null && (botLauncher.getDiscordbot() != null || botLauncher.getTelegrambot() != null)) {
/* 126 */       System.out.println("[Varo] Disconnecting bots...");
/* 127 */       botLauncher.disconnect();
/*     */     } 
/*     */     
/* 130 */     if (!this.failed) {
/* 131 */       VersionUtils.getOnlinePlayer().forEach(pl -> pl.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard()));
/*     */     } else {
/* 133 */       VaroBugreport report = new VaroBugreport();
/* 134 */       System.out.println("[Varo] Saved Crashreport to " + report.getZipFile().getName());
/*     */     } 
/* 136 */     Bukkit.getScheduler().cancelTasks((Plugin)this);
/*     */     
/* 138 */     System.out.println("[Varo] Disabled! (" + (System.currentTimeMillis() - timestamp) + "ms)");
/* 139 */     System.out.println("[Varo]  ");
/* 140 */     System.out.println("[Varo] --------------------------------");
/* 141 */     super.onDisable();
/*     */   }
/*     */   
/*     */   public void setFailed(boolean failed) {
/* 145 */     this.failed = failed;
/*     */   }
/*     */   
/*     */   public boolean isFailed() {
/* 149 */     return this.failed;
/*     */   }
/*     */   
/*     */   public File getThisFile() {
/* 153 */     return getFile();
/*     */   }
/*     */   
/*     */   public static void broadcastMessage(String message) {
/* 157 */     Bukkit.broadcastMessage(String.valueOf(getPrefix()) + message);
/*     */   }
/*     */   
/*     */   public static String getColorCode() {
/* 161 */     return ConfigSetting.PROJECTNAME_COLORCODE.getValueAsString();
/*     */   }
/*     */   
/*     */   public static String getConsolePrefix() {
/* 165 */     return "[Varo] ";
/*     */   }
/*     */   
/*     */   public static void setVaroGame(VaroGame varoGame) {
/* 169 */     Main.varoGame = varoGame;
/*     */   }
/*     */   
/*     */   public static VaroGame getVaroGame() {
/* 173 */     return varoGame;
/*     */   }
/*     */   
/*     */   public static VaroUpdater getVaroUpdater() {
/* 177 */     return varoUpdater;
/*     */   }
/*     */   
/*     */   public static void setDataManager(DataManager dataManager) {
/* 181 */     Main.dataManager = dataManager;
/*     */   }
/*     */   
/*     */   public static DataManager getDataManager() {
/* 185 */     return dataManager;
/*     */   }
/*     */   
/*     */   public static BotLauncher getBotLauncher() {
/* 189 */     return botLauncher;
/*     */   }
/*     */   
/*     */   public static String getPluginName() {
/* 193 */     return String.valueOf(instance.getDescription().getName()) + " v" + instance.getDescription().getVersion() + " by " + (String)instance.getDescription().getAuthors().get(0) + " - Contributors: " + getContributors();
/*     */   }
/*     */   
/*     */   public static String getContributors() {
/* 197 */     return JavaUtils.getArgsToString(JavaUtils.removeString(JavaUtils.arrayToCollection(instance.getDescription().getAuthors()), 0), ", ");
/*     */   }
/*     */   
/*     */   public static String getPrefix() {
/* 201 */     return ConfigSetting.PREFIX.getValueAsString();
/*     */   }
/*     */   
/*     */   public static String getProjectName() {
/* 205 */     return String.valueOf(getColorCode()) + ConfigSetting.PROJECT_NAME.getValueAsString();
/*     */   }
/*     */   
/*     */   public static boolean isBootedUp() {
/* 209 */     return (dataManager != null);
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 213 */     JOptionPane.showMessageDialog(null, "No don't do it");
/*     */   }
/*     */   
/*     */   public static Main getInstance() {
/* 217 */     return instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */