/*    */ package de.cuuky.varo.bot.telegram;
/*    */ 
/*    */ import com.pengrad.telegrambot.TelegramBot;
/*    */ import com.pengrad.telegrambot.UpdatesListener;
/*    */ import com.pengrad.telegrambot.model.Update;
/*    */ import com.pengrad.telegrambot.request.BaseRequest;
/*    */ import com.pengrad.telegrambot.request.SendMessage;
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.bot.VaroBot;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroTelegramBot
/*    */   implements VaroBot
/*    */ {
/* 21 */   private long eventChannelId = -1L;
/* 22 */   private long youtubeChannelId = -1L;
/*    */   
/* 24 */   private TelegramBot telegrambot = new TelegramBot(ConfigSetting.TELEGRAM_BOT_TOKEN.getValueAsString());
/*    */ 
/*    */   
/*    */   private void startListening() {
/* 28 */     this.telegrambot.setUpdatesListener(new UpdatesListener()
/*    */         {
/*    */           public int process(List<Update> args)
/*    */           {
/* 32 */             for (Update update : args) {
/* 33 */               if (update.message() == null) {
/*    */                 continue;
/*    */               }
/* 36 */               if (!update.message().text().contains("/getId")) {
/*    */                 continue;
/*    */               }
/* 39 */               VaroTelegramBot.this.telegrambot.execute((BaseRequest)new SendMessage(update.message().chat().id(), "Chat ID von diesem Chat: " + update.message().chat().id()));
/*    */             } 
/*    */             
/* 42 */             return -1;
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   public void connect() {
/* 49 */     startListening();
/*    */     
/* 51 */     this.eventChannelId = ConfigSetting.TELEGRAM_EVENT_CHAT_ID.getValueAsLong();
/*    */     
/* 53 */     if (this.eventChannelId == -1L) {
/* 54 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Could not get chat of chat id");
/*    */     }
/* 56 */     this.youtubeChannelId = ConfigSetting.TELEGRAM_VIDEOS_CHAT_ID.getValueAsLong();
/*    */     
/* 58 */     if (this.youtubeChannelId == -1L) {
/* 59 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Could not get chat of videochat id");
/*    */     }
/* 61 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Telegram Bot connected!");
/*    */   }
/*    */ 
/*    */   
/*    */   public void disconnect() {
/* 66 */     this.telegrambot.removeGetUpdatesListener();
/*    */   }
/*    */   
/*    */   public void sendEvent(String message) {
/*    */     try {
/* 71 */       this.telegrambot.execute((BaseRequest)new SendMessage(Long.valueOf(this.eventChannelId), message));
/* 72 */     } catch (Exception e) {
/* 73 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Could not send events");
/*    */     } 
/*    */   }
/*    */   
/*    */   public void sendVideo(String message) {
/*    */     try {
/* 79 */       this.telegrambot.execute((BaseRequest)new SendMessage(Long.valueOf(this.youtubeChannelId), message));
/* 80 */     } catch (Exception e) {
/* 81 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Could not send videos");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\bot\telegram\VaroTelegramBot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */