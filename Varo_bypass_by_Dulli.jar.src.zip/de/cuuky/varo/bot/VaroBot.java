package de.cuuky.varo.bot;

public interface VaroBot {
  void connect();
  
  void disconnect();
}


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\bot\VaroBot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */