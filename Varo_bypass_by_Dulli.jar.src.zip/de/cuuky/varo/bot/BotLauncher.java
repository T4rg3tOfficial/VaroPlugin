/*    */ package de.cuuky.varo.bot;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.bot.discord.VaroDiscordBot;
/*    */ import de.cuuky.varo.bot.telegram.VaroTelegramBot;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ 
/*    */ public class BotLauncher
/*    */ {
/*    */   private VaroDiscordBot discordbot;
/*    */   private VaroTelegramBot telegrambot;
/*    */   
/*    */   public BotLauncher() {
/* 14 */     startupDiscord();
/* 15 */     startupTelegram();
/*    */   }
/*    */   
/*    */   public void disconnect() {
/* 19 */     if (this.discordbot != null) {
/* 20 */       this.discordbot.disconnect();
/*    */     }
/* 22 */     if (this.telegrambot != null)
/* 23 */       this.telegrambot.disconnect(); 
/*    */   }
/*    */   
/*    */   public void startupDiscord() {
/* 27 */     if (!ConfigSetting.DISCORDBOT_ENABLED.getValueAsBoolean()) {
/*    */       return;
/*    */     }
/* 30 */     if (ConfigSetting.DISCORDBOT_TOKEN.getValue().equals("ENTER TOKEN HERE") || ConfigSetting.DISCORDBOT_SERVERID.getValueAsLong() == -1L) {
/* 31 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "DiscordBot deactivated because of missing information in the config (DiscordToken or ServerID missing)");
/*    */       
/*    */       return;
/*    */     } 
/*    */     try {
/* 36 */       this.discordbot = new VaroDiscordBot();
/* 37 */     } catch (NoClassDefFoundError|BootstrapMethodError e) {
/* 38 */       this.discordbot = null;
/* 39 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "DiscordBot disabled because of missing plugin.");
/* 40 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "If you want to use the DiscordBot please install this plugin:");
/* 41 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "https://www.spigotmc.org/resources/66778/");
/*    */       
/*    */       return;
/*    */     } 
/*    */     try {
/* 46 */       this.discordbot.connect();
/* 47 */     } catch (Exception e) {
/* 48 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void startupTelegram() {
/* 53 */     if (!ConfigSetting.TELEGRAM_ENABLED.getValueAsBoolean()) {
/*    */       return;
/*    */     }
/* 56 */     if (ConfigSetting.TELEGRAM_BOT_TOKEN.getValue().equals("ENTER TOKEN HERE")) {
/* 57 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "TelegramBot deactivated because of missing information in the config");
/*    */       
/*    */       return;
/*    */     } 
/*    */     try {
/* 62 */       this.telegrambot = new VaroTelegramBot();
/* 63 */     } catch (NoClassDefFoundError|BootstrapMethodError e) {
/* 64 */       this.telegrambot = null;
/* 65 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "TelegramBot disabled because of missing plugin.");
/* 66 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "If you want to use the TelegramBot please install this plugin:");
/* 67 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "https://www.spigotmc.org/resources/66823/");
/*    */       
/*    */       return;
/*    */     } 
/*    */     try {
/* 72 */       this.telegrambot.connect();
/* 73 */     } catch (Exception e) {
/* 74 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public VaroDiscordBot getDiscordbot() {
/* 79 */     return this.discordbot;
/*    */   }
/*    */   
/*    */   public VaroTelegramBot getTelegrambot() {
/* 83 */     return this.telegrambot;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\bot\BotLauncher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */