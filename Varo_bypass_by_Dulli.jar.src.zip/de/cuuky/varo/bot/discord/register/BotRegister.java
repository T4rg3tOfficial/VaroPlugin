/*     */ package de.cuuky.varo.bot.discord.register;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import java.util.UUID;
/*     */ import net.dv8tion.jda.api.entities.Member;
/*     */ import net.dv8tion.jda.api.entities.User;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BotRegister
/*     */ {
/*     */   private static final String TABLE = "verify";
/*  32 */   private static ArrayList<BotRegister> register = new ArrayList<>();
/*     */   static {
/*  34 */     loadAll();
/*     */   }
/*     */   private boolean bypass;
/*     */   private int code;
/*     */   private long userId;
/*     */   private String uuid;
/*     */   private String name;
/*     */   
/*     */   public BotRegister(String uuid, boolean start) {
/*  43 */     this.uuid = uuid;
/*  44 */     this.userId = -1L;
/*  45 */     this.code = -1;
/*     */     
/*  47 */     if (start && 
/*  48 */       this.code == -1) {
/*  49 */       this.code = generateCode();
/*     */     }
/*  51 */     register.add(this);
/*     */   }
/*     */   
/*     */   public void delete() {
/*  55 */     if (getPlayer() != null) {
/*  56 */       getPlayer().kickPlayer("§cBotRegister §7unregistered");
/*     */     }
/*  58 */     register.remove(this);
/*     */   }
/*     */   
/*     */   public int generateCode() {
/*  62 */     int code = (new Random()).nextInt(1000000) + 1;
/*  63 */     for (BotRegister br : register) {
/*  64 */       if (!br.equals(this) && 
/*  65 */         br.getCode() == code)
/*  66 */         return generateCode(); 
/*     */     } 
/*  68 */     return code;
/*     */   }
/*     */   
/*     */   public int getCode() {
/*  72 */     return this.code;
/*     */   }
/*     */   
/*     */   public String getKickMessage() {
/*  76 */     return ConfigMessages.BOTS_DISCORD_NOT_REGISTERED_DISCORD.getValue().replace("%code%", String.valueOf(getCode()));
/*     */   }
/*     */   
/*     */   public Member getMember() {
/*     */     try {
/*  81 */       return Main.getBotLauncher().getDiscordbot().getMainGuild().getMemberById(this.userId);
/*  82 */     } catch (Exception e) {
/*  83 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Player getPlayer() {
/*  88 */     return Bukkit.getPlayer(UUID.fromString(this.uuid));
/*     */   }
/*     */   
/*     */   public String getPlayerName() {
/*  92 */     return this.name;
/*     */   }
/*     */   
/*     */   public long getUserId() {
/*  96 */     return this.userId;
/*     */   }
/*     */   
/*     */   public String getUUID() {
/* 100 */     return this.uuid;
/*     */   }
/*     */   
/*     */   public boolean isActive() {
/* 104 */     if (this.bypass) {
/* 105 */       return true;
/*     */     }
/* 107 */     return (this.userId > 0L);
/*     */   }
/*     */   
/*     */   public boolean isBypass() {
/* 111 */     return this.bypass;
/*     */   }
/*     */   
/*     */   public void setBypass(boolean bypass) {
/* 115 */     this.bypass = bypass;
/*     */   }
/*     */   
/*     */   public void setCode(int code) {
/* 119 */     this.code = code;
/*     */   }
/*     */   
/*     */   public void setPlayerName(String name) {
/* 123 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void setUserId(long user) {
/* 127 */     this.userId = user;
/*     */   }
/*     */   
/*     */   private static void loadAll() {
/* 131 */     if (!ConfigSetting.DISCORDBOT_VERIFYSYSTEM.getValueAsBoolean()) {
/*     */       return;
/*     */     }
/* 134 */     if (ConfigSetting.DISCORDBOT_USE_VERIFYSTSTEM_MYSQL.getValueAsBoolean()) {
/* 135 */       if (!Main.getDataManager().getMysqlClient().isConnected()) {
/* 136 */         System.err.println(String.valueOf(Main.getConsolePrefix()) + "Failed to load BotRegister!");
/*     */         
/*     */         return;
/*     */       } 
/* 140 */       ResultSet rs = Main.getDataManager().getMysqlClient().getQuery("SELECT * FROM verify");
/*     */       
/*     */       try {
/* 143 */         while (rs.next()) {
/* 144 */           String uuid = rs.getString("uuid");
/* 145 */           BotRegister reg = new BotRegister(uuid, false);
/*     */           
/*     */           try {
/* 148 */             reg.setUserId(rs.getLong("userid"));
/* 149 */           } catch (Exception e) {
/* 150 */             reg.setUserId(-1L);
/*     */           } 
/*     */           
/* 153 */           reg.setCode(rs.getInt("code"));
/* 154 */           reg.setBypass(rs.getBoolean("bypass"));
/* 155 */           reg.setPlayerName(rs.getString("name"));
/*     */           
/* 157 */           if (Bukkit.getPlayer(UUID.fromString(uuid)) != null && !reg.isActive())
/* 158 */             Bukkit.getPlayer(UUID.fromString(uuid)).kickPlayer(reg.getKickMessage()); 
/*     */         } 
/* 160 */       } catch (SQLException e) {
/* 161 */         e.printStackTrace();
/*     */       } 
/*     */     } else {
/*     */       
/* 165 */       File file = new File("plugins/Varo", "registrations.yml");
/* 166 */       YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
/*     */       
/* 168 */       for (String key : cfg.getKeys(true)) {
/* 169 */         if (!key.contains(".userId")) {
/*     */           continue;
/*     */         }
/* 172 */         String uuid = key.replace(".userId", "");
/* 173 */         BotRegister reg = new BotRegister(uuid, false);
/*     */         
/*     */         try {
/* 176 */           reg.setUserId(cfg.getLong(String.valueOf(uuid) + ".userId"));
/* 177 */         } catch (Exception e) {
/* 178 */           reg.setUserId(-1L);
/*     */         } 
/*     */         
/* 181 */         reg.setBypass(cfg.getBoolean(String.valueOf(uuid) + ".bypass"));
/* 182 */         reg.setCode(cfg.getInt(String.valueOf(uuid) + ".code"));
/* 183 */         reg.setPlayerName(cfg.getString(String.valueOf(uuid) + ".name"));
/*     */         
/* 185 */         if (Bukkit.getPlayer(UUID.fromString(uuid)) != null && !reg.isActive())
/* 186 */           Bukkit.getPlayer(UUID.fromString(uuid)).kickPlayer(reg.getKickMessage()); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ArrayList<BotRegister> getBotRegister() {
/* 192 */     return register;
/*     */   }
/*     */   
/*     */   public static BotRegister getBotRegisterByPlayerName(String name) {
/* 196 */     for (BotRegister br : register) {
/* 197 */       if (br.getPlayerName() != null && 
/* 198 */         br.getPlayerName().equals(name))
/* 199 */         return br; 
/* 200 */     }  return null;
/*     */   }
/*     */   
/*     */   public static BotRegister getRegister(String uuid) {
/* 204 */     for (BotRegister br : register) {
/* 205 */       if (br.getUUID().equals(uuid))
/* 206 */         return br; 
/*     */     } 
/* 208 */     return null;
/*     */   }
/*     */   
/*     */   public static BotRegister getRegister(User user) {
/* 212 */     for (BotRegister br : register) {
/* 213 */       if (br.getUserId() == user.getIdLong())
/* 214 */         return br; 
/* 215 */     }  return null;
/*     */   }
/*     */   
/*     */   public static void saveAll() {
/* 219 */     if (!ConfigSetting.DISCORDBOT_VERIFYSYSTEM.getValueAsBoolean()) {
/*     */       return;
/*     */     }
/* 222 */     if (ConfigSetting.DISCORDBOT_USE_VERIFYSTSTEM_MYSQL.getValueAsBoolean()) {
/* 223 */       if (!Main.getDataManager().getMysqlClient().isConnected()) {
/*     */         return;
/*     */       }
/* 226 */       Main.getDataManager().getMysqlClient().update("TRUNCATE TABLE verify;");
/*     */       
/* 228 */       for (BotRegister reg : register) {
/* 229 */         Main.getDataManager().getMysqlClient().update("INSERT INTO verify (uuid, userid, code, bypass, name) VALUES ('" + reg.getUUID() + "', " + ((reg.getUserId() != -1L) ? (String)Long.valueOf(reg.getUserId()) : "null") + ", " + reg.getCode() + ", " + reg.isBypass() + ", '" + ((reg.getPlayerName() == null) ? "null" : reg.getPlayerName()) + "');");
/*     */       }
/*     */     } else {
/* 232 */       File file = new File("plugins/Varo", "registrations.yml");
/* 233 */       YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
/*     */       
/* 235 */       for (String s : cfg.getKeys(true)) {
/* 236 */         cfg.set(s, null);
/*     */       }
/* 238 */       for (BotRegister reg : register) {
/* 239 */         cfg.set(String.valueOf(reg.getUUID()) + ".userId", (reg.getUserId() != -1L) ? Long.valueOf(reg.getUserId()) : "null");
/* 240 */         cfg.set(String.valueOf(reg.getUUID()) + ".code", Integer.valueOf(reg.getCode()));
/* 241 */         cfg.set(String.valueOf(reg.getUUID()) + ".bypass", Boolean.valueOf(reg.isBypass()));
/* 242 */         cfg.set(String.valueOf(reg.getUUID()) + ".name", (reg.getPlayerName() == null) ? "null" : reg.getPlayerName());
/*     */       } 
/*     */       
/*     */       try {
/* 246 */         cfg.save(file);
/* 247 */       } catch (IOException e) {
/* 248 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\bot\discord\register\BotRegister.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */