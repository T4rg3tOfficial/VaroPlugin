/*    */ package de.cuuky.varo.bot.discord.commands;
/*    */ 
/*    */ import de.cuuky.varo.bot.discord.DiscordBotCommand;
/*    */ import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HelpCommand
/*    */   extends DiscordBotCommand
/*    */ {
/*    */   public HelpCommand() {
/* 13 */     super("help", new String[] { "commands" }, "Zeigt alle Befehle des DiscordBots an");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable(String[] args, MessageReceivedEvent event) {
/* 18 */     String cmds = "";
/* 19 */     for (DiscordBotCommand cmd : DiscordBotCommand.getCommands()) {
/* 20 */       String aliases = ""; byte b; int i; String[] arrayOfString;
/* 21 */       for (i = (arrayOfString = cmd.getAliases()).length, b = 0; b < i; ) { String a = arrayOfString[b];
/* 22 */         if (aliases.equals(""))
/* 23 */         { aliases = a; }
/*    */         else
/* 25 */         { aliases = String.valueOf(aliases) + ", " + a; }  b++; }
/* 26 */        cmds = String.valueOf(cmds) + "\n" + cmd.getName() + ":\n" + "  Aliases: " + aliases + "\n  Description: " + cmd.getDescription();
/*    */     } 
/*    */     
/* 29 */     getDiscordBot().sendRawMessage("``` Hier eine Übersicht aller Commands: " + cmds + "```", event.getTextChannel());
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\bot\discord\commands\HelpCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */