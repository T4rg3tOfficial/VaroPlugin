/*    */ package de.cuuky.varo.bot.discord.commands;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.bot.discord.DiscordBotCommand;
/*    */ import de.cuuky.varo.bot.discord.register.BotRegister;
/*    */ import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.OfflinePlayer;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShutdownCommand
/*    */   extends DiscordBotCommand
/*    */ {
/*    */   public ShutdownCommand() {
/* 18 */     super("shutdown", new String[] { "disconnect" }, "Faehrt den Bot herunter.");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onEnable(String[] args, MessageReceivedEvent event) {
/*    */     try {
/* 25 */       if (BotRegister.getRegister(event.getAuthor()) == null) {
/* 26 */         event.getTextChannel().sendMessage("Du musst mit dem Bot authentifiziert sein!").queue();
/*    */         
/*    */         return;
/*    */       } 
/* 30 */       BotRegister reg = BotRegister.getRegister(event.getAuthor());
/*    */       try {
/* 32 */         if (Bukkit.getOfflinePlayer(reg.getPlayerName()) == null) {
/* 33 */           event.getTextChannel().sendMessage("Spieler nicht gefunden!").queue();
/*    */           return;
/*    */         } 
/* 36 */       } catch (NullPointerException e) {
/*    */         return;
/*    */       } 
/*    */       
/* 40 */       OfflinePlayer player = Bukkit.getOfflinePlayer(reg.getPlayerName());
/* 41 */       if (!player.isOp()) {
/* 42 */         event.getTextChannel().sendMessage("Dazu bist du nicht berechtigt!").queue();
/*    */         
/*    */         return;
/*    */       } 
/* 46 */       event.getTextChannel().sendMessage("Bye, bye.").queue();
/* 47 */       Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*    */           {
/*    */             public void run()
/*    */             {
/* 51 */               ShutdownCommand.this.getDiscordBot().disconnect();
/*    */             }
/* 53 */           },  20L);
/* 54 */     } catch (Exception e) {
/* 55 */       getDiscordBot().disconnect();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\bot\discord\commands\ShutdownCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */