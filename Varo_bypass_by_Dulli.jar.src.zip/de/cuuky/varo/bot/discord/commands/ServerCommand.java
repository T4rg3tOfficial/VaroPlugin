/*    */ package de.cuuky.varo.bot.discord.commands;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.bot.discord.DiscordBotCommand;
/*    */ import java.awt.Color;
/*    */ import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
/*    */ import org.bukkit.Bukkit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerCommand
/*    */   extends DiscordBotCommand
/*    */ {
/*    */   public ServerCommand() {
/* 18 */     super("server", new String[] { "status", "whitelist" }, "Zeigt Infos und Status des Servers");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable(String[] args, MessageReceivedEvent event) {
/* 23 */     getDiscordBot().sendMessage("IP: " + Bukkit.getServer().getIp() + ":" + Bukkit.getServer().getPort() + "\n  Whitelist: " + Bukkit.getServer().hasWhitelist() + "\n  GameState: " + Main.getVaroGame().getGameState().toString(), "SERVER INFO", Color.BLUE, event.getTextChannel());
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\bot\discord\commands\ServerCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */