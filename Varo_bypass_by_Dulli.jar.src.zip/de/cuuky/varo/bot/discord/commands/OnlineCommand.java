/*    */ package de.cuuky.varo.bot.discord.commands;
/*    */ 
/*    */ import de.cuuky.varo.bot.discord.DiscordBotCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import java.awt.Color;
/*    */ import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OnlineCommand
/*    */   extends DiscordBotCommand
/*    */ {
/*    */   public OnlineCommand() {
/* 16 */     super("online", new String[] { "onlineplayers" }, "Zeigt alle Spieler an, die online sind");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable(String[] args, MessageReceivedEvent event) {
/* 21 */     if (VaroPlayer.getOnlinePlayer().size() == 0) {
/* 22 */       getDiscordBot().sendMessage("Es sind keine Spieler online!", "ERROR", Color.RED, event.getTextChannel());
/*    */       
/*    */       return;
/*    */     } 
/* 26 */     String players = "";
/* 27 */     for (VaroPlayer vp : VaroPlayer.getOnlinePlayer()) {
/* 28 */       if (players.equals("")) {
/* 29 */         players = vp.getName(); continue;
/*    */       } 
/* 31 */       players = String.valueOf(players) + ", " + vp.getName();
/*    */     } 
/*    */     
/* 34 */     getDiscordBot().sendRawMessage("ONLINE (" + VaroPlayer.getOnlinePlayer().size() + ") \n\n" + players, event.getTextChannel());
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\bot\discord\commands\OnlineCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */