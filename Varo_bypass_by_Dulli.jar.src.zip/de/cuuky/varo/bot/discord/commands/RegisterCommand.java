/*    */ package de.cuuky.varo.bot.discord.commands;
/*    */ 
/*    */ import de.cuuky.varo.bot.discord.DiscordBotCommand;
/*    */ import de.cuuky.varo.bot.discord.register.BotRegister;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import java.awt.Color;
/*    */ import net.dv8tion.jda.api.entities.TextChannel;
/*    */ import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegisterCommand
/*    */   extends DiscordBotCommand
/*    */ {
/*    */   public RegisterCommand() {
/* 18 */     super("register", new String[] { "verify", "link" }, "Registriert dich per Code mit dem Discordbot");
/*    */   }
/*    */   
/*    */   public void onEnable(String[] args, MessageReceivedEvent event) {
/*    */     int code;
/* 23 */     if (event.getAuthor().isBot() || event.getAuthor().equals(getDiscordBot().getJda().getSelfUser())) {
/*    */       return;
/*    */     }
/* 26 */     if (!ConfigSetting.DISCORDBOT_VERIFYSYSTEM.getValueAsBoolean()) {
/* 27 */       getDiscordBot().sendMessage("Das Verify-System ist nicht aktiviert!", "ERROR", Color.RED, event.getTextChannel());
/*    */       
/*    */       return;
/*    */     } 
/* 31 */     if (getDiscordBot().getRegisterChannel() != null && 
/* 32 */       getDiscordBot().getRegisterChannel().getIdLong() != event.getTextChannel().getIdLong()) {
/* 33 */       getDiscordBot().sendMessage("Bitte nutze den " + getDiscordBot().getRegisterChannel().getAsMention() + " Channel zum verifizieren, " + event.getAuthor().getAsMention() + "!", "ERROR", Color.RED, event.getTextChannel());
/*    */       
/*    */       return;
/*    */     } 
/* 37 */     TextChannel channel = event.getTextChannel();
/*    */     
/* 39 */     if (args.length == 0) {
/* 40 */       getDiscordBot().sendMessage("Usage: '" + ConfigSetting.DISCORDBOT_COMMANDTRIGGER.getValueAsString() + "verify <Code>' " + event.getAuthor().getAsMention(), "ERROR", Color.RED, event.getTextChannel());
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/*    */     try {
/* 46 */       code = Integer.valueOf(args[0]).intValue();
/* 47 */     } catch (Exception e) {
/* 48 */       getDiscordBot().sendMessage("Usage: '" + ConfigSetting.DISCORDBOT_COMMANDTRIGGER.getValueAsString() + "verify <Code>' " + event.getAuthor().getAsMention(), "ERROR", Color.RED, event.getTextChannel());
/*    */       
/*    */       return;
/*    */     } 
/* 52 */     for (BotRegister reg : BotRegister.getBotRegister()) {
/* 53 */       if (reg.isActive() && reg.getUserId() == event.getAuthor().getIdLong()) {
/* 54 */         channel.sendMessage("Discord Account already used! " + event.getAuthor().getAsMention()).queue();
/*    */         return;
/*    */       } 
/*    */     } 
/* 58 */     for (BotRegister reg : BotRegister.getBotRegister()) {
/* 59 */       if (reg.getCode() == code && !reg.isActive()) {
/* 60 */         reg.setUserId(Long.valueOf(event.getAuthor().getId()).longValue());
/* 61 */         getDiscordBot().sendMessage("Discord Account '" + event.getAuthor().getAsMention() + "' successfully linked with the MC-Account '" + reg.getPlayerName() + "'!", "SUCCESS", Color.GREEN, event.getTextChannel());
/* 62 */         reg.setCode(reg.generateCode());
/*    */         
/*    */         return;
/*    */       } 
/*    */     } 
/* 67 */     getDiscordBot().sendMessage("Code not found!", "ERROR", Color.RED, event.getTextChannel());
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\bot\discord\commands\RegisterCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */