/*    */ package de.cuuky.varo.bot.discord.commands;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.bot.discord.DiscordBotCommand;
/*    */ import de.cuuky.varo.bot.discord.register.BotRegister;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import java.awt.Color;
/*    */ import net.dv8tion.jda.api.entities.User;
/*    */ import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetLinkCommand
/*    */   extends DiscordBotCommand
/*    */ {
/*    */   public GetLinkCommand() {
/* 19 */     super("getLink", new String[] { "getVerify" }, "Gibt den verlinkten MC-Account des Spielers zurueck.");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable(String[] args, MessageReceivedEvent event) {
/* 24 */     if (args.length != 1 && event.getMessage().getMentionedUsers().size() == 0) {
/* 25 */       event.getTextChannel().sendMessage("varo getLink <User / MC-Name>").queue();
/*    */       
/*    */       return;
/*    */     } 
/* 29 */     if (!ConfigSetting.DISCORDBOT_VERIFYSYSTEM.getValueAsBoolean()) {
/* 30 */       event.getChannel().sendMessage("Das Verifzierungs-System wurde in der Config deaktiviert!").queue();
/*    */       
/*    */       return;
/*    */     } 
/* 34 */     BotRegister reg = null;
/* 35 */     if (event.getMessage().getMentionedUsers().size() != 0) {
/* 36 */       BotRegister.getRegister(event.getMessage().getMentionedUsers().get(0));
/*    */     } else {
/*    */       try {
/* 39 */         reg = BotRegister.getRegister(getDiscordBot().getJda().getUsersByName(args[0], true).get(0));
/* 40 */       } catch (Exception exception) {}
/*    */     } 
/* 42 */     if (reg == null) {
/* 43 */       event.getChannel().sendMessage(String.valueOf(Main.getPrefix()) + "Der Spieler " + args[0] + " hat den Server noch nie betreten!").queue();
/*    */       
/*    */       return;
/*    */     } 
/* 47 */     User user = getDiscordBot().getJda().getUserById(reg.getUserId());
/* 48 */     if (user == null) {
/* 49 */       event.getChannel().sendMessage(String.valueOf(Main.getPrefix()) + "User fuer diesen Spieler nicht gefunden!").queue();
/*    */       
/*    */       return;
/*    */     } 
/* 53 */     getDiscordBot().sendMessage("Der MC-Account von " + user.getAsMention() + " lautet " + reg.getPlayerName() + "!", "GET LINK", Color.BLUE, event.getTextChannel());
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\bot\discord\commands\GetLinkCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */