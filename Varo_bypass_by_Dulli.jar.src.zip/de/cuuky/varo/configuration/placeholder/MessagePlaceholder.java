/*    */ package de.cuuky.varo.configuration.placeholder;
/*    */ 
/*    */ import de.cuuky.varo.configuration.placeholder.placeholder.GeneralMessagePlaceholder;
/*    */ import de.cuuky.varo.configuration.placeholder.placeholder.PlayerMessagePlaceholder;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MessagePlaceholder
/*    */ {
/* 13 */   private static ArrayList<MessagePlaceholder> placeholders = new ArrayList<>();
/*    */   
/*    */   protected String identifier;
/*    */   
/*    */   protected String description;
/*    */   protected int defaultRefresh;
/*    */   protected int refreshDelay;
/*    */   
/*    */   public MessagePlaceholder(String identifier, int refreshDelay, String description) {
/* 22 */     this(identifier, refreshDelay, false, description);
/*    */   }
/*    */   
/*    */   public MessagePlaceholder(String identifier, int refreshDelay, boolean rawIdentifier, String description) {
/* 26 */     if (rawIdentifier) {
/* 27 */       this.identifier = identifier;
/*    */     } else {
/* 29 */       this.identifier = "%" + identifier + "%";
/*    */     } 
/* 31 */     this.description = description;
/* 32 */     this.defaultRefresh = refreshDelay;
/* 33 */     this.refreshDelay = refreshDelay * 1000 - 100;
/*    */     
/* 35 */     placeholders.add(this);
/*    */   }
/*    */   
/*    */   public boolean containsPlaceholder(String message) {
/* 39 */     return message.contains(this.identifier);
/*    */   }
/*    */   
/*    */   public String getIdentifier() {
/* 43 */     return this.identifier;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 47 */     return this.description;
/*    */   }
/*    */   
/*    */   public int getDefaultRefresh() {
/* 51 */     return this.defaultRefresh;
/*    */   }
/*    */   
/*    */   public abstract void clearValue();
/*    */   
/*    */   public static void clearPlaceholder() {
/* 57 */     GeneralMessagePlaceholder.clearCache();
/* 58 */     PlayerMessagePlaceholder.clearCache();
/*    */     
/* 60 */     for (MessagePlaceholder placeholder : placeholders)
/* 61 */       placeholder.clearValue(); 
/*    */   }
/*    */   
/*    */   public static ArrayList<MessagePlaceholder> getPlaceholders() {
/* 65 */     return placeholders;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\configuration\placeholder\MessagePlaceholder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */