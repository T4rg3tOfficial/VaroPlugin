/*    */ package de.cuuky.varo.configuration.placeholder.placeholder;
/*    */ 
/*    */ import de.cuuky.varo.configuration.placeholder.MessagePlaceholder;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PlayerMessagePlaceholder
/*    */   extends MessagePlaceholder
/*    */ {
/*    */   private static ArrayList<PlayerMessagePlaceholder> playerPlaceholder;
/* 15 */   private static HashMap<String, ArrayList<PlayerMessagePlaceholder>> cachedRequests = new HashMap<>();
/*    */   
/*    */   private HashMap<VaroPlayer, String> placeholderValues;
/*    */   
/*    */   private HashMap<VaroPlayer, Long> placeholderRefreshes;
/*    */   
/*    */   public PlayerMessagePlaceholder(String identifier, int refreshDelay, String description) {
/* 22 */     super(identifier, refreshDelay, description);
/*    */     
/* 24 */     this.placeholderValues = new HashMap<>();
/* 25 */     this.placeholderRefreshes = new HashMap<>();
/*    */     
/* 27 */     if (playerPlaceholder == null) {
/* 28 */       playerPlaceholder = new ArrayList<>();
/*    */     }
/* 30 */     playerPlaceholder.add(this);
/*    */   }
/*    */   
/*    */   private void checkRefresh(VaroPlayer player) {
/* 34 */     if (!shallRefresh(player)) {
/*    */       return;
/*    */     }
/* 37 */     refreshValue(player);
/*    */   }
/*    */   
/*    */   private boolean shallRefresh(VaroPlayer player) {
/* 41 */     if (!this.placeholderRefreshes.containsKey(player)) {
/* 42 */       return true;
/*    */     }
/* 44 */     return (this.refreshDelay < 1) ? false : ((((Long)this.placeholderRefreshes.get(player)).longValue() + this.refreshDelay <= System.currentTimeMillis()));
/*    */   }
/*    */   
/*    */   private void refreshValue(VaroPlayer player) {
/* 48 */     this.placeholderValues.put(player, getValue(player));
/* 49 */     this.placeholderRefreshes.put(player, Long.valueOf(System.currentTimeMillis()));
/*    */   }
/*    */   
/*    */   protected abstract String getValue(VaroPlayer paramVaroPlayer);
/*    */   
/*    */   public String replacePlaceholder(String message, VaroPlayer player) {
/* 55 */     checkRefresh(player);
/*    */     
/* 57 */     return message.replace(this.identifier, this.placeholderValues.get(player));
/*    */   }
/*    */ 
/*    */   
/*    */   public void clearValue() {
/* 62 */     this.placeholderValues.clear();
/* 63 */     this.placeholderRefreshes.clear();
/*    */   }
/*    */   
/*    */   private static Object[] replaceByList(String value, VaroPlayer vp, ArrayList<PlayerMessagePlaceholder> list) {
/* 67 */     ArrayList<PlayerMessagePlaceholder> cached = new ArrayList<>();
/* 68 */     for (PlayerMessagePlaceholder pmp : list) {
/* 69 */       if (pmp.containsPlaceholder(value)) {
/* 70 */         value = pmp.replacePlaceholder(value, vp);
/* 71 */         cached.add(pmp);
/*    */       } 
/*    */     } 
/* 74 */     return new Object[] { value, cached };
/*    */   }
/*    */   
/*    */   public static String replacePlaceholders(String value, VaroPlayer vp) {
/* 78 */     if (cachedRequests.get(value) != null) {
/* 79 */       return (String)replaceByList(value, vp, (ArrayList)cachedRequests.get(value))[0];
/*    */     }
/* 81 */     Object[] result = replaceByList(value, vp, playerPlaceholder);
/* 82 */     cachedRequests.put(value, (ArrayList<PlayerMessagePlaceholder>)result[1]);
/* 83 */     return (String)result[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public static void clearCache() {
/* 88 */     cachedRequests.clear();
/*    */   }
/*    */   
/*    */   public static ArrayList<PlayerMessagePlaceholder> getPlayerPlaceholder() {
/* 92 */     return playerPlaceholder;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\configuration\placeholder\placeholder\PlayerMessagePlaceholder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */