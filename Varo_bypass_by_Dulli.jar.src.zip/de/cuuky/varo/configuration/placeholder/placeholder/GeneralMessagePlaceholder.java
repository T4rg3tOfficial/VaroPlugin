/*     */ package de.cuuky.varo.configuration.placeholder.placeholder;
/*     */ 
/*     */ import de.cuuky.varo.configuration.placeholder.MessagePlaceholder;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GeneralMessagePlaceholder
/*     */   extends MessagePlaceholder
/*     */ {
/*     */   private static ArrayList<GeneralMessagePlaceholder> generalPlaceholder;
/*  16 */   private static HashMap<String, ArrayList<GeneralMessagePlaceholder>> cachedRequests = new HashMap<>();
/*     */   
/*     */   private static long lastDateRefreshTime;
/*     */   
/*     */   private static String[] lastDateRefresh;
/*     */   
/*     */   private String value;
/*     */   protected long lastRefresh;
/*     */   
/*     */   public GeneralMessagePlaceholder(String identifier, int refreshDelay, String description) {
/*  26 */     this(identifier, refreshDelay, false, description);
/*     */   }
/*     */   
/*     */   public GeneralMessagePlaceholder(String identifier, int refreshDelay, boolean rawIdentifier, String description) {
/*  30 */     super(identifier, refreshDelay, rawIdentifier, description);
/*     */     
/*  32 */     if (generalPlaceholder == null) {
/*  33 */       generalPlaceholder = new ArrayList<>();
/*     */     }
/*  35 */     this.lastRefresh = 0L;
/*     */     
/*  37 */     generalPlaceholder.add(this);
/*     */   }
/*     */   
/*     */   private void checkRefresh() {
/*  41 */     if (!shallRefresh()) {
/*     */       return;
/*     */     }
/*  44 */     refreshValue();
/*     */   }
/*     */   
/*     */   private void refreshValue() {
/*  48 */     this.value = getValue();
/*  49 */     this.lastRefresh = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */   private boolean shallRefresh() {
/*  53 */     return (this.refreshDelay < 1 && this.value != null) ? false : ((this.lastRefresh + this.refreshDelay <= System.currentTimeMillis()));
/*     */   }
/*     */   
/*     */   protected abstract String getValue();
/*     */   
/*     */   public String replacePlaceholder(String message) {
/*  59 */     checkRefresh();
/*     */     
/*  61 */     return message.replace(this.identifier, this.value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearValue() {
/*  66 */     this.value = null;
/*  67 */     this.lastRefresh = 0L;
/*     */   }
/*     */   
/*     */   protected static String getLastDateRefresh(int index) {
/*  71 */     if (lastDateRefresh == null || lastDateRefreshTime + 1000L <= System.currentTimeMillis()) {
/*  72 */       lastDateRefreshTime = System.currentTimeMillis();
/*  73 */       lastDateRefresh = (new SimpleDateFormat("yyyy,MM,dd,HH,mm,ss")).format(new Date()).split(",");
/*     */     } 
/*     */     
/*  76 */     return lastDateRefresh[index];
/*     */   }
/*     */   
/*     */   private static Object[] replaceByList(String value, ArrayList<GeneralMessagePlaceholder> list) {
/*  80 */     ArrayList<GeneralMessagePlaceholder> cached = new ArrayList<>();
/*  81 */     for (GeneralMessagePlaceholder pmp : list) {
/*  82 */       if (pmp.containsPlaceholder(value)) {
/*  83 */         value = pmp.replacePlaceholder(value);
/*  84 */         cached.add(pmp);
/*     */       } 
/*     */     } 
/*  87 */     return new Object[] { value, cached };
/*     */   }
/*     */   
/*     */   public static String replacePlaceholders(String value) {
/*  91 */     if (cachedRequests.get(value) != null) {
/*  92 */       return (String)replaceByList(value, (ArrayList)cachedRequests.get(value))[0];
/*     */     }
/*  94 */     Object[] result = replaceByList(value, generalPlaceholder);
/*  95 */     cachedRequests.put(value, (ArrayList<GeneralMessagePlaceholder>)result[1]);
/*  96 */     return (String)result[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public static void clearCache() {
/* 101 */     cachedRequests.clear();
/*     */   }
/*     */   
/*     */   public static ArrayList<GeneralMessagePlaceholder> getGeneralPlaceholderMatching() {
/* 105 */     return generalPlaceholder;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\configuration\placeholder\placeholder\GeneralMessagePlaceholder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */