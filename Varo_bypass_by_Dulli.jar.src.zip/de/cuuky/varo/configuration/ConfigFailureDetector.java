/*    */ package de.cuuky.varo.configuration;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.configuration.InvalidConfigurationException;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ import org.yaml.snakeyaml.scanner.ScannerException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ConfigFailureDetector
/*    */ {
/* 19 */   private static ArrayList<String> ignoreScan = new ArrayList<>(); private boolean failed;
/*    */   static {
/* 21 */     ignoreScan.add("logs");
/* 22 */     ignoreScan.add("presets");
/* 23 */     ignoreScan.add("legacy");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigFailureDetector() {
/* 29 */     detectConfig();
/*    */   }
/*    */   
/*    */   private void detectConfig() {
/* 33 */     File newFile = new File("plugins/Varo");
/* 34 */     if (newFile.listFiles() == null) {
/* 35 */       newFile.mkdir();
/*    */     }
/* 37 */     if (scanDirectory(newFile)) {
/* 38 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Configurations scanned for mistakes - mistakes have been found");
/* 39 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Plugin will get shut down.");
/*    */       
/* 41 */       this.failed = true;
/*    */     } else {
/* 43 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Configurations scanned for mistakes successfully!");
/*    */     }  } private boolean scanDirectory(File newFile) {
/*    */     byte b;
/*    */     int i;
/*    */     File[] arrayOfFile;
/* 48 */     for (i = (arrayOfFile = newFile.listFiles()).length, b = 0; b < i; ) { File file = arrayOfFile[b];
/* 49 */       if (file.isDirectory()) {
/* 50 */         if (!ignoreScan.contains(file.getName()))
/*    */         {
/*    */           
/* 53 */           if (scanDirectory(file)) {
/* 54 */             return true;
/*    */           
/*    */           }
/*    */         }
/*    */       }
/* 59 */       else if (file.getName().endsWith(".yml")) {
/*    */ 
/*    */ 
/*    */         
/* 63 */         try { (new YamlConfiguration()).load(file); }
/* 64 */         catch (NullPointerException e)
/* 65 */         { System.out.println(String.valueOf(Main.getConsolePrefix()) + "Odd config found, ignoring it"); }
/* 66 */         catch (ScannerException scannerException) {  } catch (FileNotFoundException fileNotFoundException) {  } catch (IOException iOException) {  } catch (InvalidConfigurationException e)
/* 67 */         { if (!e.getMessage().contains("deserialize")) {
/*    */ 
/*    */             
/* 70 */             System.err.println(String.valueOf(Main.getConsolePrefix()) + "Config failure detected!");
/* 71 */             System.err.println(String.valueOf(Main.getConsolePrefix()) + "File: " + file.getName());
/* 72 */             System.err.println(String.valueOf(Main.getConsolePrefix()) + "Usually the first information of the message gives you the location of the mistake. Just read the error and check the files.");
/* 73 */             System.err.println(String.valueOf(Main.getConsolePrefix()) + "Message: \n" + e.getMessage());
/* 74 */             return true;
/*    */           }  }
/*    */       
/*    */       }  b++; }
/* 78 */      return false;
/*    */   }
/*    */   
/*    */   public boolean hasFailed() {
/* 82 */     return this.failed;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\configuration\ConfigFailureDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */