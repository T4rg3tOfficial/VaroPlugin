/*    */ package de.cuuky.varo.configuration.configurations.messages;
/*    */ 
/*    */ import de.cuuky.varo.configuration.configurations.SectionConfiguration;
/*    */ import de.cuuky.varo.configuration.configurations.SectionEntry;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public enum ConfigMessageSection
/*    */   implements SectionConfiguration
/*    */ {
/* 10 */   ALERTS("alerts", "Nachrichten zu den Meldungen auf Discord, im Chat etc."),
/* 11 */   AUTOSTART("autostart", "Nachrichten zum AutoStart"),
/* 12 */   BOTS("bots", "Nachrichten, die die Bots ausgeben"),
/* 13 */   BORDER("border", "Nachrichten zu der Worldborder"),
/* 14 */   CHAT("chat", "Nachrichten zum Chat"),
/* 15 */   CHEST("chest", "Nachrichten zum Sichern von Kisten & Oefen"),
/* 16 */   COMBAT("combat", "Nachrichten zum Kampf"),
/* 17 */   COMMANDS("commands", "Nachrichten zu den Befehlen"),
/* 18 */   DEATH("death", "Nachrichten zum Tod eines Spielers"),
/* 19 */   GAME("game", "Nachrichten zum Spielverlauf"),
/* 20 */   KICK("kick", "Nachrichten zum Kick eines Spielers"),
/* 21 */   MOTD("motd", "Nachrichten zur Motd des Servers"),
/* 22 */   LABYMOD("labymod", "Nachrichten zu den LabyMod-Einstellungen"),
/* 23 */   OTHER("other", "Andere Nachrichten"),
/* 24 */   SPECTATOR("spectator", "Nachrichten zu den Zuschauern"),
/* 25 */   SPAWNS("spawns", "Nachrichten fuer die Spawns"),
/* 26 */   PROTECTION("protection", "Nachrichten fuer die Schutzzeiten"),
/* 27 */   SORT("sort", "Nachrichten zur Sortierung der Spieler"),
/* 28 */   NAMETAG("nametag", "Nachrichten zu den Nametags der Spieler"),
/* 29 */   TABLIST("tablist", "Nachrichten zur Modifizierung der Tablist"),
/* 30 */   TEAMREQUEST("teamrequest", "Nachrichten zu den Teameinladungen"),
/* 31 */   NOPERMISSION("nopermission", "Nachrichten fuer unzureichende Berechtigungen"),
/* 32 */   QUITMESSAGE("quitmessage", "Nachrichten fuer das Verlassen des Servers"),
/* 33 */   SPAWN("spawn", "Nachrichten zum Worldspawn"),
/* 34 */   JOINMESSAGE("joinmessage", "Nachrichten zum Betreteten des Servers"); private String name;
/*    */   private String description;
/*    */   
/*    */   ConfigMessageSection(String path, String description) {
/* 38 */     this.name = path;
/* 39 */     this.description = description;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 44 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 49 */     return this.description;
/*    */   }
/*    */ 
/*    */   
/*    */   public ArrayList<SectionEntry> getEntries() {
/* 54 */     ArrayList<SectionEntry> temp = new ArrayList<>(); byte b; int i; ConfigMessages[] arrayOfConfigMessages;
/* 55 */     for (i = (arrayOfConfigMessages = ConfigMessages.values()).length, b = 0; b < i; ) { ConfigMessages message = arrayOfConfigMessages[b];
/* 56 */       if (message.getSection().equals(this))
/*    */       {
/*    */         
/* 59 */         temp.add(message); } 
/*    */       b++; }
/*    */     
/* 62 */     return temp;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\configuration\configurations\messages\ConfigMessageSection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */