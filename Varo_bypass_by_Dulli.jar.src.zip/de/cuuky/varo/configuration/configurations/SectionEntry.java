package de.cuuky.varo.configuration.configurations;

public interface SectionEntry {
  Object getDefaultValue();
  
  Object getValue();
  
  String getPath();
  
  String getFullPath();
  
  String[] getDescription();
  
  void setValue(Object paramObject);
  
  SectionConfiguration getSection();
}


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\configuration\configurations\SectionEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */