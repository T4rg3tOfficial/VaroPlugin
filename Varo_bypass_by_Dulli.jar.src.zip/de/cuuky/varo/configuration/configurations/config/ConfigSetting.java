/*     */ package de.cuuky.varo.configuration.configurations.config;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.SectionConfiguration;
/*     */ import de.cuuky.varo.configuration.configurations.SectionEntry;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import org.bukkit.Bukkit;
/*     */ 
/*     */ public enum ConfigSetting
/*     */   implements SectionEntry {
/*  12 */   ADD_TEAM_LIFE_ON_KILL(ConfigSettingSection.DEATH, "addTeamLifesOnKill", Integer.valueOf(-1), "Wie viele Leben ein Team bekommen soll,\nsobald es einen Spieler toetet."),
/*  13 */   ALWAYS_TIME(ConfigSettingSection.WORLD, "setAlwaysTime", Integer.valueOf(1000), "Setzt die Zeit auf dem Server,\ndie dann so stehen bleibt.\nHinweis: Nacht = 13000, Tag = 1000", true),
/*  14 */   ALWAYS_TIME_USE_AFTER_START(ConfigSettingSection.WORLD, "alwaysTimeUseAfterStart", Boolean.valueOf(false), "Ob die Zeit auch stehen bleiben soll,\nwenn das Projekt gestartet wurde."),
/*  15 */   AUTOSETUP_BORDER(ConfigSettingSection.AUTOSETUP, "border", Integer.valueOf(2000), "Wie gross die Border beim\nAutoSetup gesetzt werden soll"),
/*     */   
/*  17 */   AUTOSETUP_ENABLED(
/*  18 */     ConfigSettingSection.AUTOSETUP, "enabled", Boolean.valueOf(false), "Wenn Autosetup aktiviert ist, werden beim\nStart des Servers alle Spawns automatisch gesetzt und\noptional ein Autostart eingerichtet."),
/*  19 */   AUTOSETUP_LOBBY_ENABLED(ConfigSettingSection.AUTOSETUP, "lobby.enabled", Boolean.valueOf(true), "Ob eine Lobby beim AutoSetup gespawnt werden soll"),
/*  20 */   AUTOSETUP_LOBBY_HEIGHT(ConfigSettingSection.AUTOSETUP, "lobby.height", Integer.valueOf(10), "Hoehe der Lobby, die gespawnt werden soll"),
/*  21 */   AUTOSETUP_LOBBY_SCHEMATIC(ConfigSettingSection.AUTOSETUP, "lobby.schematic", "plugins/Varo/schematics/lobby.schematic", "Schreibe hier den Pfad deiner Lobby-Schematic\nhin, die gepastet werden soll.\nHinweis: WorldEdit benoetigt"),
/*  22 */   AUTOSETUP_LOBBY_SIZE(ConfigSettingSection.AUTOSETUP, "lobby.size", Integer.valueOf(25), "Groesse der Lobby, die gespawnt werden soll"),
/*     */   
/*  24 */   AUTOSETUP_PORTAL_ENABLED(ConfigSettingSection.AUTOSETUP, "portal.enabled", Boolean.valueOf(true), "Ob ein Portal gespawnt werden soll"),
/*  25 */   AUTOSETUP_PORTAL_HEIGHT(ConfigSettingSection.AUTOSETUP, "portal.height", Integer.valueOf(5), "Hoehe des gespawnten Portals"),
/*  26 */   AUTOSETUP_PORTAL_WIDTH(ConfigSettingSection.AUTOSETUP, "portal.width", Integer.valueOf(4), "Breite des gespawnten Portals"),
/*     */   
/*  28 */   AUTOSETUP_SPAWNS_AMOUNT(ConfigSettingSection.AUTOSETUP, "spawns.amount", Integer.valueOf(40), "Zu welcher Anzahl die Loecher\ngeneriert werden sollen"),
/*  29 */   AUTOSETUP_SPAWNS_BLOCKID(ConfigSettingSection.AUTOSETUP, "spawns.block.material", "STONE_BRICK_SLAB", "Welche Block-ID der Halftstep am Spawn haben soll"),
/*  30 */   AUTOSETUP_SPAWNS_RADIUS(ConfigSettingSection.AUTOSETUP, "spawns.radius", Integer.valueOf(30), "In welchem Radius die Loecher\ngeneriert werden sollen"),
/*  31 */   AUTOSETUP_SPAWNS_SIDEBLOCKID(ConfigSettingSection.AUTOSETUP, "spawns.sideblock.material", VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_13) ? "GRASS_BLOCK" : "GRASS", "Welche Block-ID der Block,\nden man abbaut haben soll"),
/*  32 */   AUTOSETUP_TIME_HOUR(ConfigSettingSection.AUTOSETUP, "autostart.time.hour", Integer.valueOf(-1), "Um welche Zeit der Stunde der\nAutoStart gesetzt werden soll"),
/*  33 */   AUTOSETUP_TIME_MINUTE(ConfigSettingSection.AUTOSETUP, "autostart.time.minute", Integer.valueOf(-1), "Um welche Zeit der Minute der\nAutoStart gesetzt werden soll"),
/*     */   
/*  35 */   BACKPACK_PLAYER_DROP_ON_DEATH(ConfigSettingSection.BACKPACKS, "backpackPlayerDropOnDeath", Boolean.valueOf(true), "Ob der Inhalt des Spieler-Rucksacks beim Tod des Spielers gedroppt werden soll."),
/*     */   
/*  37 */   BACKPACK_PLAYER_ENABLED(
/*  38 */     ConfigSettingSection.BACKPACKS, "backpackPlayerEnabled", Boolean.valueOf(false), "Wenn dies aktiviert ist, haben Spieler einen eigenen Rucksack,\nauf den sie mit /varo bp zugreifen koennen.\nDieser wird pro Spieler und nicht pro Team gespeichert."),
/*  39 */   BACKPACK_PLAYER_SIZE(ConfigSettingSection.BACKPACKS, "backpackPlayerSize", Integer.valueOf(54), "Groesse des Spieler-Rucksacks (Max = 54)"),
/*     */   
/*  41 */   BACKPACK_TEAM_DROP_ON_DEATH(ConfigSettingSection.BACKPACKS, "backpackTeamDropOnDeath", Boolean.valueOf(true), "Ob der Inhalt des Team-Rucksacks beim Tod des letzten Teammitglieds gedroppt werden soll."),
/*  42 */   BACKPACK_TEAM_ENABLED(ConfigSettingSection.BACKPACKS, "backpackTeamEnabled", Boolean.valueOf(false), "Wenn dies aktiviert ist, haben Teams einen eigenen Rucksack,\nauf den sie mit /varo bp zugreifen koennen.\nDieser wird pro Team und nicht pro Spieler gespeichert."),
/*     */   
/*  44 */   BACKPACK_TEAM_SIZE(ConfigSettingSection.BACKPACKS, "backpackTeamSize", Integer.valueOf(54), "Groesse des Team-Rucksacks (Max = 54)"),
/*  45 */   BAN_AFTER_DISCONNECT_MINUTES(ConfigSettingSection.DISCONNECT, "banAfterDisconnectMinutes", Integer.valueOf(-1), "Wenn ein Spieler disconnected,\nob er nach dieser Anzahl an Minuten entfernt werden soll.\nOff = -1"),
/*     */   
/*  47 */   BLOCK_CHAT_ADS(
/*  48 */     ConfigSettingSection.CHAT, "blockChatAds", Boolean.valueOf(true), "Wenn aktiviert, koennen keine Links in den oeffentlichen Chat gepostet werden."),
/*     */   
/*  50 */   WORLD_SPAWNS_GENERATE_Y_TOLERANCE(
/*  51 */     ConfigSettingSection.WORLD, "spawnGeneratorYTolerance", Integer.valueOf(4), "Wie viel Hoehe die Spawns von einander\nAbstand haben duerfen beim\ngenerieren der Spawns\nBeispiel: Spawn ist 10 Bloecke hoeher als andere\n->wird weiter nach Terrain gesucht"),
/*  52 */   BLOCK_DESTROY_LOGGER(ConfigSettingSection.WORLD, "blockDestroyLogger", Boolean.valueOf(true), "Loggt alle abgebauten Bloecke, die ihr\nunten eintragt unter 'oreLogger.yml'", true),
/*  53 */   BLOCK_USER_PORTALS(ConfigSettingSection.WORLD, "blockUserPortals", Boolean.valueOf(true), "Ob Spieler nicht ihre eigenen\nPortale bauen koennen"),
/*     */   
/*  55 */   BLOODLUST_DAYS(
/*  56 */     ConfigSettingSection.ACTIVITY, "noBloodlustDays", Integer.valueOf(-1), "Nach wie vielen Tagen ohne Gegnerkontakt\nder Spieler gemeldet werden soll.\nOff = -1"),
/*  57 */   BORDER_DAMAGE(ConfigSettingSection.BORDER, "borderDamage", Integer.valueOf(1), "Wie viel Schaden die Border\nin halben Herzen macht."),
/*     */   
/*  59 */   WORLD_SNCHRONIZE_BORDER(
/*  60 */     ConfigSettingSection.BORDER, "synchronizeBorders", Boolean.valueOf(true), "Ob die Groesse der Border\nfuer alle Welten zaehlen soll"),
/*  61 */   BORDER_DEATH_DECREASE(ConfigSettingSection.BORDER, "deathBorderDecrease.enabled", Boolean.valueOf(true), "Ob sich die Border bei Tod verringern soll"),
/*  62 */   BORDER_DEATH_DECREASE_SIZE(ConfigSettingSection.BORDER, "deathBorderDecrease.size", Integer.valueOf(25), "Um wie viele Bloecke sich die\nBorder bei Tod verringern soll."),
/*  63 */   BORDER_DEATH_DECREASE_SPEED(ConfigSettingSection.BORDER, "deathBorderDecrease.speed", Integer.valueOf(1), "Mit welcher Geschwindigkeit sich\ndie Border beiTod verringern soll."),
/*  64 */   BORDER_SIZE_IN_FINALE(ConfigSettingSection.FINALE, "borderSizeInFinale", Integer.valueOf(300), "Auf diese Groesse wird die Border beim Starten des Finales gestellt."),
/*     */   
/*  66 */   BORDER_TIME_DAY_DECREASE(ConfigSettingSection.BORDER, "dayBorderDecrease.enabled", Boolean.valueOf(true), "Ob sich die Border nach Tagen verringern soll"),
/*  67 */   BORDER_TIME_DAY_DECREASE_DAYS(ConfigSettingSection.BORDER, "dayBorderDecrease.days", Integer.valueOf(3), "Nach wie vielen Tagen sich\ndie Border verkleinern soll."),
/*  68 */   BORDER_TIME_DAY_DECREASE_SIZE(ConfigSettingSection.BORDER, "dayBorderDecrease.size", Integer.valueOf(50), "Um wieviel sich die Bordernach den\noben genannten Tagen verkleinern soll."),
/*  69 */   BORDER_TIME_DAY_DECREASE_SPEED(ConfigSettingSection.BORDER, "dayBorderDecrease.speed", Integer.valueOf(5), "Wie viele Bloecke pro Sekunde sich\ndie Border nach Tagen verkleinern soll."),
/*  70 */   BORDER_TIME_MINUTE_DECREASE(ConfigSettingSection.BORDER, "minuteBorderDecrease.enabled", Boolean.valueOf(false), "Ob sich die Border nach Minuten verringern soll"),
/*  71 */   BORDER_TIME_MINUTE_DECREASE_MINUTES(ConfigSettingSection.BORDER, "minuteBorderDecrease.minutes", Integer.valueOf(30), "Nach wie vielen Minuten sich\ndie Border verkleinern soll."),
/*  72 */   BORDER_TIME_MINUTE_DECREASE_SIZE(ConfigSettingSection.BORDER, "minuteBorderDecrease.size", Integer.valueOf(50), "Um wieviel sich die Bordernach den oben\ngenannten Minuten verkleinern soll."),
/*  73 */   BORDER_TIME_MINUTE_DECREASE_SPEED(ConfigSettingSection.BORDER, "minuteBorderDecrease.speed", Integer.valueOf(5), "Wie viele Bloecke pro Sekunde sichdie\nBorder nach Minuten verkleinern soll."),
/*  74 */   BORDER_TIME_MINUTE_BC_INTERVAL(ConfigSettingSection.BORDER, "minuteBorderDecrease.bcInterval", Integer.valueOf(300), "In welchen Sekundenabstaenden die Zeit bis zur Verkleinerung\ngebroacastet werden soll"),
/*  75 */   BROADCAST_INTERVAL_IN_SECONDS(ConfigSettingSection.OTHER, "broadcastIntervalInSeconds", Integer.valueOf(-1), "Interval in Sekunden, in welcher der\nBroadcaster eine Nachricht postet.\nHinweis: Die Nachrichten kannst du in der broadcasts.yml einstellen.\nOff = -1"),
/*  76 */   CAN_CHAT_BEFORE_START(ConfigSettingSection.CHAT, "canChatBeforeStart", Boolean.valueOf(true), "Ob die Spieler vor Start chatten koennen."),
/*     */   
/*  78 */   CAN_MOVE_BEFORE_START(ConfigSettingSection.START, "canMoveBeforeStart", Boolean.valueOf(false), "Ob die Spieler sich vor Start bewegen koennen."),
/*  79 */   CANWALK_PROTECTIONTIME(ConfigSettingSection.PROTECTIONS, "canWalkOnJoinProtection", Boolean.valueOf(false), "Ob Spieler waehrend der Joinschutzzeit laufen koennen."),
/*  80 */   CATCH_UP_SESSIONS(ConfigSettingSection.JOIN_SYSTEMS, "catchUpSessions", Boolean.valueOf(false), "NUR FÜR ERSTES JOIN SYSTEM\nStellt ein, ob man verpasste Folgen nachholen darf."),
/*     */   
/*  82 */   CHANGE_MOTD(
/*  83 */     ConfigSettingSection.SERVER_LIST, "changeMotd", Boolean.valueOf(true), "Ob das Plugin die Motd veraendern soll.\nHinweis: du kannst die Motd in der messages.yml aendern."),
/*  84 */   CHAT_COOLDOWN_IF_STARTED(ConfigSettingSection.CHAT, "chatCooldownIfStarted", Boolean.valueOf(false), "Ob der Chatcooldown auch aktiviert sein\\nsoll wenn das Projekt gestartet wurde."),
/*  85 */   CHAT_COOLDOWN_IN_SECONDS(ConfigSettingSection.CHAT, "chatCooldownInSeconds", Integer.valueOf(3), "Der Cooldown der Spieler im Chat,\nbevor sie wieder eine Nachricht senden koennen.\nOff = -1"),
/*  86 */   CHAT_TRIGGER(ConfigSettingSection.TEAMS, "chatTrigger", "#", "Definiert den Buchstaben am Anfang einer\nNachricht, der den Teamchat ausloest."),
/*     */   
/*  88 */   COMBATLOG_TIME(
/*  89 */     ConfigSettingSection.COMBATLOG, "combatlogTime", Integer.valueOf(30), "Zeit, nachdem sich ein Spieler\nnach dem Kampf wieder ausloggen kann.\nOff = -1"),
/*     */   
/*  91 */   DEATH_SOUND(
/*  92 */     ConfigSettingSection.DEATH, "deathSound", Boolean.valueOf(false), "Ob ein Withersound fuer alle abgespielt werden soll,\nsobald ein Spieler stirbt", true),
/*  93 */   DEBUG_OPTIONS(ConfigSettingSection.OTHER, "debugOptions", Boolean.valueOf(false), "Ob Debug Funktionen verfuegbar sein sollen.\nVorsicht: Mit Bedacht oder nur\nauf Anweisung nutzen!"),
/*  94 */   DISABLE_LABYMOD_FUNCTIONS(ConfigSettingSection.OTHER, "disableLabyModFunctions", Boolean.valueOf(false), "Ob die Addons von LabyMod beim Spieler\ndeaktviert werden sollen.\nFuer diese Funktion wird dieses Plugin benoetigt:\nhttps://www.spigotmc.org/resources/52423/"),
/*     */   
/*  96 */   DISCONNECT_PER_SESSION(
/*  97 */     ConfigSettingSection.DISCONNECT, "maxDisconnectsPerSessions", Integer.valueOf(3), "Wie oft ein Spieler pro\nSession maximal disconnecten darf,\nbevor er bestraft wird.Off = -1"),
/*  98 */   DISCORDBOT_ADD_POKAL_ON_WIN(ConfigSettingSection.DISCORD, "addPokalOnWin", Boolean.valueOf(true), "Ob den Gewinnern Pokale hinter den\nNamen gesetzt werden sollen."),
/*  99 */   DISCORDBOT_ANNOUNCEMENT_CHANNELID(ConfigSettingSection.DISCORD, "announcementChannelID", Integer.valueOf(-1), "Gib hier den Channel an,\nin dem Nachrichten vom AutoStart geschrieben werden.\nBeispiel: Varo startet in ... Minuten."),
/* 100 */   DISCORDBOT_ANNOUNCEMENT_PING_ROLEID(ConfigSettingSection.DISCORD, "announcementPingRoleID", Integer.valueOf(-1), "Gib hier die ID der Rolle ein, welche\nbei Nachrichtenauf Discord gepingt werden sollen.\nHinweis: -1 = everyone"),
/* 101 */   DISCORDBOT_COMMANDTRIGGER(ConfigSettingSection.DISCORD, "commandTrigger", "!varo ", "Stelle hier ein, womit man die\nVaro Commands Triggern kann.\nBeispiel: '!varo remaining'"),
/*     */   
/* 103 */   DISCORDBOT_ENABLED(
/* 104 */     ConfigSettingSection.DISCORD, "discordBotEnabled", Boolean.valueOf(false), "Ob der DiscordBot fuer Events aktiviert werden soll.\nHinweis: bitte fuer diesen Informationen unten ausfuellen"),
/* 105 */   DISCORDBOT_EVENT_ALERT(ConfigSettingSection.DISCORD, "eventChannel.alert", Integer.valueOf(-1), "ID's des Channels, wo die Benachrichtigungen gepostet werden.\n-1= EventChannelID wird genutzt"),
/* 106 */   DISCORDBOT_EVENT_DEATH(ConfigSettingSection.DISCORD, "eventChannel.death", Integer.valueOf(-1), "ID's des Channels, wo die Tode gepostet werden.\n-1= EventChannelID wird genutzt"),
/* 107 */   DISCORDBOT_EVENT_JOIN_LEAVE(ConfigSettingSection.DISCORD, "eventChannel.joinLeave", Integer.valueOf(-1), "ID's des Channels, wo die Joins/Leaves gepostet werden.\n-1= EventChannelID wird genutzt"),
/*     */   
/* 109 */   DISCORDBOT_EVENT_KILL(ConfigSettingSection.DISCORD, "eventChannel.kill", Integer.valueOf(-1), "ID's des Channels, wo die Kills gepostet werden.\n-1= EventChannelID wird genutzt"),
/* 110 */   DISCORDBOT_EVENT_STRIKE(ConfigSettingSection.DISCORD, "eventChannel.strike", Integer.valueOf(-1), "ID's des Channels, wo die Strikes gepostet werden.\n-1= EventChannelID wird genutzt"),
/* 111 */   DISCORDBOT_EVENT_WIN(ConfigSettingSection.DISCORD, "eventChannel.win", Integer.valueOf(-1), "ID's des Channels, wo die Winnachricht gepostet wird.\n-1= EventChannelID wird genutzt"),
/* 112 */   DISCORDBOT_EVENT_YOUTUBE(ConfigSettingSection.DISCORD, "eventChannel.youtube", Integer.valueOf(-1), "ID's des Channels, wo die YT-Videos gepostet werden.\n-1= EventChannelID wird genutzt"),
/* 113 */   DISCORDBOT_EVENTCHANNELID(ConfigSettingSection.DISCORD, "eventChannelID", Integer.valueOf(-1), "Gib hier die ChannelID des Channels an,\nin welchen der Bot Events posten soll.\nRechtsklick auf den Channel -> 'Copy ChannelID'\nWenn Option nicht vorhanden, schalte\n'developer options' in den Einstellungen von Discord ein."),
/* 114 */   DISCORDBOT_GAMESTATE(ConfigSettingSection.DISCORD, "gameState", "Varo | Plugin by Cuuky - Contributors: Korne127", "Stelle hier ein, was der Bot\nim Spiel als Name haben soll."),
/* 115 */   DISCORDBOT_INVITELINK(ConfigSettingSection.DISCORD, "inviteLink", "ENTER LINK HERE", "Stelle hier deinen Link zum Discord ein"),
/*     */   
/* 117 */   DISCORDBOT_MESSAGE_RANDOM_COLOR(ConfigSettingSection.DISCORD, "randomMessageColor", Boolean.valueOf(false), "Ob die Nachrichten eine zufaellige Farbe haben sollen"),
/* 118 */   DISCORDBOT_RESULT_CHANNELID(ConfigSettingSection.DISCORD, "resultChannelID", Integer.valueOf(-1), "Gib hier die Channel ID an, in der spaeter\ndie Logs und die Gewinner gepostet werden sollen."),
/* 119 */   DISCORDBOT_SERVERID(ConfigSettingSection.DISCORD, "serverGuildID", Integer.valueOf(-1), "Gib hier die ServerID deines Servers an.\nHinweis: Vorgangsweise, um die ID zu bekommen wie beim Channel."),
/*     */   
/* 121 */   DISCORDBOT_SET_TEAM_AS_GROUP(ConfigSettingSection.DISCORD, "setTeamAsGroup", Boolean.valueOf(false), "Ob die Spieler, die ein Team bekommen,\ndiesen auch als Gruppe im Discord bekommen sollen."),
/* 122 */   DISCORDBOT_TOKEN(ConfigSettingSection.DISCORD, "botToken", "ENTER TOKEN HERE", "Gib hier den Token an, welchen du auf\nder Bot Seite und 'create bot user' bekommst."),
/*     */   
/* 124 */   DISCORDBOT_VERIFYSYSTEM(ConfigSettingSection.DISCORD, "verify.enabled", Boolean.valueOf(false), "Ob das Verify System aktiviert werden soll.\nDieses laesst die Spieler sich mit Discord-Accounts verbinden."),
/* 125 */   DISCORDBOT_VERIFYSYSTEM_OPTIONAL(ConfigSettingSection.DISCORD, "verify.optinal", Boolean.valueOf(false), "Ob das Verify-System optional sein soll\nWenn deaktiviert: Nur verifizierte Spieler koennen\nden Server betreten"),
/* 126 */   DISCORDBOT_REGISTERCHANNELID(ConfigSettingSection.DISCORD, "verify.registerChannelID", Integer.valueOf(-1), "Gib hier die Channel ID des #verify - Channels\nan, wo sich die User verifizieren koennen."),
/* 127 */   DISCORDBOT_USE_VERIFYSTSTEM_MYSQL(ConfigSettingSection.DISCORD, "verify.mysql.enabled", Boolean.valueOf(false), "Ob fuer die Speicherung der BotRegister\neine MySQL Datenbank genutzt werden soll"),
/* 128 */   DISCORDBOT_VERIFY_DATABASE(ConfigSettingSection.DISCORD, "verify.mysql.database", "DATABASE_HERE", "Datenbank, wo die BotRegister\ngespeichert werden sollen"),
/* 129 */   DISCORDBOT_VERIFY_HOST(ConfigSettingSection.DISCORD, "verify.mysql.host", "HOST_HERE", "MySQL Host, zu welchem das Plugin sich verbinden soll"),
/* 130 */   DISCORDBOT_VERIFY_PASSWORD(ConfigSettingSection.DISCORD, "verify.mysql.password", "PASSWORD_HERE", "Passwort fuer MySQL Nutzer,\nwelcher auf die Datenbank zugreifen soll"),
/* 131 */   DISCORDBOT_VERIFY_USER(ConfigSettingSection.DISCORD, "verify.mysql.user", "USER_HERE", "MySQL Nutzer, welcher auf die Datenbank zugreifen soll"),
/*     */   
/* 133 */   DISTANCE_TO_BORDER_REQUIRED(ConfigSettingSection.BORDER, "distanceToBorderRequired", Integer.valueOf(-1), "Die Distanz, die der Spieler haben muss,\ndamit die Distanz angezeigt wird."),
/* 134 */   DO_DAILY_BACKUPS(ConfigSettingSection.MAIN, "dailyBackups", Boolean.valueOf(true), "Es werden immer Backups um 'ResetHour' gemacht."),
/*     */   
/* 136 */   DO_RANDOMTEAM_AT_START(ConfigSettingSection.START, "doRandomTeamAtStart", Integer.valueOf(-1), "Groesse der Teams, in die die Teamlosen beim Start eingeordnet werden.\nAusgeschaltet = -1"),
/* 137 */   DO_SORT_AT_START(ConfigSettingSection.START, "doSortAtStart", Boolean.valueOf(true), "Ob beim Start /sort ausgefuehrt werden soll."),
/* 138 */   DO_SPAWN_GENERATE_AT_START(ConfigSettingSection.START, "doSpawnGenerateAtStart", Boolean.valueOf(false), "Ob die Spawnloecher am Start basierend auf den\nderzeitigen Spielern generiert werden sollen"),
/* 139 */   FAKE_MAX_SLOTS(ConfigSettingSection.SERVER_LIST, "fakeMaxSlots", Integer.valueOf(-1), "Setzt die maximalen Slots des Servers gefaked.\nOff = -1"),
/* 140 */   FINALE_PROTECTION_TIME(ConfigSettingSection.FINALE, "finaleProtectionTime", Integer.valueOf(30), "Laenge der Schutzzeit nachdem alle Spieler in die Mitte teleportiert werden."),
/*     */   
/* 142 */   FRIENDLYFIRE(
/* 143 */     ConfigSettingSection.TEAMS, "friendlyFire", Boolean.valueOf(false), "Zufuegen von Schaden unter Teamkameraden."),
/* 144 */   GUI_FILL_INVENTORY(ConfigSettingSection.GUI, "guiFillInventory", Boolean.valueOf(true), "Bestimmt, ob die leeren Felder der Gui mit Kacheln aufgefuellt werden."),
/*     */   
/* 146 */   GUI_INVENTORY_ANIMATIONS(
/* 147 */     ConfigSettingSection.GUI, "guiInventoryAnimations", Boolean.valueOf(false), "Bestimmt, ob beim Klicken in der Gui eine Animation abgespielt wird."),
/*     */   
/* 149 */   IGNORE_JOINSYSTEMS_AS_OP(
/* 150 */     ConfigSettingSection.JOIN_SYSTEMS, "ignoreJoinSystemsAsOP", Boolean.valueOf(true), "Ob OP-Spieler die JoinSysteme ignorieren."),
/* 151 */   JOIN_AFTER_HOURS(ConfigSettingSection.JOIN_SYSTEMS, "joinAfterHours", Integer.valueOf(-1), "ZWEITES JOIN SYSTEM\nStellt ein, nach wie vielen Stunden\nSpieler regulaer wieder den Server betreten duerfen"),
/*     */   
/* 153 */   JOIN_PROTECTIONTIME(
/* 154 */     ConfigSettingSection.PROTECTIONS, "joinProtectionTime", Integer.valueOf(10), "Laenge der Schutzzeit in Sekunden beim Betreten des Servers.\nOff = -1"),
/* 155 */   KICK_AT_SERVER_CLOSE(ConfigSettingSection.JOIN_SYSTEMS, "kickAtServerClose", Boolean.valueOf(false), "Kickt den Spieler, sobald er ausserhalb\ndererlaubten Zeit auf dem Server ist."),
/* 156 */   KICK_DELAY_AFTER_DEATH(ConfigSettingSection.DEATH, "kickDelayAfterDeath", Integer.valueOf(-1), "Zeit in Sekunden, nach der ein Spieler\nnach Tod gekickt wird.\nOff = -1"),
/* 157 */   KICK_LABYMOD_PLAYER(ConfigSettingSection.OTHER, "kickLabyModPlayer", Boolean.valueOf(false), "Ob Spieler, die LabyMod nutzen,\ngekickt werden sollen.\nFuer diese Funktion wird dieses Plugin benoetigt:\nhttps://www.spigotmc.org/resources/52423/"),
/*     */   
/* 159 */   KILL_ON_COMBATLOG(ConfigSettingSection.COMBATLOG, "killOnCombatlog", Boolean.valueOf(true), "Ob ein Spieler, wenn er\nsich in der oben genannten Zeit ausloggt,\ngetoetet werden soll."),
/* 160 */   KILLER_ADD_HEALTH_ON_KILL(ConfigSettingSection.DEATH, "killerHealthAddOnKill", Integer.valueOf(-1), "Anzahl halber Herzen, die der Killer nach Kill bekommt.\nOff = -1"),
/* 161 */   LOG_REPORTS(ConfigSettingSection.REPORT, "logReports", Boolean.valueOf(true), "Ob alle Reports in der reports.yml\nfestgehalten werden sollen."),
/* 162 */   MASS_RECORDING_TIME(ConfigSettingSection.JOIN_SYSTEMS, "massRecordingTime", Integer.valueOf(15), "Die Laenge der Massenaufnahme, in der alle joinen koennen."),
/* 163 */   MIN_BORDER_SIZE(ConfigSettingSection.BORDER, "minBorderSize", Integer.valueOf(300), "Wie klein die Border maximal werden kann."),
/*     */   
/* 165 */   MINIMAL_SPECTATOR_HEIGHT(ConfigSettingSection.OTHER, "minimalSpectatorHeight", Integer.valueOf(70), "Wie tief die Spectator maximal fliegen koennen.\nOff = 0"),
/* 166 */   NAMETAG_SPAWN_HEIGHT(ConfigSettingSection.WORLD, "nametagSpawnHeight", Integer.valueOf(3), "Wie hoch ueber den Spawns\ndie Nametags sein sollen"),
/* 167 */   NAMETAGS(ConfigSettingSection.MAIN, "nametags", Boolean.valueOf(true), "Ob das Plugin die Nametags ueber\nden Koepfen der Spieler veraendern soll.\nHinweis: du kannst diese in der messages.yml einstellen.", true),
/* 168 */   NO_ACTIVITY_DAYS(ConfigSettingSection.ACTIVITY, "noActivityDays", Integer.valueOf(-1), "Nach wie vielen Tagen ohne Aktiviaet auf dem\nServer der Spieler gemeldet werden soll.\nOff = -1"),
/*     */   
/* 170 */   NO_DISCONNECT_PING(ConfigSettingSection.DISCONNECT, "noDisconnectPing", Integer.valueOf(200), "Ab welchem Ping ein Disconnect\nnicht mehr als einer zaehlt."),
/* 171 */   NO_KICK_DISTANCE(ConfigSettingSection.OTHER, "noKickDistance", Integer.valueOf(30), "In welcher Distanz zum Gegner\nein Spieler nicht gekickt wird.\nOff = 0"),
/* 172 */   NO_SATIATION_REGENERATE(ConfigSettingSection.OFFLINEVILLAGER, "noSatiationRegenerate", Boolean.valueOf(false), "Ob Spieler nicht durch Saettigung regenerieren\nkoennen sondern nur durch Gapple etc."),
/*     */   
/* 174 */   OFFLINEVILLAGER(
/* 175 */     ConfigSettingSection.OFFLINEVILLAGER, "enableOfflineVillager", Boolean.valueOf(false), "Ob Villager, welche representativ fuer den Spieler waehrend\nseiner Onlinezeit auf dem Server warten und gekillt werden koennen."),
/*     */   
/* 177 */   ONLY_JOIN_BETWEEN_HOURS(ConfigSettingSection.JOIN_SYSTEMS, "onlyJoinBetweenHours", Boolean.valueOf(false), "FÜR BEIDE JOIN SYSTEME\nStellt ein, ob Spieler nur zwischen\n2 unten festgelegten Zeiten joinen duerfen."),
/* 178 */   ONLY_JOIN_BETWEEN_HOURS_HOUR1(ConfigSettingSection.JOIN_SYSTEMS, "onlyJoinBetweenHoursHour1", Integer.valueOf(14), "Erste Uhrzeit, zwischen welchen\ndie Spieler joinen duerfen."),
/* 179 */   ONLY_JOIN_BETWEEN_HOURS_MINUTE1(ConfigSettingSection.JOIN_SYSTEMS, "onlyJoinBetweenHoursMinute1", Integer.valueOf(0), "Erste Minuten-Uhrzeit, zwischen welchen\ndie Spieler joinen duerfen."),
/* 180 */   ONLY_JOIN_BETWEEN_HOURS_HOUR2(ConfigSettingSection.JOIN_SYSTEMS, "onlyJoinBetweenHoursHour2", Integer.valueOf(16), "Zweite Uhrzeit, zwischen welchen\ndie Spieler joinen duerfen."),
/* 181 */   ONLY_JOIN_BETWEEN_HOURS_MINUTE2(ConfigSettingSection.JOIN_SYSTEMS, "onlyJoinBetweenHoursMinute2", Integer.valueOf(0), "Zweite Minuten-Uhrzeit, zwischen welchen\ndie Spieler joinen duerfen."),
/*     */   
/* 183 */   ONLY_LABYMOD_PLAYER(ConfigSettingSection.OTHER, "onlyLabyModPlayer", Boolean.valueOf(false), "Ob nur Spieler mit LabyMod joinen duerfen.\nFuer diese Funktion wird dieses Plugin benoetigt:\nhttps://www.spigotmc.org/resources/52423/"),
/* 184 */   OUTSIDE_BORDER_SPAWN_TELEPORT(ConfigSettingSection.BORDER, "outsideBorderSpawnTeleport", Boolean.valueOf(true), "Ob, wenn ein Spieler ausserhalb der Border joint, er in die Mitte teleportiert werden soll."),
/* 185 */   PLAY_TIME(ConfigSettingSection.MAIN, "playTime", Integer.valueOf(15), "Zeit in Minuten, wie lange die Spieler\npro Session auf dem Server spielen koennen.\nUnlimited = -1"),
/*     */   
/* 187 */   PLAYER_CHEST_LIMIT(
/* 188 */     ConfigSettingSection.OTHER, "playerChestLimit", Integer.valueOf(2), "Wie viele Chests ein Team\nregistrieren darf.\nOff = 0, Unendlich = -1"),
/* 189 */   PLAYER_FURNACE_LIMIT(ConfigSettingSection.OTHER, "playerFurnaceLimit", Integer.valueOf(-1), "Wie viele Furnaces ein\nSpieler registrieren darf.\nOff = 0, Undendlich = -1"),
/* 190 */   PLAYER_SPECTATE_AFTER_DEATH(ConfigSettingSection.DEATH, "playerSpectateAfterDeath", Boolean.valueOf(false), "Ob ein Spieler nach seinem Tod Spectator wird."),
/*     */   
/* 192 */   PLAYER_SPECTATE_IN_FINALE(
/* 193 */     ConfigSettingSection.FINALE, "playerSpectateInFinale", Boolean.valueOf(true), "Ob die toten Spieler waehrend des Finales spectaten duerfen."),
/* 194 */   POST_COORDS_DAYS(ConfigSettingSection.ACTIVITY, "postCoordsDays", Integer.valueOf(-1), "Postet nach den genannten Tagen\nvon allen Spielern die Koordinatenum die Uhrzeit,\num der auch Sessions etc. geprueft werden"),
/* 195 */   PRE_PRODUCE_SESSIONS(ConfigSettingSection.JOIN_SYSTEMS, "preProduceSessions", Integer.valueOf(3), "FÜR BEIDE JOIN SYSTEME\nStellt ein, wie viele Folgen der Spieler zusaetzlich zu\nden Regulaeren vorproduzieren darf."),
/*     */   
/* 197 */   PREFIX(
/* 198 */     ConfigSettingSection.MAIN, "prefix", "&7[&3Varo&7] ", "Prefix, der im Chat bzw. vor\nden Nachrichten angezeigt wird."),
/* 199 */   PROJECT_NAME(ConfigSettingSection.MAIN, "projectname", "Varo", "Name deines Projektes, der in den\nNachrichten, am Scoreboard, etc. steht."),
/* 200 */   PROJECTNAME_COLORCODE(ConfigSettingSection.MAIN, "projectnameColorcode", "&3", "Dieser Farbcode ist der Massgebende,\nder ueberall im Projekt verwendet wird.."),
/* 201 */   RANDOM_CHEST_FILL_RADIUS(ConfigSettingSection.WORLD, "randomChestFillRadius", Integer.valueOf(-1), "In welchem Radius die Kisten um den\nSpawn mit den in der Config angegebenen\nItems befuellt werden sollen.\nOff = -1"),
/* 202 */   RANDOM_CHEST_MAX_ITEMS_PER_CHEST(ConfigSettingSection.WORLD, "randomChestMaxItems", Integer.valueOf(5), "Wie viele Items in eine Kiste sollen."),
/* 203 */   REMOVE_HIT_COOLDOWN(ConfigSettingSection.OTHER, "removeHitDelay", Boolean.valueOf(false), "Entfernt den 1.9+ Hit delay"),
/* 204 */   REMOVE_PLAYERS_ARENT_AT_START(ConfigSettingSection.START, "removePlayersArentAtStart", Boolean.valueOf(true), "Ob das Plugin alle Spieler, die nicht beim\nStart dabei sind vom Projekt entferenen soll."),
/* 205 */   REPORT_SEND_DELAY(ConfigSettingSection.REPORT, "reportDelay", Integer.valueOf(30), "Zeit in Sekunden, die ein Spieler warten muss,\nbevor er einen neuen Spieler reporten kann.\nOff = -1"),
/* 206 */   REPORT_STAFF_MEMBER(ConfigSettingSection.REPORT, "reportStaffMember", Boolean.valueOf(true), "Ob Spieler mit der Permission\n'varo.report' reportet werden koennen."),
/*     */   
/* 208 */   REPORTSYSTEM_ENABLED(
/* 209 */     ConfigSettingSection.REPORT, "enabled", Boolean.valueOf(true), "Ob das Report-System angeschaltet sein soll."),
/* 210 */   RESET_SESSION_HOUR(ConfigSettingSection.MAIN, "resetSessionHour", Integer.valueOf(1), "Um welche Uhrzeit (24h) der Server den\nSpieler neue Sessions etc. gibt"),
/* 211 */   RESPAWN_PROTECTION(ConfigSettingSection.DEATH, "respawnProtection", Integer.valueOf(120), "Wie lange in Sekunden Spieler\nnach Respawn geschuetzt sind"),
/* 212 */   SCOREBOARD(ConfigSettingSection.MAIN, "scoreboard", Boolean.valueOf(true), "Ob das Scoreboard aktiviert sein soll.\nHinweis: das Scoreboard kannst du in\nder scoreboard.yml bearbeiten.", true),
/* 213 */   SESSIONS_PER_DAY(ConfigSettingSection.JOIN_SYSTEMS, "sessionsPerDay", Integer.valueOf(1), "ERSTES JOIN SYSTEM\nStellt ein, wie oft Spieler am Tag\nden Server regulaer betreten duerfen."),
/*     */   
/* 215 */   SET_NAMETAGS_OVER_SPAWN(ConfigSettingSection.WORLD, "setNameTagOverSpawn", Boolean.valueOf(true), "Ob Nametags ueber den\nSpawns erscheinen sollen"),
/* 216 */   SHOW_DISTANCE_TO_BORDER(ConfigSettingSection.BORDER, "showDistanceToBorder", Boolean.valueOf(false), "Ob die Distanz zur Border in der\nActionBar angezeigt werden soll."),
/* 217 */   SHOW_TIME_IN_ACTIONBAR(ConfigSettingSection.OTHER, "showTimeInActionbar", Boolean.valueOf(false), "Ob die verbleibende Sessionzeit in\nder Actionbar angezeigt werden soll."),
/* 218 */   SPAWN_PROTECTION_RADIUS(ConfigSettingSection.WORLD, "spawnProtectionRadius", Integer.valueOf(0), "Radius, in dem die Spieler\nnicht am Spawn bauen koennen."),
/*     */   
/* 220 */   SPAWN_TELEPORT_JOIN(ConfigSettingSection.START, "spawnTeleportAtLobbyPhase", Boolean.valueOf(true), "Ob die Spieler, wenn\nfuer sie ein Spawn gesetzt wurde auch in\ndiesem spawnen sollen, sobald sie joinen."),
/* 221 */   START_AT_PLAYERS(ConfigSettingSection.START, "startAtPlayers", Integer.valueOf(-1), "Startet das Projekt automatisch wenn die\nAnzahl der Online Spieler dieser entspricht."),
/*     */   
/* 223 */   STARTCOUNTDOWN(
/* 224 */     ConfigSettingSection.START, "startCountdown", Integer.valueOf(30), "Wie lange der Startcountdown\nbei Start in Sekunden ist."),
/* 225 */   STARTPERIOD_PROTECTIONTIME(ConfigSettingSection.PROTECTIONS, "startperiodProtectiontime", Integer.valueOf(-1), "Laenge der Schutzzeit nach dem Start.\nOff = -1"),
/* 226 */   STARTPERIOD_PROTECTIONTIME_BROADCAST_INTERVAL(ConfigSettingSection.PROTECTIONS, "startperiodProtectiontimeBcInterval", Integer.valueOf(60), "In welchen Sekundenabstaenden die restliche Schutzzeit\ngebroacastet werden soll"),
/* 227 */   STOP_SERVER_ON_WIN(ConfigSettingSection.DEATH, "stopServerOnWin", Integer.valueOf(-1), "Zeit in Sekunden, nachdem der Server nach\nWin eines Teams heruntergefahren wird."),
/* 228 */   STRIKE_BAN_AFTER_STRIKE_HOURS(ConfigSettingSection.STRIKE, "banOnPostHours", Integer.valueOf(-1), "Fuer wie viele Stunden die Spieler\nnach einem Strike gestriket werden"),
/* 229 */   STRIKE_BAN_AT_POST(ConfigSettingSection.STRIKE, "banAtPost", Boolean.valueOf(true), "Ob der Spieler beim Posten des Strikes\num die oben genannte Zahl gebannt werden soll.\nSonst wird dieser beim Erhalten gebannt"),
/* 230 */   STRIKE_ON_BLOODLUST(ConfigSettingSection.ACTIVITY, "strikeOnBloodlust", Boolean.valueOf(false), "Ob der Spieler nach den oben\ngenannten Tagen ohne Gegnerkontakt\ngestriket werden soll."),
/* 231 */   STRIKE_ON_COMBATLOG(ConfigSettingSection.COMBATLOG, "strikeOnCombatlog", Boolean.valueOf(true), "Ob ein Spieler, wenn er sich in\nder oben genannten Zeit ausloggt,\ngestriket werden soll."),
/* 232 */   STRIKE_ON_DISCONNECT(ConfigSettingSection.DISCONNECT, "strikeOnMaxDisconnect", Boolean.valueOf(false), "Ob ein Spieler gestriket werden soll\nwenn zu oft disconnected wurde."),
/* 233 */   STRIKE_ON_NO_ACTIVITY(ConfigSettingSection.ACTIVITY, "strikeOnNoActivity", Boolean.valueOf(false), "Ob der Spieler nach den oben genannten Tagen\nohne Aktivitaet auf dem Servergestriket werden soll."),
/*     */   
/* 235 */   STRIKE_POST_RESET_HOUR(
/* 236 */     ConfigSettingSection.STRIKE, "postAtResetHour", Boolean.valueOf(false), "Ob die Strikes erst um die ResetHour gepostet werden sollen"),
/* 237 */   SUPPORT_PLUGIN_ADS(ConfigSettingSection.MAIN, "supportPluginAds", Boolean.valueOf(false), "Werbung wird im Plugin mit eingebaut,was das Plugin,\nalso mich, supportet. Danke an alle, die das aktivieren :3"),
/* 238 */   TABLIST(ConfigSettingSection.MAIN, "tablist", Boolean.valueOf(true), "Ob das Plugin die Tablist modfizieren soll", true),
/* 239 */   TEAM_LIFES(ConfigSettingSection.DEATH, "teamLifes", Integer.valueOf(1), "Wie viele Leben ein Team hat"),
/*     */   
/* 241 */   TEAM_PLACE_SPAWN(ConfigSettingSection.TEAMS, "teamPlaceSpawn", Integer.valueOf(-1), "Anzahl an Spawnplaetzen in einer Teambasis\nWenn angeschaltet (nicht -1) wird eine Luecke fuer fehlende Teammitglieder gelassen.\nAnschalten, wenn jedes Team einen eigenen Spawnplatz besitzt und es keinen grossen Kreis gibt."),
/*     */   
/* 243 */   TEAMREQUEST_EXPIRETIME(ConfigSettingSection.TEAMS, "teamRequest.expiretime", Integer.valueOf(30), "Die Zeit in Sekunden, nachdem eine Teamanfrage ablaufen soll."),
/* 244 */   TEAMREQUEST_MAXTEAMMEMBERS(ConfigSettingSection.TEAMS, "teamRequest.maxTeamMembers", Integer.valueOf(2), "Anzahl an Teammitglieder pro Team."),
/* 245 */   TEAMREQUEST_MAXTEAMNAMELENGTH(ConfigSettingSection.TEAMS, "teamRequest.maxTeamnameLength", Integer.valueOf(10), "Maximal Laenge eines Teamnamens."),
/* 246 */   TEAMREQUEST_ENABLED(ConfigSettingSection.TEAMS, "teamRequest.enabled", Boolean.valueOf(false), "Ob Spieler sich gegenseitig in Teams\nmit /tr einladen koennen.\nSehr gute Funktion fuer ODV's."),
/* 247 */   TEAMREQUEST_LOBBYITEMS(ConfigSettingSection.TEAMS, "teamRequest.lobbyItems", Boolean.valueOf(true), "Ob die Spieler Items in\nder Lobby erhalten sollen,\nwomit sie sich einladen können"),
/*     */   
/* 249 */   TELEGRAM_BOT_TOKEN(ConfigSettingSection.TELEGRAM, "botToken", "ENTER TOKEN HERE", "Setzt den Bot Token des Telegrambots"),
/*     */   
/* 251 */   TELEGRAM_ENABLED(
/* 252 */     ConfigSettingSection.TELEGRAM, "telegrambotEnabled", Boolean.valueOf(false), "Ob der Telegrambot aktiviert werden soll."),
/* 253 */   TELEGRAM_EVENT_CHAT_ID(ConfigSettingSection.TELEGRAM, "eventChatId", Integer.valueOf(-1), "In diesen Chat werden alle Events gepostet."),
/* 254 */   TELEGRAM_VIDEOS_CHAT_ID(ConfigSettingSection.TELEGRAM, "videosChatId", Integer.valueOf(-1), "Hier kannst du die ID des Chats angeben, wo\ndie Videos der User gepostet werden sollen."),
/* 255 */   TRIGGER_FOR_GLOBAL(ConfigSettingSection.TEAMS, "triggerForGlobal", Boolean.valueOf(false), "Wenn aktiviert, wird standardmaessig in den Teamchat geschrieben und mit dem Triggerbuchstaben am Anfang in den globalen Chat, ansonsten umgekehrt."),
/* 256 */   UNREGISTERED_PLAYER_JOIN(ConfigSettingSection.MAIN, "unregisteredPlayerJoin", Boolean.valueOf(true), "Ob unregistrierte Spieler joinen duerfen."),
/*     */   
/* 258 */   YOUTUBE_ENABLED(
/* 259 */     ConfigSettingSection.YOUTUBE, "enabled", Boolean.valueOf(false), "Checkt jeden Tag bei den Spielern,\ndie einen YouTube Link registriert haben,\nnach den Uploads"),
/* 260 */   YOUTUBE_SET_OWN_LINK(ConfigSettingSection.YOUTUBE, "setOwnLink", Boolean.valueOf(true), "Ob die Spieler sich selbst den\nYouTube-Link per /yt setzen duerfen"),
/* 261 */   YOUTUBE_VIDEO_IDENTIFIER(ConfigSettingSection.YOUTUBE, "videoIdentifier", "Varo", "Was die Videotitel enthalten\nmuessen, um als Varovideo zu gelten."); private Object defaultValue;
/*     */   private Object value;
/*     */   private String path;
/*     */   private String description;
/*     */   private ConfigSettingSection section;
/*     */   private boolean reducesPerformance;
/*     */   
/*     */   ConfigSetting(ConfigSettingSection section, String path, Object value, String description) {
/* 269 */     this.section = section;
/* 270 */     this.path = path;
/* 271 */     this.value = value;
/* 272 */     this.defaultValue = value;
/* 273 */     this.description = description;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigSetting(ConfigSettingSection section, String path, Object value, String description, boolean reducesPerformance) {
/* 279 */     this.reducesPerformance = reducesPerformance;
/*     */   }
/*     */   
/*     */   private void save() {
/* 283 */     Main.getDataManager().getConfigHandler().saveValue(this);
/*     */   }
/*     */   
/*     */   private void sendFalseCast(Class<?> failedToCast) {
/* 287 */     if ((this.value instanceof Integer && failedToCast.equals(Long.class)) || (this.value instanceof Long && failedToCast.equals(Integer.class))) {
/* 288 */       throw new IllegalArgumentException("'" + this.value + "' (" + this.value.getClass().getName() + ") is not applyable for " + failedToCast.getName() + " for entry " + getFullPath());
/*     */     }
/*     */     try {
/* 291 */       throw new IllegalArgumentException("'" + this.value + "' (" + this.value.getClass().getName() + ") is not applyable for " + failedToCast.getName() + " for entry " + getFullPath());
/* 292 */     } catch (Exception e) {
/* 293 */       e.printStackTrace();
/*     */     } finally {
/* 295 */       Bukkit.getServer().shutdown();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFullPath() {
/* 301 */     return String.valueOf(this.section.getName()) + "." + this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getDefaultValue() {
/* 306 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getDescription() {
/* 311 */     return this.description.split("\n");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPath() {
/* 316 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigSettingSection getSection() {
/* 321 */     return this.section;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(Object value) {
/* 326 */     setValue(value, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 331 */     return this.value;
/*     */   }
/*     */   
/*     */   public void setValue(Object value, boolean save) {
/* 335 */     this.value = value;
/*     */     
/* 337 */     if (save)
/* 338 */       save(); 
/*     */   }
/*     */   
/*     */   public boolean getValueAsBoolean() {
/*     */     try {
/* 343 */       return ((Boolean)this.value).booleanValue();
/* 344 */     } catch (Exception e) {
/* 345 */       sendFalseCast(Boolean.class);
/*     */ 
/*     */       
/* 348 */       return ((Boolean)this.defaultValue).booleanValue();
/*     */     } 
/*     */   }
/*     */   public double getValueAsDouble() {
/*     */     try {
/* 353 */       return ((Double)this.value).doubleValue();
/* 354 */     } catch (Exception e) {
/*     */       try {
/* 356 */         return Double.valueOf(getValueAsInt()).doubleValue();
/* 357 */       } catch (Exception e2) {
/* 358 */         sendFalseCast(Double.class);
/*     */ 
/*     */ 
/*     */         
/* 362 */         return ((Double)this.defaultValue).doubleValue();
/*     */       } 
/*     */     } 
/*     */   } public int getValueAsInt() {
/*     */     try {
/* 367 */       return ((Integer)this.value).intValue();
/* 368 */     } catch (Exception e) {
/* 369 */       sendFalseCast(Integer.class);
/*     */ 
/*     */       
/* 372 */       return ((Integer)this.defaultValue).intValue();
/*     */     } 
/*     */   }
/*     */   public long getValueAsLong() {
/*     */     try {
/* 377 */       return ((Long)this.value).longValue();
/* 378 */     } catch (Exception e) {
/*     */       try {
/* 380 */         return Long.valueOf(getValueAsInt()).longValue();
/* 381 */       } catch (Exception e2) {
/* 382 */         sendFalseCast(Long.class);
/*     */ 
/*     */ 
/*     */         
/* 386 */         return ((Long)this.defaultValue).longValue();
/*     */       } 
/*     */     } 
/*     */   } public String getValueAsString() {
/* 390 */     if (this.value instanceof String) {
/* 391 */       return ((String)this.value).replace("&", "§");
/*     */     }
/*     */     try {
/* 394 */       return (String)(this.value = String.valueOf(this.value).replace("&", "§"));
/* 395 */     } catch (Exception e) {
/* 396 */       sendFalseCast(String.class);
/*     */ 
/*     */       
/* 399 */       return (String)this.defaultValue;
/*     */     } 
/*     */   }
/*     */   public boolean isIntActivated() {
/* 403 */     return (getValueAsInt() > -1);
/*     */   }
/*     */   
/*     */   public boolean isReducingPerformance() {
/* 407 */     return this.reducesPerformance; } public static ConfigSetting getEntryByPath(String path) {
/*     */     byte b;
/*     */     int i;
/*     */     ConfigSetting[] arrayOfConfigSetting;
/* 411 */     for (i = (arrayOfConfigSetting = values()).length, b = 0; b < i; ) { ConfigSetting entry = arrayOfConfigSetting[b];
/* 412 */       if (!entry.getPath().equals(path)) {
/*     */         b++; continue;
/*     */       } 
/* 415 */       return entry; }
/*     */     
/* 417 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\configuration\configurations\config\ConfigSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */