/*    */ package de.cuuky.varo.preset;
/*    */ 
/*    */ import com.google.common.io.Files;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ public class PresetLoader
/*    */ {
/*    */   private File file;
/*    */   
/*    */   public PresetLoader(String name) {
/* 13 */     this.file = new File("plugins/Varo/presets/" + name);
/*    */   }
/*    */   
/*    */   public void copyCurrentSettingsTo() {
/* 17 */     if (!this.file.exists())
/* 18 */       this.file.mkdirs();  byte b; int i;
/*    */     File[] arrayOfFile;
/* 20 */     for (i = (arrayOfFile = (new File("plugins/Varo/config/")).listFiles()).length, b = 0; b < i; ) { File config = arrayOfFile[b];
/* 21 */       if (config.isFile())
/*    */         
/*    */         try {
/*    */           
/* 25 */           Files.copy(config, new File(String.valueOf(this.file.getPath()) + "/" + config.getName()));
/* 26 */         } catch (IOException e) {
/* 27 */           e.printStackTrace();
/*    */         }  
/*    */       b++; }
/*    */   
/*    */   }
/*    */   public File getFile() {
/* 33 */     return this.file;
/*    */   }
/*    */   
/*    */   public void loadSettings() {
/* 37 */     if (!this.file.exists())
/* 38 */       this.file.mkdirs();  byte b; int i;
/*    */     File[] arrayOfFile;
/* 40 */     for (i = (arrayOfFile = this.file.listFiles()).length, b = 0; b < i; ) { File config = arrayOfFile[b];
/* 41 */       if (config.isFile())
/*    */         
/*    */         try {
/*    */           
/* 45 */           Files.copy(config, new File("plugins/Varo/config/" + config.getName()));
/* 46 */         } catch (IOException e) {
/* 47 */           e.printStackTrace();
/*    */         }  
/*    */       b++; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\preset\PresetLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */