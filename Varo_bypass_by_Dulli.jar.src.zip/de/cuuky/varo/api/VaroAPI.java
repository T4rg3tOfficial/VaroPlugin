/*    */ package de.cuuky.varo.api;
/*    */ 
/*    */ import de.cuuky.varo.api.event.EventManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroAPI
/*    */ {
/* 10 */   private static EventManager eventManager = new EventManager();
/*    */ 
/*    */   
/*    */   public static EventManager getEventManager() {
/* 14 */     return eventManager;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\api\VaroAPI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */