package de.cuuky.varo.api.event.register;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface VaroEventMethod {}


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\api\event\register\VaroEventMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */