/*    */ package de.cuuky.varo.api.event.events.player;
/*    */ 
/*    */ import de.cuuky.varo.api.event.VaroAPIEvent;
/*    */ import de.cuuky.varo.api.objects.player.VaroAPIPlayer;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ 
/*    */ public class VaroPlayerEvent
/*    */   extends VaroAPIEvent {
/*    */   private VaroAPIPlayer player;
/*    */   
/*    */   public VaroPlayerEvent(VaroPlayer player, boolean cancelAble) {
/* 12 */     super(cancelAble);
/*    */     
/* 14 */     this.player = new VaroAPIPlayer(player);
/*    */   }
/*    */   
/*    */   public VaroAPIPlayer getPlayer() {
/* 18 */     return this.player;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\api\event\events\player\VaroPlayerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */