/*    */ package de.cuuky.varo.api.event.events.player.strike;
/*    */ 
/*    */ import de.cuuky.varo.api.event.events.player.VaroPlayerEvent;
/*    */ import de.cuuky.varo.api.objects.player.stats.VaroAPIStrike;
/*    */ import de.cuuky.varo.entity.player.stats.stat.Strike;
/*    */ 
/*    */ public class PlayerStrikeRemoveEvent
/*    */   extends VaroPlayerEvent {
/*    */   private VaroAPIStrike strike;
/*    */   
/*    */   public PlayerStrikeRemoveEvent(Strike strike) {
/* 12 */     super(strike.getStriked(), true);
/*    */     
/* 14 */     this.strike = new VaroAPIStrike(strike);
/*    */   }
/*    */   
/*    */   public VaroAPIStrike getStrike() {
/* 18 */     return this.strike;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\api\event\events\player\strike\PlayerStrikeRemoveEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */