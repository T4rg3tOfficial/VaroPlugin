/*    */ package de.cuuky.varo.api.event.events.game;
/*    */ 
/*    */ import de.cuuky.varo.api.event.VaroAPIEvent;
/*    */ import de.cuuky.varo.api.objects.game.VaroAPIGame;
/*    */ import de.cuuky.varo.game.VaroGame;
/*    */ 
/*    */ public class VaroEndEvent
/*    */   extends VaroAPIEvent {
/*    */   private VaroAPIGame game;
/*    */   
/*    */   public VaroEndEvent(VaroGame game) {
/* 12 */     super(true);
/*    */     
/* 14 */     this.game = new VaroAPIGame(game);
/*    */   }
/*    */   
/*    */   public VaroAPIGame getGame() {
/* 18 */     return this.game;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\api\event\events\game\VaroEndEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */