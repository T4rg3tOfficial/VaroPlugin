/*    */ package de.cuuky.varo.api.objects.player.stats;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.stats.stat.Strike;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ public class VaroAPIStrike
/*    */ {
/*    */   private Strike strike;
/*    */   
/*    */   public VaroAPIStrike(Strike strike) {
/* 13 */     this.strike = strike;
/*    */   }
/*    */   
/*    */   public Date getAcquiredDate() {
/* 17 */     return this.strike.getAcquiredDate();
/*    */   }
/*    */   
/*    */   public String getReason() {
/* 21 */     return this.strike.getReason();
/*    */   }
/*    */   
/*    */   public VaroPlayer getStrikeOwner() {
/* 25 */     return this.strike.getStriked();
/*    */   }
/*    */   
/*    */   public String getStriker() {
/* 29 */     return this.strike.getStriker();
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\api\objects\player\stats\VaroAPIStrike.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */