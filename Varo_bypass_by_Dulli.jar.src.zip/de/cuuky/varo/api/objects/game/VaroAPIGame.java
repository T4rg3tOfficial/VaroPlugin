/*    */ package de.cuuky.varo.api.objects.game;
/*    */ 
/*    */ import de.cuuky.varo.game.VaroGame;
/*    */ import org.bukkit.Location;
/*    */ 
/*    */ 
/*    */ public class VaroAPIGame
/*    */ {
/*    */   private VaroGame game;
/*    */   
/*    */   public VaroAPIGame(VaroGame game) {
/* 12 */     this.game = game;
/*    */   }
/*    */   
/*    */   public VaroAPIGameState getState() {
/* 16 */     return VaroAPIGameState.getState(this.game.getGameState());
/*    */   }
/*    */   
/*    */   public boolean isStarting() {
/* 20 */     return this.game.isStarting();
/*    */   }
/*    */   
/*    */   public void setLobbyLocation(Location lobby) {
/* 24 */     this.game.setLobby(lobby);
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\api\objects\game\VaroAPIGame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */