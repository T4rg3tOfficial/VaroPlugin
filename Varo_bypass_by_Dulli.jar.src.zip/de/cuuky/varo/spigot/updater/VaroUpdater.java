/*     */ package de.cuuky.varo.spigot.updater;
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.alert.Alert;
/*     */ import de.cuuky.varo.alert.AlertType;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Scanner;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.json.simple.JSONObject;
/*     */ import org.json.simple.JSONValue;
/*     */ import org.json.simple.parser.ParseException;
/*     */ 
/*     */ public class VaroUpdater {
/*     */   private static final int RESCOURCE_ID = 71075;
/*     */   private static final String UPDATE_LINK = "https://api.spiget.org/v2/resources/71075/versions/latest";
/*     */   private VaroUpdateResultSet lastResult;
/*     */   
/*     */   private enum VersionCompareResult {
/*  20 */     VERSION1GREATER,
/*  21 */     VERSION2GREATER,
/*  22 */     VERSIONS_EQUAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VaroUpdater() {
/*  31 */     checkUpdate();
/*     */   }
/*     */   
/*     */   private VersionCompareResult compareVersions(String version1, String version2) {
/*  35 */     if (!version1.replace("-BETA", "").matches("[0-9]+(\\.[0-9]+)*") || !version2.replace("-BETA", "").matches("[0-9]+(\\.[0-9]+)*")) {
/*  36 */       throw new IllegalArgumentException("Invalid version format");
/*     */     }
/*  38 */     String[] version1Parts = version1.replace("-BETA", "").split("\\.");
/*  39 */     String[] version2Parts = version2.replace("-BETA", "").split("\\.");
/*     */     
/*  41 */     for (int i = 0; i < Math.max(version1Parts.length, version2Parts.length); i++) {
/*  42 */       int version1Part = (i < version1Parts.length) ? Integer.parseInt(version1Parts[i]) : 0;
/*  43 */       int version2Part = (i < version2Parts.length) ? Integer.parseInt(version2Parts[i]) : 0;
/*  44 */       if (version1Part < version2Part)
/*  45 */         return VersionCompareResult.VERSION2GREATER; 
/*  46 */       if (version1Part > version2Part) {
/*  47 */         return VersionCompareResult.VERSION1GREATER;
/*     */       }
/*     */     } 
/*  50 */     if (version1.contains("BETA")) {
/*  51 */       return VersionCompareResult.VERSION2GREATER;
/*     */     }
/*  53 */     if (version2.contains("BETA")) {
/*  54 */       return VersionCompareResult.VERSION1GREATER;
/*     */     }
/*  56 */     return VersionCompareResult.VERSIONS_EQUAL;
/*     */   }
/*     */   
/*     */   private void checkUpdate() {
/*  60 */     Bukkit.getScheduler().scheduleAsyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  64 */             VaroUpdater.this.checkForUpdates(true);
/*     */           }
/*  66 */         },  20L);
/*     */   }
/*     */   
/*     */   public void printResults() {
/*  70 */     if (this.lastResult == null) {
/*     */       return;
/*     */     }
/*  73 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Updater: " + this.lastResult.getUpdateResult().getMessage());
/*     */     
/*  75 */     for (Alert upAlert : Alert.getAlerts(AlertType.UPDATE_AVAILABLE)) {
/*  76 */       if (upAlert.isOpen() && upAlert.getMessage().contains(this.lastResult.getVersionName()))
/*     */         return; 
/*     */     } 
/*  79 */     if (this.lastResult.getUpdateResult() == VaroUpdateResultSet.UpdateResult.UPDATE_AVAILABLE);
/*     */   }
/*     */   
/*     */   public VaroUpdateResultSet checkForUpdates(boolean print) {
/*     */     String version, id;
/*  84 */     VaroUpdateResultSet.UpdateResult result = VaroUpdateResultSet.UpdateResult.NO_UPDATE;
/*     */ 
/*     */     
/*     */     try {
/*  88 */       Scanner scanner = new Scanner((new URL("https://api.spiget.org/v2/resources/71075/versions/latest")).openStream());
/*  89 */       String all = "";
/*  90 */       while (scanner.hasNextLine()) {
/*  91 */         all = String.valueOf(all) + scanner.nextLine();
/*     */       }
/*  93 */       scanner.close();
/*     */       
/*  95 */       JSONObject scannerJSON = (JSONObject)JSONValue.parseWithException(all);
/*  96 */       String str1 = scannerJSON.get("name").toString();
/*  97 */       String str2 = scannerJSON.get("id").toString();
/*  98 */       switch (compareVersions(str1, Main.getInstance().getDescription().getVersion())) {
/*     */         case null:
/* 100 */           result = VaroUpdateResultSet.UpdateResult.UPDATE_AVAILABLE;
/*     */           break;
/*     */         case VERSIONS_EQUAL:
/* 103 */           result = VaroUpdateResultSet.UpdateResult.NO_UPDATE;
/*     */           break;
/*     */         case VERSION2GREATER:
/* 106 */           result = VaroUpdateResultSet.UpdateResult.TEST_BUILD;
/*     */           break;
/*     */       } 
/* 109 */     } catch (IOException e) {
/* 110 */       result = VaroUpdateResultSet.UpdateResult.FAIL_SPIGOT;
/* 111 */       String str1 = "";
/* 112 */       String str2 = "";
/* 113 */     } catch (ParseException|IllegalArgumentException e) {
/* 114 */       e.getSuppressed();
/* 115 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Failed to fetch server version!");
/*     */     } finally {
/* 117 */       String str1 = "";
/* 118 */       String str2 = "";
/*     */     } 
/*     */     
/* 121 */     this.lastResult = new VaroUpdateResultSet(result, version, id);
/*     */     
/* 123 */     if (print) {
/* 124 */       printResults();
/*     */     }
/* 126 */     return this.lastResult;
/*     */   }
/*     */   
/*     */   public VaroUpdateResultSet getLastResult() {
/* 130 */     return this.lastResult;
/*     */   }
/*     */   
/*     */   public static int getRescourceId() {
/* 134 */     return 71075;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\spigo\\updater\VaroUpdater.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */