/*    */ package de.cuuky.varo.combatlog;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*    */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*    */ import de.cuuky.varo.entity.player.stats.stat.Strike;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import de.cuuky.varo.logger.logger.EventLogger;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CombatlogCheck
/*    */ {
/*    */   private boolean combatLog;
/*    */   
/*    */   public CombatlogCheck(PlayerQuitEvent event) {
/* 27 */     this.combatLog = false;
/*    */     
/* 29 */     check(event);
/*    */   }
/*    */   
/*    */   private void check(PlayerQuitEvent event) {
/* 33 */     if (Main.getVaroGame().getGameState() == GameState.END || PlayerHit.getHit(event.getPlayer()) == null) {
/*    */       return;
/*    */     }
/*    */     
/* 37 */     VaroPlayer vp = VaroPlayer.getPlayer(event.getPlayer().getName());
/* 38 */     PlayerHit hit = PlayerHit.getHit(event.getPlayer());
/*    */     
/* 40 */     if (hit.getOpponent() != null && hit.getOpponent().isOnline()) {
/* 41 */       PlayerHit.getHit(hit.getOpponent()).over();
/*    */     }
/* 43 */     if (!vp.getStats().isAlive()) {
/*    */       return;
/*    */     }
/*    */     
/* 47 */     if (ConfigSetting.KILL_ON_COMBATLOG.getValueAsBoolean()) {
/* 48 */       event.getPlayer().setHealth(0.0D);
/* 49 */       vp.getStats().setState(PlayerState.DEAD);
/*    */     } 
/*    */     
/* 52 */     this.combatLog = true;
/* 53 */     punish(vp);
/*    */   }
/*    */   
/*    */   private void punish(VaroPlayer player) {
/* 57 */     player.onEvent(BukkitEventType.KICKED);
/*    */     
/* 59 */     if (ConfigSetting.STRIKE_ON_COMBATLOG.getValueAsBoolean()) {
/* 60 */       player.getStats().addStrike(new Strike("CombatLog", player, "CONSOLE"));
/* 61 */       Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, ConfigMessages.ALERT_COMBAT_LOG_STRIKE.getValue(player));
/*    */     } else {
/* 63 */       Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, ConfigMessages.ALERT_COMBAT_LOG.getValue(player));
/*    */     } 
/* 65 */     Bukkit.broadcastMessage(ConfigMessages.COMBAT_LOGGED_OUT.getValue(player));
/*    */   }
/*    */   
/*    */   public boolean isCombatLog() {
/* 69 */     return this.combatLog;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\combatlog\CombatlogCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */