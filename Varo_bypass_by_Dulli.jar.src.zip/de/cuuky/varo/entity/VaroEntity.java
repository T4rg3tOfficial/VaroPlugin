package de.cuuky.varo.entity;

import de.cuuky.varo.serialize.identifier.VaroSerializeable;

public abstract class VaroEntity implements VaroSerializeable {}


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\entity\VaroEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */