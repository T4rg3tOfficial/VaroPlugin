/*    */ package de.cuuky.varo.entity.team;
/*    */ 
/*    */ import de.cuuky.varo.serialize.VaroSerializeObject;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ 
/*    */ public class VaroTeamHandler extends VaroSerializeObject {
/*    */   public VaroTeamHandler() {
/*  8 */     super(VaroTeam.class, "/stats/teams.yml");
/*    */     
/* 10 */     load();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onSave() {
/* 15 */     clearOld();
/*    */     
/* 17 */     for (VaroTeam team : VaroTeam.getTeams()) {
/* 18 */       save(String.valueOf(team.getId()), (VaroSerializeable)team, getConfiguration());
/*    */     }
/* 20 */     saveFile();
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\entity\team\VaroTeamHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */