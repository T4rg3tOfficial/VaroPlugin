/*     */ package de.cuuky.varo.entity.player.disconnect;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*     */ import de.cuuky.varo.entity.player.stats.stat.Strike;
/*     */ import de.cuuky.varo.game.state.GameState;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VaroPlayerDisconnect
/*     */ {
/*  31 */   private static ArrayList<VaroPlayerDisconnect> disconnects = new ArrayList<>();
/*  32 */   private static HashMap<String, Integer> scheds = new HashMap<>();
/*     */   
/*     */   private int amount;
/*     */   
/*     */   private String name;
/*     */   
/*     */   public VaroPlayerDisconnect(Player player) {
/*  39 */     this.name = player.getName();
/*     */     
/*  41 */     disconnects.add(this);
/*     */   }
/*     */   
/*     */   public void addDisconnect() {
/*  45 */     if (VaroPlayer.getPlayer(this.name).getNetworkManager().getPing() >= ConfigSetting.NO_DISCONNECT_PING.getValueAsInt() || playerIsDead()) {
/*     */       return;
/*     */     }
/*  48 */     this.amount++;
/*     */   }
/*     */   
/*     */   public boolean check() {
/*  52 */     if (this.amount <= ConfigSetting.DISCONNECT_PER_SESSION.getValueAsInt()) {
/*  53 */       return false;
/*     */     }
/*  55 */     VaroPlayer vp = VaroPlayer.getPlayer(this.name);
/*  56 */     vp.getStats().setBan();
/*  57 */     if (vp.getStats().hasTimeLeft()) {
/*  58 */       vp.getStats().removeCountdown();
/*     */     }
/*  60 */     if (ConfigSetting.STRIKE_ON_DISCONNECT.getValueAsBoolean()) {
/*  61 */       vp.getStats().addStrike(new Strike("Der Server wurde zu oft verlassen.", vp, "CONSOLE"));
/*     */     }
/*     */     
/*  64 */     Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, ConfigMessages.ALERT_DISCONNECT_TOO_OFTEN.getValue(vp));
/*  65 */     Bukkit.broadcastMessage(ConfigMessages.QUIT_TOO_OFTEN.getValue(vp));
/*  66 */     remove();
/*  67 */     return true;
/*     */   }
/*     */   
/*     */   public int getDisconnects() {
/*  71 */     return this.amount;
/*     */   }
/*     */   
/*     */   public String getPlayer() {
/*  75 */     return this.name;
/*     */   }
/*     */   
/*     */   public boolean playerIsDead() {
/*  79 */     Player player = Bukkit.getPlayerExact(this.name);
/*  80 */     if (player != null && 
/*  81 */       !player.isDead() && VersionUtils.getHearts(player) != 0.0D) {
/*  82 */       return false;
/*     */     }
/*  84 */     return true;
/*     */   }
/*     */   
/*     */   public void remove() {
/*  88 */     disconnects.remove(this);
/*     */   }
/*     */   
/*     */   public static void disconnected(final String playerName) {
/*  92 */     if (!ConfigSetting.BAN_AFTER_DISCONNECT_MINUTES.isIntActivated()) {
/*     */       return;
/*     */     }
/*  95 */     if (Main.getVaroGame().getGameState() != GameState.STARTED) {
/*     */       return;
/*     */     }
/*  98 */     if (!VaroPlayer.getPlayer(playerName).getStats().isAlive()) {
/*     */       return;
/*     */     }
/* 101 */     scheds.put(playerName, Integer.valueOf(Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */             {
/*     */               public void run()
/*     */               {
/* 105 */                 if (Bukkit.getPlayerExact(playerName) != null) {
/*     */                   return;
/*     */                 }
/* 108 */                 if (Main.getVaroGame().getGameState() != GameState.STARTED) {
/*     */                   return;
/*     */                 }
/* 111 */                 VaroPlayer vp = VaroPlayer.getPlayer(playerName);
/* 112 */                 vp.getStats().removeCountdown();
/* 113 */                 vp.getStats().setState(PlayerState.DEAD);
/* 114 */                 Bukkit.broadcastMessage(ConfigMessages.QUIT_DISCONNECT_SESSION_END.getValue(vp).replace("%banTime%", String.valueOf(ConfigSetting.BAN_AFTER_DISCONNECT_MINUTES.getValueAsInt())));
/*     */               }
/* 116 */             }(ConfigSetting.BAN_AFTER_DISCONNECT_MINUTES.getValueAsInt() * 60 * 20))));
/*     */   }
/*     */   
/*     */   public static VaroPlayerDisconnect getDisconnect(Player p) {
/* 120 */     for (VaroPlayerDisconnect disconnect : disconnects) {
/* 121 */       if (disconnect.getPlayer().equals(p.getName()))
/* 122 */         return disconnect; 
/*     */     } 
/* 124 */     return null;
/*     */   }
/*     */   
/*     */   public static void joinedAgain(String playerName) {
/* 128 */     if (!scheds.containsKey(playerName)) {
/*     */       return;
/*     */     }
/* 131 */     Bukkit.getScheduler().cancelTask(((Integer)scheds.get(playerName)).intValue());
/* 132 */     scheds.remove(playerName);
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\entity\player\disconnect\VaroPlayerDisconnect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */