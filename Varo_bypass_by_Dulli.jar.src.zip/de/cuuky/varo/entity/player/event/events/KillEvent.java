/*    */ package de.cuuky.varo.entity.player.event.events;
/*    */ 
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEvent;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import de.cuuky.varo.version.types.Sounds;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class KillEvent extends BukkitEvent {
/*    */   public KillEvent() {
/* 13 */     super(BukkitEventType.KILL);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onExec(VaroPlayer player) {
/* 18 */     if (ConfigSetting.DEATH_SOUND.getValueAsBoolean()) {
/* 19 */       VersionUtils.getOnlinePlayer().forEach(pl -> pl.playSound(pl.getLocation(), Sounds.WITHER_IDLE.bukkitSound(), 1.0F, 1.0F));
/*    */     }
/* 21 */     player.getStats().addKill();
/* 22 */     super.onExec(player);
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\entity\player\event\events\KillEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */