/*    */ package de.cuuky.varo.entity.player.event.events;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEvent;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*    */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.InventoryBackup;
/*    */ import de.cuuky.varo.entity.player.stats.stat.offlinevillager.OfflineVillager;
/*    */ 
/*    */ public class QuitEvent
/*    */   extends BukkitEvent {
/*    */   public QuitEvent() {
/* 15 */     super(BukkitEventType.QUIT);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onExec(VaroPlayer player) {
/* 20 */     if (Main.getVaroGame().isRunning() && player.getStats().getState() == PlayerState.ALIVE) {
/* 21 */       player.getStats().addInventoryBackup(new InventoryBackup(player));
/*    */       
/* 23 */       if (ConfigSetting.OFFLINEVILLAGER.getValueAsBoolean()) {
/* 24 */         player.setVillager(new OfflineVillager(player, player.getPlayer().getLocation()));
/*    */       }
/*    */     } 
/* 27 */     if (!player.getStats().hasTimeLeft()) {
/* 28 */       player.getStats().removeCountdown();
/*    */     }
/* 30 */     player.getStats().setLastLocation(player.getPlayer().getLocation());
/* 31 */     if (player.getNametag() != null)
/* 32 */       player.getNametag().remove(); 
/* 33 */     player.setNametag(null);
/* 34 */     player.setNetworkManager(null);
/* 35 */     player.setAdminIgnore(false);
/* 36 */     player.setPlayer(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\entity\player\event\events\QuitEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */