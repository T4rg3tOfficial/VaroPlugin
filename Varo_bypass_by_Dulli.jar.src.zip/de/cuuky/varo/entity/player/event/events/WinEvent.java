/*    */ package de.cuuky.varo.entity.player.event.events;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.bot.discord.VaroDiscordBot;
/*    */ import de.cuuky.varo.bot.discord.register.BotRegister;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEvent;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*    */ import net.dv8tion.jda.api.entities.Member;
/*    */ import net.dv8tion.jda.api.exceptions.PermissionException;
/*    */ 
/*    */ public class WinEvent
/*    */   extends BukkitEvent {
/*    */   public WinEvent() {
/* 16 */     super(BukkitEventType.WIN);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onExec(VaroPlayer player) {
/* 21 */     player.getStats().addWin();
/* 22 */     VaroDiscordBot db = Main.getBotLauncher().getDiscordbot();
/*    */     
/* 24 */     if (db != null && (
/* 25 */       db.isEnabled() || !ConfigSetting.DISCORDBOT_ADD_POKAL_ON_WIN.getValueAsBoolean())) {
/*    */       return;
/*    */     }
/* 28 */     BotRegister register = BotRegister.getBotRegisterByPlayerName(player.getName());
/* 29 */     if (register == null) {
/*    */       return;
/*    */     }
/* 32 */     Member member = register.getMember();
/* 33 */     int wins = 1;
/* 34 */     String name = (member.getNickname() == null) ? member.getUser().getName() : member.getNickname();
/*    */     
/* 36 */     if (name.contains("|")) {
/* 37 */       wins = Integer.valueOf(name.split("\\|")[1].replace("ð", "").replace(" ", "")).intValue();
/* 38 */       wins++;
/*    */     } 
/*    */     
/*    */     try {
/* 42 */       member.modifyNickname(String.valueOf(member.getUser().getName()) + " | " + wins + " ð");
/* 43 */     } catch (PermissionException e) {
/* 44 */       System.out.println("[Varo] Konnte den Pokal fuer '" + player.getName() + "' nicht setzen, da dieser Bot zu wenig, oder der Nutzer zu viele Rechte auf dem Discord hat!");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\entity\player\event\events\WinEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */