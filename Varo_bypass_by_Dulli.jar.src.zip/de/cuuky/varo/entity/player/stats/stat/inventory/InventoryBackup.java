/*     */ package de.cuuky.varo.entity.player.stats.stat.inventory;
/*     */ 
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.VaroInventory;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InventoryBackup
/*     */   implements VaroSerializeable
/*     */ {
/*  19 */   private static ArrayList<InventoryBackup> allBackups = new ArrayList<>();
/*     */   
/*     */   @VaroSerializeField(path = "armor")
/*     */   private ArrayList<ItemStack> armor;
/*     */   
/*     */   @VaroSerializeField(path = "date")
/*     */   private Date date;
/*     */   
/*     */   @VaroSerializeField(path = "inventory")
/*     */   private VaroInventory inventory;
/*     */   
/*     */   private VaroPlayer varoplayer;
/*     */   
/*     */   @VaroSerializeField(path = "playerId")
/*     */   private int vpId;
/*     */ 
/*     */   
/*     */   public InventoryBackup() {
/*  37 */     allBackups.add(this);
/*     */   }
/*     */   
/*     */   public InventoryBackup(VaroPlayer vp) {
/*  41 */     this.varoplayer = vp;
/*  42 */     this.date = new Date();
/*  43 */     this.inventory = new VaroInventory(45);
/*  44 */     this.armor = new ArrayList<>();
/*     */     
/*  46 */     if (vp.isOnline()) {
/*  47 */       addUpdate(vp.getPlayer());
/*     */     }
/*  49 */     allBackups.add(this);
/*     */   }
/*     */   
/*     */   public void addUpdate(Player player) {
/*  53 */     this.inventory.getInventory().setContents(player.getInventory().getContents());
/*  54 */     this.armor = new ArrayList<>(); byte b; int i;
/*     */     ItemStack[] arrayOfItemStack;
/*  56 */     for (i = (arrayOfItemStack = player.getInventory().getArmorContents()).length, b = 0; b < i; ) { ItemStack l = arrayOfItemStack[b];
/*  57 */       this.armor.add(l);
/*     */       b++; }
/*     */   
/*     */   } public ArrayList<ItemStack> getArmor() {
/*  61 */     return this.armor;
/*     */   }
/*     */   
/*     */   public Date getDate() {
/*  65 */     return this.date;
/*     */   }
/*     */   
/*     */   public VaroInventory getInventory() {
/*  69 */     return this.inventory;
/*     */   }
/*     */   
/*     */   public VaroPlayer getVaroPlayer() {
/*  73 */     return this.varoplayer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {
/*  78 */     this.varoplayer = VaroPlayer.getPlayer(this.vpId);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSerializeStart() {
/*  83 */     if (this.varoplayer != null)
/*  84 */       this.vpId = this.varoplayer.getId(); 
/*     */   }
/*     */   
/*     */   public void remove() {
/*  88 */     allBackups.remove(this);
/*     */   }
/*     */   
/*     */   public void restoreUpdate(Player player) {
/*  92 */     player.getInventory().clear();
/*     */     
/*     */     try {
/*  95 */       for (int j = 0; j < (this.inventory.getInventory().getContents()).length; j++)
/*  96 */         player.getInventory().setItem(j, this.inventory.getInventory().getContents()[j]); 
/*  97 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
/*     */     
/*  99 */     ItemStack[] armorc = new ItemStack[4];
/* 100 */     for (int i = 0; i < this.armor.size(); i++)
/* 101 */       armorc[i] = this.armor.get(i); 
/* 102 */     player.getInventory().setArmorContents(armorc);
/*     */     
/* 104 */     player.updateInventory();
/*     */   }
/*     */   
/*     */   public static ArrayList<InventoryBackup> getAllBackups() {
/* 108 */     return allBackups;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\entity\player\stats\stat\inventory\InventoryBackup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */