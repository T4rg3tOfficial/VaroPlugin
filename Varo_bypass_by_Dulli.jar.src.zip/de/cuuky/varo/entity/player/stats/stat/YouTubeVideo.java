/*     */ package de.cuuky.varo.entity.player.stats.stat;
/*     */ 
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YouTubeVideo
/*     */   implements VaroSerializeable, Comparable<YouTubeVideo>
/*     */ {
/*  15 */   private static ArrayList<YouTubeVideo> videos = new ArrayList<>();
/*     */   
/*     */   @VaroSerializeField(path = "detectedAt")
/*     */   private Date detectedAt;
/*     */   
/*     */   @VaroSerializeField(path = "duration")
/*     */   private String duration;
/*     */   
/*     */   @VaroSerializeField(path = "link")
/*     */   private String link;
/*     */   
/*     */   @VaroSerializeField(path = "title")
/*     */   private String title;
/*     */   
/*     */   @VaroSerializeField(path = "videoId")
/*     */   private String videoId;
/*     */ 
/*     */   
/*     */   public YouTubeVideo() {
/*  34 */     videos.add(this);
/*     */   }
/*     */   
/*     */   public YouTubeVideo(String videoId, String title, String link, String duration) {
/*  38 */     this.videoId = videoId;
/*  39 */     this.title = title;
/*  40 */     this.link = link;
/*  41 */     this.duration = duration;
/*  42 */     this.detectedAt = new Date();
/*     */     
/*  44 */     videos.add(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(YouTubeVideo comparison) {
/*  50 */     return getDetectedAt().getDate() - comparison.getDetectedAt().getDate();
/*     */   }
/*     */   
/*     */   public Date getDetectedAt() {
/*  54 */     return this.detectedAt;
/*     */   }
/*     */   
/*     */   public String getDuration() {
/*  58 */     return this.duration;
/*     */   }
/*     */   
/*     */   public String getLink() {
/*  62 */     return this.link;
/*     */   }
/*     */   
/*     */   public VaroPlayer getOwner() {
/*  66 */     for (VaroPlayer vp : VaroPlayer.getVaroPlayer()) {
/*  67 */       if (vp.getStats().getVideos().contains(this))
/*  68 */         return vp; 
/*     */     } 
/*  70 */     return null;
/*     */   }
/*     */   
/*     */   public String getTitle() {
/*  74 */     return this.title;
/*     */   }
/*     */   
/*     */   public String getVideoId() {
/*  78 */     return this.videoId;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {}
/*     */ 
/*     */   
/*     */   public void onSerializeStart() {}
/*     */   
/*     */   public void remove() {
/*  88 */     VaroPlayer owner = getOwner();
/*  89 */     if (owner != null) {
/*  90 */       owner.getStats().removeVideo(this);
/*     */     }
/*  92 */     videos.remove(this);
/*     */   }
/*     */   
/*     */   public static YouTubeVideo getVideo(String videoId) {
/*  96 */     for (YouTubeVideo video : videos) {
/*  97 */       if (video.getVideoId().equals(videoId))
/*  98 */         return video; 
/*     */     } 
/* 100 */     return null;
/*     */   }
/*     */   
/*     */   public static ArrayList<YouTubeVideo> getVideos() {
/* 104 */     return videos;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\entity\player\stats\stat\YouTubeVideo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */