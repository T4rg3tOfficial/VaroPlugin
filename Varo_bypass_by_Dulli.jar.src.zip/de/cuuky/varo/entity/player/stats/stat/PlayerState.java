/*    */ package de.cuuky.varo.entity.player.stats.stat;
/*    */ 
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ 
/*    */ public enum PlayerState
/*    */   implements VaroSerializeable {
/*  8 */   ALIVE(
/*  9 */     "ALIVE"),
/* 10 */   DEAD(
/* 11 */     "DEAD"),
/* 12 */   SPECTATOR(
/* 13 */     "SPECTATOR");
/*    */   
/*    */   private String name;
/*    */   
/*    */   PlayerState(String name) {
/* 18 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 22 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDeserializeEnd() {}
/*    */ 
/*    */   
/*    */   public void onSerializeStart() {}
/*    */ 
/*    */   
/*    */   public String toString() {
/* 33 */     return this.name; } public static PlayerState getByName(String name) {
/*    */     byte b;
/*    */     int i;
/*    */     PlayerState[] arrayOfPlayerState;
/* 37 */     for (i = (arrayOfPlayerState = values()).length, b = 0; b < i; ) { PlayerState state = arrayOfPlayerState[b];
/* 38 */       if (state.getName().equalsIgnoreCase(name))
/* 39 */         return state;  b++; }
/*    */     
/* 41 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\entity\player\stats\stat\PlayerState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */