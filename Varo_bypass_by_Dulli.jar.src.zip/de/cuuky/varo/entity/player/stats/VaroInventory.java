/*    */ package de.cuuky.varo.entity.player.stats;
/*    */ 
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ import de.cuuky.varo.utils.JavaUtils;
/*    */ import java.util.HashMap;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroInventory
/*    */   implements VaroSerializeable
/*    */ {
/*    */   @VaroSerializeField(path = "inventory")
/*    */   private HashMap<String, ItemStack> inventoryList;
/*    */   @VaroSerializeField(path = "size")
/*    */   private int size;
/*    */   private Inventory inventory;
/*    */   
/*    */   public VaroInventory() {}
/*    */   
/*    */   public VaroInventory(int size) {
/* 27 */     this.inventoryList = new HashMap<>();
/* 28 */     this.size = (54 < size) ? 54 : ((size < 9) ? 9 : JavaUtils.getNextToNine(size));
/*    */     
/* 30 */     createInventory();
/*    */   }
/*    */   
/*    */   private void createInventory() {
/* 34 */     this.inventory = Bukkit.createInventory(null, this.size, "§aBackpack");
/*    */   }
/*    */   
/*    */   public void clear() {
/* 38 */     this.inventoryList.clear();
/* 39 */     this.inventory.clear();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDeserializeEnd() {
/* 44 */     createInventory();
/*    */     
/* 46 */     for (String i : this.inventoryList.keySet()) {
/* 47 */       this.inventory.setItem(Integer.valueOf(i).intValue(), this.inventoryList.get(i));
/*    */     }
/*    */   }
/*    */   
/*    */   public void onSerializeStart() {
/* 52 */     for (int i = 0; i < this.inventory.getSize(); i++) {
/* 53 */       ItemStack stack = this.inventory.getItem(i);
/* 54 */       if (stack != null && stack.getType() != Material.AIR)
/* 55 */         this.inventoryList.put(String.valueOf(i), stack); 
/*    */     } 
/*    */   }
/*    */   
/*    */   public Inventory getInventory() {
/* 60 */     return this.inventory;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\entity\player\stats\VaroInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */