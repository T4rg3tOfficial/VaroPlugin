/*     */ package de.cuuky.varo.entity.player;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.bot.discord.VaroDiscordBot;
/*     */ import de.cuuky.varo.bot.discord.register.BotRegister;
/*     */ import de.cuuky.varo.clientadapter.nametag.Nametag;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.VaroEntity;
/*     */ import de.cuuky.varo.entity.player.connection.NetworkManager;
/*     */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*     */ import de.cuuky.varo.entity.player.stats.Stats;
/*     */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*     */ import de.cuuky.varo.entity.player.stats.stat.Rank;
/*     */ import de.cuuky.varo.entity.player.stats.stat.offlinevillager.OfflineVillager;
/*     */ import de.cuuky.varo.entity.team.VaroTeam;
/*     */ import de.cuuky.varo.event.VaroEvent;
/*     */ import de.cuuky.varo.event.VaroEventType;
/*     */ import de.cuuky.varo.game.lobby.LobbyItem;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import de.cuuky.varo.utils.JavaUtils;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.UUID;
/*     */ import net.dv8tion.jda.api.entities.Member;
/*     */ import net.dv8tion.jda.api.entities.Role;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VaroPlayer
/*     */   extends VaroEntity
/*     */ {
/*  46 */   private static ArrayList<VaroPlayer> varoplayer = new ArrayList<>();
/*     */   
/*     */   @VaroSerializeField(path = "id")
/*     */   private int id;
/*     */   
/*     */   @VaroSerializeField(path = "name")
/*     */   private String name;
/*     */   
/*     */   @VaroSerializeField(path = "uuid")
/*     */   private String uuid;
/*     */   
/*     */   @VaroSerializeField(path = "adminIgnore")
/*     */   private boolean adminIgnore;
/*     */   
/*     */   @VaroSerializeField(path = "villager")
/*     */   private OfflineVillager villager;
/*     */   
/*     */   @VaroSerializeField(path = "rank")
/*     */   private Rank rank;
/*     */   
/*     */   @VaroSerializeField(path = "stats")
/*     */   private Stats stats;
/*     */   private Nametag nametag;
/*     */   private NetworkManager networkManager;
/*     */   private String tabName;
/*     */   private VaroTeam team;
/*     */   private Player player;
/*     */   private boolean alreadyHadMassProtectionTime;
/*     */   private boolean inMassProtectionTime;
/*     */   private boolean massRecordingKick;
/*     */   
/*     */   public VaroPlayer() {
/*  78 */     varoplayer.add(this);
/*     */   }
/*     */   
/*     */   public VaroPlayer(Player player) {
/*  82 */     this.name = player.getName();
/*  83 */     this.uuid = player.getUniqueId().toString();
/*  84 */     this.player = player;
/*  85 */     this.id = generateId();
/*  86 */     this.adminIgnore = false;
/*     */     
/*  88 */     this.stats = new Stats(this);
/*     */   }
/*     */   
/*     */   public VaroPlayer(String playerName, String uuid) {
/*  92 */     this.name = playerName;
/*  93 */     this.uuid = uuid;
/*     */     
/*  95 */     this.adminIgnore = false;
/*  96 */     this.id = generateId();
/*     */     
/*  98 */     varoplayer.add(this);
/*  99 */     this.stats = new Stats(this);
/* 100 */     this.stats.loadDefaults();
/*     */   }
/*     */   
/*     */   private int generateId() {
/* 104 */     int id = JavaUtils.randomInt(1000, 9999999);
/* 105 */     while (getPlayer(id) != null) {
/* 106 */       generateId();
/*     */     }
/* 108 */     return id;
/*     */   }
/*     */   
/*     */   private void updateDiscordTeam(VaroTeam oldTeam) {
/* 112 */     VaroDiscordBot db = Main.getBotLauncher().getDiscordbot();
/* 113 */     if (db == null || !db.isEnabled()) {
/*     */       return;
/*     */     }
/* 116 */     BotRegister reg = BotRegister.getBotRegisterByPlayerName(this.name);
/* 117 */     if (reg == null) {
/*     */       return;
/*     */     }
/* 120 */     Member member = reg.getMember();
/* 121 */     if (oldTeam != null && 
/* 122 */       db.getMainGuild().getRolesByName("#" + oldTeam.getName(), true).size() > 0) {
/* 123 */       Role role = db.getMainGuild().getRolesByName("#" + oldTeam.getName(), true).get(0);
/* 124 */       db.getMainGuild().removeRoleFromMember(member, role).complete();
/*     */     } 
/*     */ 
/*     */     
/* 128 */     if (this.team != null) {
/* 129 */       Role role = (db.getMainGuild().getRolesByName("#" + this.team.getName(), true).size() > 0) ? db.getMainGuild().getRolesByName("#" + this.team.getName(), true).get(0) : null;
/* 130 */       if (role == null) {
/* 131 */         role = (Role)db.getMainGuild().createCopyOfRole(db.getMainGuild().getPublicRole()).setHoisted(Boolean.valueOf(true)).setName("#" + this.team.getName()).complete();
/*     */       }
/* 133 */       db.getMainGuild().addRoleToMember(member, role).complete();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canBeKicked(int noKickDistance) {
/* 142 */     if (noKickDistance < 1) {
/* 143 */       return true;
/*     */     }
/* 145 */     for (Entity entity : this.player.getNearbyEntities(noKickDistance, noKickDistance, noKickDistance)) {
/* 146 */       if (!(entity instanceof Player)) {
/*     */         continue;
/*     */       }
/* 149 */       VaroPlayer vp = getPlayer((Player)entity);
/* 150 */       if (vp.equals(this)) {
/*     */         continue;
/*     */       }
/* 153 */       if (vp.getTeam() != null && 
/* 154 */         vp.getTeam().equals(this.team)) {
/*     */         continue;
/*     */       }
/* 157 */       if (vp.getStats().isSpectator() || vp.isAdminIgnore()) {
/*     */         continue;
/*     */       }
/* 160 */       return false;
/*     */     } 
/*     */     
/* 163 */     return true;
/*     */   }
/*     */   
/*     */   public void cleanUpPlayer() {
/* 167 */     this.player.setHealth(20.0D);
/* 168 */     this.player.setFoodLevel(20);
/* 169 */     this.player.getInventory().clear();
/* 170 */     this.player.getInventory().setArmorContents(new org.bukkit.inventory.ItemStack[0]);
/* 171 */     this.player.setExp(0.0F);
/* 172 */     this.player.setLevel(0);
/*     */   }
/*     */   
/*     */   public void delete() {
/* 176 */     if (this.team != null) {
/* 177 */       this.team.removeMember(this);
/*     */     }
/* 179 */     if (this.rank != null) {
/* 180 */       this.rank.remove();
/*     */     }
/* 182 */     if (isOnline()) {
/* 183 */       this.player.kickPlayer(ConfigMessages.JOIN_KICK_NOT_USER_OF_PROJECT.getValue(this));
/*     */     }
/* 185 */     if (this.villager != null) {
/* 186 */       this.villager.remove();
/*     */     }
/* 188 */     this.stats.remove();
/* 189 */     varoplayer.remove(this);
/* 190 */     Main.getVaroGame().getTopScores().update();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {
/* 195 */     this.player = (Bukkit.getPlayer(getRealUUID()) != null) ? Bukkit.getPlayer(getRealUUID()) : null;
/* 196 */     if (isOnline()) {
/* 197 */       update();
/*     */       
/* 199 */       if (getStats().isSpectator() || isAdminIgnore()) {
/* 200 */         setSpectacting();
/*     */       }
/* 202 */       setNormalAttackSpeed();
/* 203 */       LobbyItem.giveItems(this.player);
/* 204 */     } else if (isAdminIgnore()) {
/* 205 */       this.adminIgnore = false;
/*     */     } 
/* 207 */     this.stats.setOwner(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEvent(BukkitEventType type) {}
/*     */ 
/*     */   
/*     */   public void onSerializeStart() {}
/*     */ 
/*     */   
/*     */   public void register() {
/* 218 */     if (this.stats == null) {
/* 219 */       this.stats = new Stats(this);
/*     */     }
/* 221 */     this.stats.loadDefaults();
/* 222 */     varoplayer.add(this);
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/* 226 */     String pr = "";
/* 227 */     if (this.team != null) {
/* 228 */       pr = String.valueOf(this.team.getDisplay()) + " ";
/*     */     }
/* 230 */     if (this.rank != null) {
/* 231 */       pr = String.valueOf(this.rank.getDisplay()) + (pr.isEmpty() ? " " : " §8| ") + pr;
/*     */     }
/* 233 */     return pr;
/*     */   }
/*     */   
/*     */   public void setSpectacting() {
/* 237 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           
/*     */           public void run()
/*     */           {
/* 242 */             VaroPlayer.this.player.getPlayer().setGameMode(GameMode.ADVENTURE);
/* 243 */             VaroPlayer.this.player.getPlayer().setAllowFlight(true);
/* 244 */             VaroPlayer.this.player.getPlayer().setFlying(true);
/* 245 */             VaroPlayer.this.player.getPlayer().setHealth(20.0D);
/* 246 */             VaroPlayer.this.player.getPlayer().setFoodLevel(20);
/*     */             
/* 248 */             if (!VaroPlayer.this.adminIgnore) {
/* 249 */               VaroPlayer.this.player.getInventory().clear();
/* 250 */               VaroPlayer.this.player.getInventory().setArmorContents(new org.bukkit.inventory.ItemStack[0]);
/*     */             } 
/*     */           }
/* 253 */         },  1L);
/*     */   }
/*     */   
/*     */   public void update() {
/* 257 */     if (!isOnline()) {
/*     */       return;
/*     */     }
/* 260 */     if (!this.player.isOnline()) {
/* 261 */       this.player = null;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 266 */     if (ConfigSetting.NAMETAGS.getValueAsBoolean()) {
/* 267 */       if (this.nametag == null) {
/* 268 */         this.nametag = new Nametag(this.player.getUniqueId(), this.player);
/*     */       } else {
/* 270 */         this.nametag.refresh();
/*     */       } 
/*     */     }
/* 273 */     if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7) && 
/* 274 */       ConfigSetting.TABLIST.getValueAsBoolean()) {
/* 275 */       Main.getDataManager().getTablistHandler().updatePlayer(this);
/*     */     }
/* 277 */     Main.getDataManager().getScoreboardHandler().updatePlayer(this);
/*     */     
/* 279 */     String listname = "";
/* 280 */     if (getTeam() != null) {
/* 281 */       if (getRank() == null) {
/* 282 */         listname = ConfigMessages.TABLIST_PLAYER_WITH_TEAM.getValue(this);
/*     */       } else {
/* 284 */         listname = ConfigMessages.TABLIST_PLAYER_WITH_TEAM_RANK.getValue(this);
/*     */       }
/*     */     
/* 287 */     } else if (getRank() == null) {
/* 288 */       listname = ConfigMessages.TABLIST_PLAYER_WITHOUT_TEAM.getValue(this);
/*     */     } else {
/* 290 */       listname = ConfigMessages.TABLIST_PLAYER_WITHOUT_TEAM_RANK.getValue(this);
/*     */     } 
/*     */ 
/*     */     
/* 294 */     if (this.tabName == null || !this.tabName.equals(listname))
/* 295 */       this.player.setPlayerListName(this.tabName = listname); 
/*     */   }
/*     */   
/*     */   public boolean getalreadyHadMassProtectionTime() {
/* 299 */     return this.alreadyHadMassProtectionTime;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 303 */     return this.id;
/*     */   }
/*     */   
/*     */   public boolean getinMassProtectionTime() {
/* 307 */     return this.inMassProtectionTime;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 311 */     return this.name;
/*     */   }
/*     */   
/*     */   public Nametag getNametag() {
/* 315 */     return this.nametag;
/*     */   }
/*     */   
/*     */   public NetworkManager getNetworkManager() {
/* 319 */     return (this.networkManager == null) ? (this.networkManager = new NetworkManager(this.player)) : this.networkManager;
/*     */   }
/*     */   
/*     */   public Player getPlayer() {
/* 323 */     return this.player;
/*     */   }
/*     */   
/*     */   public Rank getRank() {
/* 327 */     return this.rank;
/*     */   }
/*     */   
/*     */   public UUID getRealUUID() {
/* 331 */     return UUID.fromString(this.uuid);
/*     */   }
/*     */   
/*     */   public Stats getStats() {
/* 335 */     return this.stats;
/*     */   }
/*     */   
/*     */   public VaroTeam getTeam() {
/* 339 */     return this.team;
/*     */   }
/*     */   
/*     */   public String getUuid() {
/* 343 */     return this.uuid;
/*     */   }
/*     */   
/*     */   public OfflineVillager getVillager() {
/* 347 */     return this.villager;
/*     */   }
/*     */   
/*     */   public boolean isAdminIgnore() {
/* 351 */     return this.adminIgnore;
/*     */   }
/*     */   
/*     */   public boolean isInProtection() {
/* 355 */     if (VaroEvent.getEvent(VaroEventType.MASS_RECORDING).isEnabled()) {
/* 356 */       return this.inMassProtectionTime;
/*     */     }
/* 358 */     return (ConfigSetting.PLAY_TIME.isIntActivated() && this.stats.getCountdown() >= ConfigSetting.PLAY_TIME.getValueAsInt() * 60 - ConfigSetting.JOIN_PROTECTIONTIME.getValueAsInt());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMassRecordingKick() {
/* 363 */     return this.massRecordingKick;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOnline() {
/* 370 */     return (this.player != null);
/*     */   }
/*     */   
/*     */   public boolean isRegistered() {
/* 374 */     return varoplayer.contains(this);
/*     */   }
/*     */   
/*     */   public void sendMessage(String message) {
/* 378 */     this.player.sendMessage(message);
/*     */   }
/*     */   
/*     */   public void setAdminIgnore(boolean adminIgnore) {
/* 382 */     this.adminIgnore = adminIgnore;
/*     */   }
/*     */   
/*     */   public void setalreadyHadMassProtectionTime(boolean alreadyHadMassProtectionTime) {
/* 386 */     this.alreadyHadMassProtectionTime = alreadyHadMassProtectionTime;
/*     */   }
/*     */   
/*     */   public void setinMassProtectionTime(boolean inMassProtectionTime) {
/* 390 */     this.inMassProtectionTime = inMassProtectionTime;
/*     */   }
/*     */   
/*     */   public void setMassRecordingKick(boolean massRecordingKick) {
/* 394 */     this.massRecordingKick = massRecordingKick;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 398 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void setNametag(Nametag nametag) {
/* 402 */     this.nametag = nametag;
/*     */   }
/*     */   
/*     */   public void setNetworkManager(NetworkManager networkManager) {
/* 406 */     this.networkManager = networkManager;
/*     */   }
/*     */   
/*     */   public void setNormalAttackSpeed() {
/* 410 */     getNetworkManager().setAttributeSpeed(!ConfigSetting.REMOVE_HIT_COOLDOWN.getValueAsBoolean() ? 4.0D : 100.0D);
/*     */   }
/*     */   
/*     */   public void setPlayer(Player player) {
/* 414 */     this.player = player;
/*     */   }
/*     */   
/*     */   public void setRank(Rank rank) {
/* 418 */     this.rank = rank;
/* 419 */     update();
/*     */   }
/*     */   
/*     */   public void setUuid(String uuid) {
/* 423 */     this.uuid = uuid;
/*     */   }
/*     */   
/*     */   public void setVillager(OfflineVillager villager) {
/* 427 */     this.villager = villager;
/*     */   }
/*     */   
/*     */   public void setTeam(VaroTeam team) {
/* 431 */     VaroTeam oldTeam = this.team;
/* 432 */     this.team = team;
/*     */     
/* 434 */     if (!Main.isBootedUp()) {
/*     */       return;
/*     */     }
/*     */     try {
/* 438 */       if (ConfigSetting.DISCORDBOT_SET_TEAM_AS_GROUP.getValueAsBoolean())
/* 439 */         updateDiscordTeam(oldTeam); 
/* 440 */     } catch (Exception e) {
/* 441 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 444 */     update();
/* 445 */     Main.getVaroGame().getTopScores().update();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayList<VaroPlayer> getAlivePlayer() {
/* 452 */     ArrayList<VaroPlayer> alive = new ArrayList<>();
/* 453 */     for (VaroPlayer vp : varoplayer) {
/* 454 */       if (!vp.getStats().isAlive()) {
/*     */         continue;
/*     */       }
/* 457 */       alive.add(vp);
/*     */     } 
/*     */     
/* 460 */     return alive;
/*     */   }
/*     */   
/*     */   public static ArrayList<VaroPlayer> getDeadPlayer() {
/* 464 */     ArrayList<VaroPlayer> dead = new ArrayList<>();
/* 465 */     for (VaroPlayer vp : varoplayer) {
/* 466 */       if (vp.getStats().getState() != PlayerState.DEAD) {
/*     */         continue;
/*     */       }
/* 469 */       dead.add(vp);
/*     */     } 
/*     */     
/* 472 */     return dead;
/*     */   }
/*     */   
/*     */   public static ArrayList<VaroPlayer> getOnlineAndAlivePlayer() {
/* 476 */     ArrayList<VaroPlayer> online = new ArrayList<>();
/* 477 */     for (VaroPlayer vp : varoplayer) {
/* 478 */       if (!vp.isOnline() || !vp.getStats().isAlive()) {
/*     */         continue;
/*     */       }
/* 481 */       online.add(vp);
/*     */     } 
/*     */     
/* 484 */     return online;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayList<VaroPlayer> getOnlinePlayer() {
/* 491 */     ArrayList<VaroPlayer> online = new ArrayList<>();
/* 492 */     for (VaroPlayer vp : varoplayer) {
/* 493 */       if (!vp.isOnline()) {
/*     */         continue;
/*     */       }
/* 496 */       online.add(vp);
/*     */     } 
/*     */     
/* 499 */     return online;
/*     */   }
/*     */   
/*     */   public static VaroPlayer getPlayer(int id) {
/* 503 */     for (VaroPlayer vp : varoplayer) {
/* 504 */       if (vp.getId() != id) {
/*     */         continue;
/*     */       }
/* 507 */       return vp;
/*     */     } 
/*     */     
/* 510 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VaroPlayer getPlayer(Player player) {
/* 518 */     for (VaroPlayer vp : varoplayer) {
/* 519 */       if (vp.getUuid() != null && 
/* 520 */         !vp.getUuid().equals(player.getUniqueId().toString())) {
/*     */         continue;
/*     */       }
/* 523 */       if (vp.getUuid() == null && player.getName().equalsIgnoreCase(vp.getName())) {
/* 524 */         vp.setUuid(player.getUniqueId().toString());
/* 525 */       } else if (vp.getUuid() == null) {
/*     */         continue;
/*     */       } 
/* 528 */       if (!vp.getName().equalsIgnoreCase(player.getName())) {
/* 529 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, ConfigMessages.ALERT_SWITCHED_NAME.getValue(vp).replace("%newName%", player.getName()));
/* 530 */         Bukkit.broadcastMessage("§c" + vp.getName() + " §7hat seinen Namen gewechselt und ist nun unter §c" + player.getName() + " §7bekannt!");
/*     */         
/* 532 */         vp.setName(player.getName());
/*     */       } 
/*     */       
/* 535 */       return vp;
/*     */     } 
/*     */     
/* 538 */     return null;
/*     */   }
/*     */   
/*     */   public static VaroPlayer getPlayer(String name) {
/* 542 */     for (VaroPlayer vp : varoplayer) {
/* 543 */       if (!vp.getName().equalsIgnoreCase(name)) {
/*     */         continue;
/*     */       }
/* 546 */       return vp;
/*     */     } 
/*     */     
/* 549 */     return null;
/*     */   }
/*     */   
/*     */   public static ArrayList<VaroPlayer> getSpectator() {
/* 553 */     ArrayList<VaroPlayer> spectator = new ArrayList<>();
/* 554 */     for (VaroPlayer vp : varoplayer) {
/* 555 */       if (!vp.getStats().isSpectator()) {
/*     */         continue;
/*     */       }
/* 558 */       spectator.add(vp);
/*     */     } 
/*     */     
/* 561 */     return spectator;
/*     */   }
/*     */   
/*     */   public static ArrayList<VaroPlayer> getVaroPlayer() {
/* 565 */     return varoplayer;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\entity\player\VaroPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */