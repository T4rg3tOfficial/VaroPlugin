/*     */ package de.cuuky.varo.entity.player.connection;
/*     */ 
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NetworkManager
/*     */ {
/*     */   private static Class<?> chatMessageTypeClass;
/*     */   private static Object genericSpeedType;
/*     */   private static Class<?> ioBase;
/*     */   private static Class<?> ioBaseChat;
/*     */   private static Class<?> titleClass;
/*     */   private static Constructor<?> titleConstructor;
/*     */   private static Class<?> packetChatClass;
/*     */   private static Class<?> tablistClass;
/*     */   private static Method ioBaseChatMethod;
/*     */   private static Object title;
/*     */   private static Object subtitle;
/*     */   private static Constructor<?> chatByteMethod;
/*     */   private static Constructor<?> chatEnumMethod;
/*     */   private static Object healthPacket;
/*     */   private Object connection;
/*     */   private Field footerField;
/*     */   private Field headerField;
/*     */   private Player player;
/*     */   private Object playerHandle;
/*     */   private Method sendPacketMethod;
/*     */   private Object tablist;
/*     */   private Field pingField;
/*     */   
/*     */   static {
/*     */     try {
/*  41 */       if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*  42 */         ioBaseChat = VersionUtils.getChatSerializer();
/*     */         
/*  44 */         ioBase = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".IChatBaseComponent");
/*  45 */         titleClass = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".PacketPlayOutTitle");
/*     */         
/*  47 */         Class<?> enumTitleClass = null;
/*     */         try {
/*  49 */           enumTitleClass = titleClass.getDeclaredClasses()[0];
/*  50 */         } catch (Exception e) {
/*  51 */           enumTitleClass = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".EnumTitleAction");
/*     */         } 
/*     */         
/*     */         try {
/*  55 */           title = enumTitleClass.getDeclaredField("TITLE").get((Object)null);
/*  56 */           subtitle = enumTitleClass.getDeclaredField("SUBTITLE").get((Object)null);
/*  57 */         } catch (Exception e) {
/*  58 */           e.printStackTrace();
/*     */         } 
/*     */         
/*  61 */         packetChatClass = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".PacketPlayOutChat");
/*     */         try {
/*  63 */           chatMessageTypeClass = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".ChatMessageType");
/*  64 */           chatEnumMethod = packetChatClass.getConstructor(new Class[] { ioBase, chatMessageTypeClass });
/*  65 */         } catch (Exception e) {
/*  66 */           chatByteMethod = packetChatClass.getConstructor(new Class[] { ioBase, byte.class });
/*     */         } 
/*     */         
/*  69 */         titleConstructor = titleClass.getConstructor(new Class[] { enumTitleClass, ioBase, int.class, int.class, int.class });
/*     */         
/*  71 */         tablistClass = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".PacketPlayOutPlayerListHeaderFooter");
/*  72 */         ioBaseChatMethod = ioBaseChat.getDeclaredMethod("a", new Class[] { String.class });
/*     */         
/*  74 */         healthPacket = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".PacketPlayOutUpdateHealth").newInstance(); byte b; int i; Field[] arrayOfField;
/*  75 */         for (i = (arrayOfField = healthPacket.getClass().getDeclaredFields()).length, b = 0; b < i; ) { Field f = arrayOfField[b];
/*  76 */           f.setAccessible(true);
/*  77 */           f.set(healthPacket, Integer.valueOf(0)); b++; }
/*     */       
/*     */       } 
/*  80 */     } catch (ClassNotFoundException|NoSuchMethodException|SecurityException|InstantiationException|IllegalAccessException e) {
/*  81 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NetworkManager(Player player) {
/*  97 */     this.player = player;
/*     */     
/*  99 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       return;
/*     */     }
/*     */     try {
/* 103 */       this.playerHandle = player.getClass().getMethod("getHandle", new Class[0]).invoke(player, new Object[0]);
/* 104 */       this.pingField = this.playerHandle.getClass().getField("ping");
/* 105 */       this.connection = this.playerHandle.getClass().getField("playerConnection").get(this.playerHandle);
/* 106 */       this.sendPacketMethod = this.connection.getClass().getMethod("sendPacket", new Class[] { Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".Packet") });
/* 107 */     } catch (Exception e) {
/* 108 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object getConnection() {
/* 113 */     return this.connection;
/*     */   }
/*     */   
/*     */   public int getPing() {
/* 117 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/* 118 */       return -1;
/*     */     }
/*     */     try {
/* 121 */       return this.pingField.getInt(this.playerHandle);
/* 122 */     } catch (Exception e) {
/* 123 */       e.printStackTrace();
/*     */ 
/*     */       
/* 126 */       return -1;
/*     */     } 
/*     */   }
/*     */   public Player getPlayer() {
/* 130 */     return this.player;
/*     */   }
/*     */   
/*     */   public void sendFakeHealthUpdate() {
/* 134 */     sendPacket(healthPacket);
/*     */   }
/*     */   
/*     */   public void respawnPlayer() {
/*     */     try {
/* 139 */       Object respawnEnum = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".EnumClientCommand").getEnumConstants()[0];
/* 140 */       Constructor[] constructors = (Constructor[])Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".PacketPlayInClientCommand").getConstructors(); byte b; int i; Constructor[] arrayOfConstructor1;
/* 141 */       for (i = (arrayOfConstructor1 = constructors).length, b = 0; b < i; ) { Constructor<?> constructor = arrayOfConstructor1[b];
/* 142 */         Class[] args = constructor.getParameterTypes();
/* 143 */         if (args.length == 1 && args[0] == respawnEnum.getClass()) {
/* 144 */           Object packet = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".PacketPlayInClientCommand").getConstructor(args).newInstance(new Object[] { respawnEnum });
/* 145 */           sendPacket(packet); break;
/*     */         } 
/*     */         b++; }
/*     */     
/* 149 */     } catch (Throwable e) {
/* 150 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendActionbar(String message) {
/* 155 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       return;
/*     */     }
/*     */     try {
/* 159 */       Object barchat = ioBaseChatMethod.invoke(ioBaseChat, new Object[] { "{\"text\": \"" + message + "\"}" });
/*     */       
/* 161 */       Object packet = null;
/* 162 */       if (chatEnumMethod == null) {
/* 163 */         packet = chatByteMethod.newInstance(new Object[] { barchat, Byte.valueOf((byte)2) });
/*     */       } else {
/* 165 */         packet = chatEnumMethod.newInstance(new Object[] { barchat, chatMessageTypeClass.getDeclaredField("GAME_INFO").get((Object)null) });
/*     */       } 
/* 167 */       sendPacket(packet);
/* 168 */     } catch (Exception e) {
/* 169 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendLinkedMessage(String message, String link) {
/*     */     try {
/* 175 */       Constructor<?> constructor = packetChatClass.getConstructor(new Class[] { ioBase });
/* 176 */       Object text = ioBaseChatMethod.invoke(ioBaseChat, new Object[] { "{text: '" + message + "', color: 'white', clickEvent: {\"action\": \"open_url\" , value: \"" + link + "\"}}" });
/* 177 */       Object packetFinal = constructor.newInstance(new Object[] { text });
/* 178 */       Field field = packetFinal.getClass().getDeclaredField("a");
/* 179 */       field.setAccessible(true);
/* 180 */       field.set(packetFinal, text);
/*     */       
/* 182 */       sendPacket(packetFinal);
/* 183 */     } catch (Throwable e) {
/* 184 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendPacket(Object packet) {
/*     */     try {
/* 190 */       this.sendPacketMethod.invoke(this.connection, new Object[] { packet });
/* 191 */     } catch (Exception e) {
/* 192 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendTablist(String header, String footer) {
/* 197 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       return;
/*     */     }
/*     */     try {
/* 201 */       Object tabheader = ioBaseChatMethod.invoke(ioBaseChat, new Object[] { "{\"text\": \"" + header + "\"}" });
/* 202 */       Object tabfooter = ioBaseChatMethod.invoke(ioBaseChat, new Object[] { "{\"text\": \"" + footer + "\"}" });
/*     */       
/* 204 */       if (this.tablist == null) {
/* 205 */         this.tablist = tablistClass.newInstance();
/*     */         
/* 207 */         this.headerField = getField(this.tablist.getClass(), new String[] { "a", "header" });
/* 208 */         this.headerField.setAccessible(true);
/*     */         
/* 210 */         this.footerField = getField(this.tablist.getClass(), new String[] { "b", "footer" });
/* 211 */         this.footerField.setAccessible(true);
/*     */       } 
/*     */       
/* 214 */       this.headerField.set(this.tablist, tabheader);
/* 215 */       this.footerField.set(this.tablist, tabfooter);
/*     */       
/* 217 */       sendPacket(this.tablist);
/* 218 */     } catch (Exception e) {
/* 219 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendTitle(String header, String footer) {
/* 224 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       return;
/*     */     }
/*     */     try {
/* 228 */       Object titleHeader = ioBaseChatMethod.invoke(ioBaseChat, new Object[] { "{\"text\": \"" + header + "\"}" });
/* 229 */       Object titleFooter = ioBaseChatMethod.invoke(ioBaseChat, new Object[] { "{\"text\": \"" + footer + "\"}" });
/*     */       
/* 231 */       Object headerPacket = titleConstructor.newInstance(new Object[] { title, titleHeader, Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(0) });
/* 232 */       Object footerPacket = titleConstructor.newInstance(new Object[] { subtitle, titleFooter, Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(0) });
/*     */       
/* 234 */       sendPacket(headerPacket);
/* 235 */       sendPacket(footerPacket);
/* 236 */     } catch (Exception e) {
/* 237 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setAttributeSpeed(double value) {
/* 242 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_8)) {
/*     */       return;
/*     */     }
/*     */     try {
/* 246 */       if (genericSpeedType == null) {
/* 247 */         Class<?> attribute = Class.forName("org.bukkit.attribute.Attribute");
/* 248 */         genericSpeedType = attribute.getField("GENERIC_ATTACK_SPEED").get(attribute);
/*     */       } 
/*     */       
/* 251 */       Object attributeInstance = this.player.getClass().getMethod("getAttribute", new Class[] { genericSpeedType.getClass() }).invoke(this.player, new Object[] { genericSpeedType });
/*     */       
/* 253 */       attributeInstance.getClass().getMethod("setBaseValue", new Class[] { double.class }).invoke(attributeInstance, new Object[] { Double.valueOf(value) });
/* 254 */     } catch (Exception e) {
/* 255 */       e.printStackTrace();
/*     */     }  } private static Field getField(Class<?> clazz, String... strings) {
/*     */     byte b;
/*     */     int i;
/*     */     String[] arrayOfString;
/* 260 */     for (i = (arrayOfString = strings).length, b = 0; b < i; ) { String s = arrayOfString[b];
/*     */       try {
/* 262 */         return clazz.getDeclaredField(s);
/* 263 */       } catch (NoSuchFieldException noSuchFieldException) {}
/*     */       
/*     */       b++; }
/*     */ 
/*     */     
/* 268 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\entity\player\connection\NetworkManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */