/*    */ package de.cuuky.varo.logger;
/*    */ 
/*    */ import de.cuuky.varo.logger.logger.BlockLogger;
/*    */ import de.cuuky.varo.logger.logger.ChatLogger;
/*    */ import de.cuuky.varo.logger.logger.ConsoleLogger;
/*    */ import de.cuuky.varo.logger.logger.EventLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroLoggerManager
/*    */ {
/* 16 */   private BlockLogger blockLogger = new BlockLogger("blocklogs");
/* 17 */   private ChatLogger chatLogger = new ChatLogger("chatlogs");
/* 18 */   private EventLogger eventLogger = new EventLogger("logs");
/*    */   private ConsoleLogger consoleLogger;
/*    */   
/*    */   public BlockLogger getBlockLogger() {
/* 22 */     return this.blockLogger;
/*    */   }
/*    */   
/*    */   public ChatLogger getChatLogger() {
/* 26 */     return this.chatLogger;
/*    */   }
/*    */   
/*    */   public ConsoleLogger getConsoleLogger() {
/* 30 */     return this.consoleLogger;
/*    */   }
/*    */   
/*    */   public EventLogger getEventLogger() {
/* 34 */     return this.eventLogger;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\logger\VaroLoggerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */