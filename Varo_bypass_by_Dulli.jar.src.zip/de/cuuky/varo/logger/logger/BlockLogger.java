/*    */ package de.cuuky.varo.logger.logger;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.logger.VaroLogger;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class BlockLogger
/*    */   extends VaroLogger
/*    */ {
/*    */   public BlockLogger(String name) {
/* 12 */     super(name, true);
/*    */   }
/*    */   
/*    */   public void println(Block block, Player player) {
/* 16 */     if (!Main.getDataManager().getListManager().getDestroyedBlocks().shallLog(block)) {
/*    */       return;
/*    */     }
/* 19 */     String log = "[" + getCurrentDate() + "] " + player.getName() + " mined " + block.getType().toString() + " at x:" + block.getLocation().getBlockX() + " y:" + block.getLocation().getBlockY() + " z:" + block.getLocation().getBlockZ() + " in the world '" + block.getWorld().getName() + "'!";
/*    */     
/* 21 */     this.pw.println(log);
/* 22 */     this.logs.add(log);
/*    */     
/* 24 */     this.pw.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\logger\logger\BlockLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */