/*     */ package de.cuuky.varo.logger.logger;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.bot.telegram.VaroTelegramBot;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.logger.VaroLogger;
/*     */ import de.cuuky.varo.utils.JavaUtils;
/*     */ import java.awt.Color;
/*     */ 
/*     */ public class EventLogger
/*     */   extends VaroLogger
/*     */ {
/*     */   public enum LogType
/*     */   {
/*  15 */     ALERT("ALERT", Color.RED, (String)ConfigSetting.DISCORDBOT_EVENT_ALERT),
/*  16 */     BORDER("BORDER", Color.GREEN, (String)ConfigSetting.DISCORDBOT_EVENT_YOUTUBE),
/*  17 */     DEATH("DEATH", Color.BLACK, (String)ConfigSetting.DISCORDBOT_EVENT_DEATH),
/*  18 */     JOIN_LEAVE("JOIN/LEAVE", Color.CYAN, (String)ConfigSetting.DISCORDBOT_EVENT_JOIN_LEAVE),
/*  19 */     KILL("KILL", Color.BLACK, (String)ConfigSetting.DISCORDBOT_EVENT_KILL),
/*  20 */     LOG("LOG", Color.RED, null),
/*  21 */     STRIKE("STRIKE", Color.YELLOW, (String)ConfigSetting.DISCORDBOT_EVENT_STRIKE),
/*  22 */     WIN("WIN", Color.MAGENTA, (String)ConfigSetting.DISCORDBOT_EVENT_WIN),
/*  23 */     YOUTUBE("YOUTUBE", Color.ORANGE, (String)ConfigSetting.DISCORDBOT_EVENT_YOUTUBE);
/*     */     
/*     */     private Color color;
/*     */     private ConfigSetting idEntry;
/*     */     private String name;
/*     */     
/*     */     LogType(String name, Color color, ConfigSetting idEntry) {
/*  30 */       this.color = color;
/*  31 */       this.name = name;
/*  32 */       this.idEntry = idEntry;
/*     */     }
/*     */     
/*     */     public Color getColor() {
/*  36 */       return this.color;
/*     */     }
/*     */     
/*     */     public String getName() {
/*  40 */       return this.name;
/*     */     }
/*     */     
/*     */     public long getPostChannel() {
/*  44 */       if (this.idEntry == null || Main.getBotLauncher().getDiscordbot() == null || !Main.getBotLauncher().getDiscordbot().isEnabled()) {
/*  45 */         return -1L;
/*     */       }
/*  47 */       return (this.idEntry.getValueAsLong() != -1L) ? this.idEntry.getValueAsLong() : ConfigSetting.DISCORDBOT_EVENTCHANNELID.getValueAsLong(); } public static LogType getType(String s) {
/*     */       byte b;
/*     */       int i;
/*     */       LogType[] arrayOfLogType;
/*  51 */       for (i = (arrayOfLogType = values()).length, b = 0; b < i; ) { LogType type = arrayOfLogType[b];
/*  52 */         if (type.getName().equalsIgnoreCase(s))
/*  53 */           return type;  b++; }
/*     */       
/*  55 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public EventLogger(String name) {
/*  60 */     super(name, true);
/*     */   }
/*     */   
/*     */   private void sendToDiscord(LogType type, String msg) {
/*     */     try {
/*  65 */       Main.getBotLauncher().getDiscordbot().sendMessage(msg, type.getName(), type.getColor(), type.getPostChannel());
/*  66 */     } catch (NoClassDefFoundError|BootstrapMethodError e) {
/*     */       return;
/*  68 */     } catch (Exception e) {
/*  69 */       e.printStackTrace();
/*  70 */       System.out.println(String.valueOf(Main.getPrefix()) + "Failed to broadcast message! Did you enter a wrong channel ID?");
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sendToTelegram(LogType type, String message) {
/*  76 */     VaroTelegramBot telegramBot = Main.getBotLauncher().getTelegrambot();
/*  77 */     if (telegramBot == null) {
/*     */       return;
/*     */     }
/*     */     try {
/*  81 */       if (!type.equals(LogType.YOUTUBE))
/*  82 */       { telegramBot.sendEvent(message); }
/*     */       else
/*  84 */       { telegramBot.sendVideo(message); } 
/*  85 */     } catch (ArrayIndexOutOfBoundsException e) {
/*  86 */       telegramBot.sendEvent(message);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void println(LogType type, String message) {
/*  91 */     message = JavaUtils.replaceAllColors(message);
/*     */     
/*  93 */     String log = String.valueOf(getCurrentDate()) + " || " + "[" + type.getName() + "] " + message.replace("%noBot%", "");
/*     */     
/*  95 */     this.pw.println(log);
/*  96 */     this.logs.add(log);
/*     */     
/*  98 */     this.pw.flush();
/*     */     
/* 100 */     if (type.getPostChannel() == -1L || message.contains("%noBot%")) {
/*     */       return;
/*     */     }
/* 103 */     sendToDiscord(type, message);
/* 104 */     sendToTelegram(type, message);
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\logger\logger\EventLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */