/*    */ package de.cuuky.varo.threads.daily.dailycheck.checker;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.stats.stat.Strike;
/*    */ import de.cuuky.varo.logger.logger.EventLogger;
/*    */ import de.cuuky.varo.threads.daily.dailycheck.Checker;
/*    */ import java.util.Date;
/*    */ import org.apache.commons.lang.time.DateUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BloodLustCheck
/*    */   extends Checker
/*    */ {
/*    */   public void check() {
/* 21 */     int days = ConfigSetting.BLOODLUST_DAYS.getValueAsInt();
/* 22 */     boolean strike = ConfigSetting.STRIKE_ON_BLOODLUST.getValueAsBoolean();
/* 23 */     if (!ConfigSetting.BLOODLUST_DAYS.isIntActivated()) {
/*    */       return;
/*    */     }
/* 26 */     for (VaroPlayer player : VaroPlayer.getAlivePlayer()) {
/* 27 */       Date lastContact = player.getStats().getLastEnemyContact();
/*    */       
/* 29 */       if (lastContact.before(DateUtils.addDays(new Date(), -days))) {
/*    */         
/* 31 */         if (strike) {
/* 32 */           player.getStats().addStrike(new Strike("Es wurde fuer zu viele Tage nicht gekaempft.", player, "CONSOLE"));
/* 33 */           Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, ConfigMessages.ALERT_NO_BLOODLUST_STRIKE.getValue(player).replace("%days%", String.valueOf(days))); continue;
/*    */         } 
/* 35 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, ConfigMessages.ALERT_NO_BLOODLUST.getValue(player).replace("%days%", String.valueOf(days)));
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\threads\daily\dailycheck\checker\BloodLustCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */