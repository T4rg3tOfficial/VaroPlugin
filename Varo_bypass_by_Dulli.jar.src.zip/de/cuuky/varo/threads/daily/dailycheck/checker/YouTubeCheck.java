/*    */ package de.cuuky.varo.threads.daily.dailycheck.checker;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.stats.stat.YouTubeVideo;
/*    */ import de.cuuky.varo.threads.daily.dailycheck.Checker;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Scanner;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class YouTubeCheck
/*    */   extends Checker
/*    */ {
/*    */   private ArrayList<YouTubeVideo> loadVideos(String url, VaroPlayer player) {
/* 19 */     ArrayList<String> lines = new ArrayList<>();
/* 20 */     ArrayList<YouTubeVideo> videos = new ArrayList<>();
/* 21 */     URLConnection connection = null;
/*    */     try {
/* 23 */       connection = (new URL(String.valueOf(url) + "/videos")).openConnection();
/* 24 */       connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)\tChrome/70.0.3538.67 Safari/537.36");
/* 25 */       Scanner scanner = new Scanner(connection.getInputStream());
/*    */       
/* 27 */       while (scanner.hasNextLine()) {
/* 28 */         lines.add(scanner.nextLine());
/*    */       }
/* 30 */       scanner.close();
/* 31 */     } catch (Exception ex) {
/* 32 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Could not load videos for " + player.getName());
/*    */       
/* 34 */       return null;
/*    */     } 
/*    */     
/* 37 */     String videoId = null, videoTitle = null, link = null, duration = null;
/* 38 */     for (String line : lines) {
/* 39 */       if (line.contains("yt-lockup-title")) {
/*    */         try {
/* 41 */           videoTitle = line.split("title=\"")[1].split("\"")[0];
/* 42 */           if (!videoTitle.toLowerCase().contains(ConfigSetting.YOUTUBE_VIDEO_IDENTIFIER.getValueAsString().toLowerCase())) {
/*    */             continue;
/*    */           }
/* 45 */           videoId = line.split("href=\"")[1].split("\"")[0];
/* 46 */           link = "https://youtube.com" + videoId;
/* 47 */           videoId = videoId.replace("/watch?v=", "");
/* 48 */           duration = line.split("> - ")[1].split("</span>")[0];
/*    */           
/* 50 */           if (player.getStats().hasVideo(videoId)) {
/*    */             continue;
/*    */           }
/* 53 */           videos.add(new YouTubeVideo(videoId, videoTitle, link, duration));
/* 54 */         } catch (Exception e) {
/* 55 */           e.printStackTrace();
/* 56 */           System.out.println("AT LINE " + line);
/*    */         } 
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 62 */     return videos;
/*    */   }
/*    */ 
/*    */   
/*    */   public void check() {
/* 67 */     for (VaroPlayer vp : VaroPlayer.getAlivePlayer()) {
/* 68 */       if (vp.getStats().getYoutubeLink() == null) {
/*    */         continue;
/*    */       }
/* 71 */       ArrayList<YouTubeVideo> videos = loadVideos(vp.getStats().getYoutubeLink(), vp);
/* 72 */       if (videos == null);
/*    */ 
/*    */       
/* 75 */       if (videos.size() == 0);
/*    */ 
/*    */       
/* 78 */       for (YouTubeVideo video : videos)
/* 79 */         vp.getStats().addVideo(video); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\threads\daily\dailycheck\checker\YouTubeCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */