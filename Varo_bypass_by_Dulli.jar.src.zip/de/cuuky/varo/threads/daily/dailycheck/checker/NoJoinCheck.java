/*    */ package de.cuuky.varo.threads.daily.dailycheck.checker;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.stats.stat.Strike;
/*    */ import de.cuuky.varo.logger.logger.EventLogger;
/*    */ import de.cuuky.varo.threads.daily.dailycheck.Checker;
/*    */ import java.util.Date;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import org.apache.commons.lang.time.DateUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoJoinCheck
/*    */   extends Checker
/*    */ {
/*    */   public void check() {
/* 22 */     int days = ConfigSetting.NO_ACTIVITY_DAYS.getValueAsInt();
/* 23 */     if (days < 0) {
/*    */       return;
/*    */     }
/* 26 */     for (VaroPlayer vp : VaroPlayer.getAlivePlayer()) {
/* 27 */       if (vp.getStats().getLastJoined() == null) {
/* 28 */         vp.getStats().setLastJoined(new Date());
/*    */       }
/* 30 */       Date current = new Date();
/*    */       
/* 32 */       if (vp.getStats().getLastJoined().before(DateUtils.addDays(current, -ConfigSetting.NO_ACTIVITY_DAYS.getValueAsInt()))) {
/*    */         
/* 34 */         if (ConfigSetting.STRIKE_ON_NO_ACTIVITY.getValueAsBoolean()) {
/* 35 */           Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, ConfigMessages.ALERT_NOT_JOIN_STRIKE.getValue(vp).replace("%days%", String.valueOf((int)getDateDiff(vp.getStats().getLastJoined(), current, TimeUnit.DAYS))).replace("%player%", vp.getName()));
/*    */           
/* 37 */           vp.getStats().addStrike(new Strike("Es wurde fuer zu viele Tage nicht auf den Server gejoint.", vp, "CONSOLE")); continue;
/*    */         } 
/* 39 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, ConfigMessages.ALERT_NOT_JOIN.getValue(vp).replace("%days%", String.valueOf((int)getDateDiff(vp.getStats().getLastJoined(), current, TimeUnit.DAYS))).replace("%player%", vp.getName()));
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\threads\daily\dailycheck\checker\NoJoinCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */