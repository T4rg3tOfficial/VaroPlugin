/*    */ package de.cuuky.varo.threads.daily.dailycheck.checker;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.stats.stat.Strike;
/*    */ import de.cuuky.varo.threads.daily.dailycheck.Checker;
/*    */ 
/*    */ public class StrikePostCheck
/*    */   extends Checker
/*    */ {
/*    */   public void check() {
/* 11 */     for (VaroPlayer vp : VaroPlayer.getAlivePlayer()) {
/* 12 */       for (Strike strike : vp.getStats().getStrikes()) {
/* 13 */         if (!strike.isPosted())
/* 14 */           strike.post(); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\threads\daily\dailycheck\checker\StrikePostCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */