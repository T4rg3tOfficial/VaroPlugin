/*     */ package de.cuuky.varo.threads.daily;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.game.state.GameState;
/*     */ import de.cuuky.varo.threads.daily.dailycheck.Checker;
/*     */ import de.cuuky.varo.threads.daily.dailycheck.checker.BloodLustCheck;
/*     */ import de.cuuky.varo.threads.daily.dailycheck.checker.CoordsCheck;
/*     */ import de.cuuky.varo.threads.daily.dailycheck.checker.NoJoinCheck;
/*     */ import de.cuuky.varo.threads.daily.dailycheck.checker.SessionCheck;
/*     */ import de.cuuky.varo.threads.daily.dailycheck.checker.StrikePostCheck;
/*     */ import de.cuuky.varo.threads.daily.dailycheck.checker.YouTubeCheck;
/*     */ import de.cuuky.varo.utils.varo.VaroUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.lang.time.DateUtils;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DailyTimer
/*     */ {
/*     */   private ArrayList<Checker> checker;
/*     */   
/*     */   public DailyTimer() {
/*  30 */     this.checker = new ArrayList<>();
/*     */     
/*  32 */     this.checker.add(new NoJoinCheck());
/*  33 */     this.checker.add(new BloodLustCheck());
/*  34 */     this.checker.add(new SessionCheck());
/*  35 */     this.checker.add(new YouTubeCheck());
/*  36 */     this.checker.add(new CoordsCheck());
/*  37 */     this.checker.add(new StrikePostCheck());
/*     */     
/*  39 */     startTimer();
/*     */   }
/*     */   
/*     */   private static long getDateDiff(Date date1, Date date2, TimeUnit timeUnit) {
/*  43 */     long diffInMillies = date2.getTime() - date1.getTime();
/*  44 */     return timeUnit.convert(diffInMillies, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   
/*     */   private static long getNextReset() {
/*  49 */     Date reset = new Date();
/*  50 */     reset.setMinutes(0);
/*  51 */     reset.setSeconds(0);
/*  52 */     Date current = new Date();
/*  53 */     reset.setHours(ConfigSetting.RESET_SESSION_HOUR.getValueAsInt());
/*  54 */     if (reset.before(current))
/*  55 */       reset = DateUtils.addDays(reset, 1); 
/*  56 */     return (reset.getTime() - current.getTime()) / 1000L;
/*     */   }
/*     */   
/*     */   private void startTimer() {
/*  60 */     VaroUtils.setWorldToTime();
/*  61 */     if (Main.getVaroGame().getGameState() == GameState.STARTED && Main.getVaroGame().getLastDayTimer() != null) {
/*  62 */       Date date = Main.getVaroGame().getLastDayTimer();
/*  63 */       for (int i = 0; i < getDateDiff(date, new Date(), TimeUnit.DAYS); i++) {
/*  64 */         if (ConfigSetting.DEBUG_OPTIONS.getValueAsBoolean()) {
/*  65 */           System.out.println("DAILY RECTIFY");
/*     */         }
/*  67 */         doDailyChecks();
/*     */       } 
/*     */       
/*  70 */       Main.getVaroGame().setLastDayTimer(new Date());
/*     */     } 
/*     */     
/*  73 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */ 
/*     */           
/*     */           public void run()
/*     */           {
/*     */             try {
/*  80 */               Main.getVaroGame().setLastDayTimer(new Date());
/*     */               
/*  82 */               if (Main.getVaroGame().getGameState() == GameState.STARTED) {
/*  83 */                 if (ConfigSetting.DEBUG_OPTIONS.getValueAsBoolean()) {
/*  84 */                   System.out.println("DAILY");
/*     */                 }
/*  86 */                 DailyTimer.this.doDailyChecks();
/*     */               } 
/*     */               
/*  89 */               Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new BukkitRunnable()
/*     */                   {
/*     */                     public void run()
/*     */                     {
/*  93 */                       DailyTimer.null.access$0(DailyTimer.null.this).startTimer();
/*     */                     }
/*  95 */                   },  100L);
/*  96 */             } catch (Exception e) {
/*  97 */               Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new BukkitRunnable()
/*     */                   {
/*     */                     public void run()
/*     */                     {
/* 101 */                       DailyTimer.null.access$0(DailyTimer.null.this).startTimer();
/*     */                     }
/* 103 */                   },  100L);
/*     */             } 
/*     */           }
/* 106 */         }getNextReset() * 20L);
/*     */   }
/*     */   
/*     */   public void doDailyChecks() {
/* 110 */     for (VaroPlayer vp : VaroPlayer.getVaroPlayer()) {
/* 111 */       vp.getStats().setCountdown(ConfigSetting.PLAY_TIME.getValueAsInt() * 60);
/*     */       
/* 113 */       if (vp.isOnline()) {
/* 114 */         vp.getPlayer().kickPlayer("RESET");
/*     */       }
/*     */     } 
/* 117 */     for (Checker checkers : this.checker) {
/*     */       try {
/* 119 */         checkers.check();
/* 120 */       } catch (Exception e) {
/* 121 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\threads\daily\DailyTimer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */