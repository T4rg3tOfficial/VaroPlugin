/*    */ package de.cuuky.varo.data.plugin;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.listener.PermissionSendListener;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public enum DownloadPlugin {
/* 11 */   DISCORDBOT(66778, "Discordbot", "net.dv8tion.jda.api.JDABuilder", new ConfigSetting[] { ConfigSetting.DISCORDBOT_ENABLED }),
/* 12 */   SERVER_LIBRARY_EXTENSION(76114, "ServerLibraryExtension", "com.google.gson.JsonElement", new ConfigSetting[0]),
/* 13 */   TELEGRAM(66823, "Telegrambot", "com.pengrad.telegrambot.TelegramBot", new ConfigSetting[] { ConfigSetting.TELEGRAM_ENABLED }),
/* 14 */   LABYMOD(52423, "Labymod", "net.labymod.serverapi.LabyModAPI", new ConfigSetting[] { ConfigSetting.DISABLE_LABYMOD_FUNCTIONS, ConfigSetting.KICK_LABYMOD_PLAYER, ConfigSetting.ONLY_LABYMOD_PLAYER });
/*    */   private int id;
/*    */   private String requiredClassName;
/*    */   private String name;
/*    */   private ConfigSetting[] configSettings;
/*    */   
/*    */   DownloadPlugin(int id, String name, String requiredClassName, ConfigSetting... configSettings) {
/* 21 */     this.id = id;
/* 22 */     this.requiredClassName = requiredClassName;
/* 23 */     this.name = name;
/* 24 */     this.configSettings = configSettings;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 28 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 32 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getRequiredClassName() {
/* 36 */     return this.requiredClassName;
/*    */   }
/*    */   
/*    */   public boolean shallLoad() {
/* 40 */     if (this.configSettings.length == 0)
/* 41 */       return true;  byte b; int i;
/*    */     ConfigSetting[] arrayOfConfigSetting;
/* 43 */     for (i = (arrayOfConfigSetting = this.configSettings).length, b = 0; b < i; ) { ConfigSetting setting = arrayOfConfigSetting[b];
/* 44 */       if (setting.getValueAsBoolean())
/* 45 */         return true;  b++; }
/*    */     
/* 47 */     return false;
/*    */   }
/*    */   
/*    */   public void checkedAndLoaded() {
/* 51 */     switch (this) {
/*    */       case LABYMOD:
/* 53 */         Bukkit.getPluginManager().registerEvents((Listener)new PermissionSendListener(), (Plugin)Main.getInstance());
/*    */         break;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\data\plugin\DownloadPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */