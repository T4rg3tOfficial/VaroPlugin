/*     */ package de.cuuky.varo.data;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommandListener;
/*     */ import de.cuuky.varo.command.essentials.AntiXrayCommand;
/*     */ import de.cuuky.varo.command.essentials.BorderCommand;
/*     */ import de.cuuky.varo.command.essentials.BroadcastCommand;
/*     */ import de.cuuky.varo.command.essentials.ChatClearCommand;
/*     */ import de.cuuky.varo.command.essentials.CountdownCommand;
/*     */ import de.cuuky.varo.command.essentials.DayCommand;
/*     */ import de.cuuky.varo.command.essentials.FlyCommand;
/*     */ import de.cuuky.varo.command.essentials.FreezeCommand;
/*     */ import de.cuuky.varo.command.essentials.GamemodeCommand;
/*     */ import de.cuuky.varo.command.essentials.HealCommand;
/*     */ import de.cuuky.varo.command.essentials.InfoCommand;
/*     */ import de.cuuky.varo.command.essentials.InvSeeCommand;
/*     */ import de.cuuky.varo.command.essentials.MessageCommand;
/*     */ import de.cuuky.varo.command.essentials.MuteCommand;
/*     */ import de.cuuky.varo.command.essentials.NightCommand;
/*     */ import de.cuuky.varo.command.essentials.PerformanceCommand;
/*     */ import de.cuuky.varo.command.essentials.PingCommand;
/*     */ import de.cuuky.varo.command.essentials.ProtectCommand;
/*     */ import de.cuuky.varo.command.essentials.RainCommand;
/*     */ import de.cuuky.varo.command.essentials.ReplyCommand;
/*     */ import de.cuuky.varo.command.essentials.ReportCommand;
/*     */ import de.cuuky.varo.command.essentials.SetWorldspawnCommand;
/*     */ import de.cuuky.varo.command.essentials.SpawnCommand;
/*     */ import de.cuuky.varo.command.essentials.SpeedCommand;
/*     */ import de.cuuky.varo.command.essentials.SunCommand;
/*     */ import de.cuuky.varo.command.essentials.ThunderCommand;
/*     */ import de.cuuky.varo.command.essentials.UnflyCommand;
/*     */ import de.cuuky.varo.command.essentials.UnfreezeCommand;
/*     */ import de.cuuky.varo.command.essentials.UnmuteCommand;
/*     */ import de.cuuky.varo.command.essentials.UnprotectCommand;
/*     */ import de.cuuky.varo.command.essentials.UsageCommand;
/*     */ import de.cuuky.varo.command.essentials.VanishCommand;
/*     */ import de.cuuky.varo.event.VaroEventListener;
/*     */ import de.cuuky.varo.game.world.listener.VaroWorldListener;
/*     */ import de.cuuky.varo.gui.utils.InventoryListener;
/*     */ import de.cuuky.varo.item.hook.HookListener;
/*     */ import de.cuuky.varo.listener.EntityDamageByEntityListener;
/*     */ import de.cuuky.varo.listener.EntityDamageListener;
/*     */ import de.cuuky.varo.listener.HealtLoseListener;
/*     */ import de.cuuky.varo.listener.NoPortalListener;
/*     */ import de.cuuky.varo.listener.PlayerAchievementListener;
/*     */ import de.cuuky.varo.listener.PlayerChatListener;
/*     */ import de.cuuky.varo.listener.PlayerCommandPreprocessListener;
/*     */ import de.cuuky.varo.listener.PlayerDeathListener;
/*     */ import de.cuuky.varo.listener.PlayerHungerListener;
/*     */ import de.cuuky.varo.listener.PlayerJoinListener;
/*     */ import de.cuuky.varo.listener.PlayerLoginListener;
/*     */ import de.cuuky.varo.listener.PlayerMoveListener;
/*     */ import de.cuuky.varo.listener.PlayerQuitListener;
/*     */ import de.cuuky.varo.listener.PlayerRegenerateListener;
/*     */ import de.cuuky.varo.listener.PlayerRespawnListener;
/*     */ import de.cuuky.varo.listener.PlayerTeleportListener;
/*     */ import de.cuuky.varo.listener.ServerListPingListener;
/*     */ import de.cuuky.varo.listener.lists.BlockedEnchantmentsListener;
/*     */ import de.cuuky.varo.listener.lists.BlockedItemsListener;
/*     */ import de.cuuky.varo.listener.logging.DestroyedBlocksListener;
/*     */ import de.cuuky.varo.listener.saveable.BlockBreakListener;
/*     */ import de.cuuky.varo.listener.saveable.BlockPlaceListener;
/*     */ import de.cuuky.varo.listener.saveable.EntityExplodeListener;
/*     */ import de.cuuky.varo.listener.saveable.InventoryMoveListener;
/*     */ import de.cuuky.varo.listener.saveable.PlayerInteractListener;
/*     */ import de.cuuky.varo.listener.saveable.SignChangeListener;
/*     */ import de.cuuky.varo.listener.spectator.SpectatorListener;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public final class BukkitRegisterer
/*     */ {
/*     */   private static void registerCommand(String name, CommandExecutor cm) {
/*  78 */     Main.getInstance().getCommand(name).setExecutor(cm);
/*     */   }
/*     */   
/*     */   private static void registerEvent(Listener listener) {
/*  82 */     Bukkit.getPluginManager().registerEvents(listener, (Plugin)Main.getInstance());
/*     */   }
/*     */   
/*     */   public static void registerCommands() {
/*  86 */     registerCommand("varo", (CommandExecutor)new VaroCommandListener());
/*  87 */     registerCommand("antixray", (CommandExecutor)new AntiXrayCommand());
/*  88 */     registerCommand("broadcast", (CommandExecutor)new BroadcastCommand());
/*  89 */     registerCommand("chatclear", (CommandExecutor)new ChatClearCommand());
/*  90 */     registerCommand("day", (CommandExecutor)new DayCommand());
/*  91 */     registerCommand("fly", (CommandExecutor)new FlyCommand());
/*  92 */     registerCommand("freeze", (CommandExecutor)new FreezeCommand());
/*  93 */     registerCommand("gamemode", (CommandExecutor)new GamemodeCommand());
/*  94 */     registerCommand("heal", (CommandExecutor)new HealCommand());
/*  95 */     registerCommand("info", (CommandExecutor)new InfoCommand());
/*  96 */     registerCommand("invsee", (CommandExecutor)new InvSeeCommand());
/*  97 */     registerCommand("message", (CommandExecutor)new MessageCommand());
/*  98 */     registerCommand("mute", (CommandExecutor)new MuteCommand());
/*  99 */     registerCommand("night", (CommandExecutor)new NightCommand());
/* 100 */     registerCommand("ping", (CommandExecutor)new PingCommand());
/* 101 */     registerCommand("reply", (CommandExecutor)new ReplyCommand());
/* 102 */     registerCommand("speed", (CommandExecutor)new SpeedCommand());
/* 103 */     registerCommand("vanish", (CommandExecutor)new VanishCommand());
/* 104 */     registerCommand("report", (CommandExecutor)new ReportCommand());
/* 105 */     registerCommand("unfly", (CommandExecutor)new UnflyCommand());
/* 106 */     registerCommand("unfreeze", (CommandExecutor)new UnfreezeCommand());
/* 107 */     registerCommand("unmute", (CommandExecutor)new UnmuteCommand());
/* 108 */     registerCommand("unprotect", (CommandExecutor)new UnprotectCommand());
/* 109 */     registerCommand("usage", (CommandExecutor)new UsageCommand());
/* 110 */     registerCommand("border", (CommandExecutor)new BorderCommand());
/* 111 */     registerCommand("setworldspawn", (CommandExecutor)new SetWorldspawnCommand());
/* 112 */     registerCommand("spawn", (CommandExecutor)new SpawnCommand());
/* 113 */     registerCommand("sun", (CommandExecutor)new SunCommand());
/* 114 */     registerCommand("rain", (CommandExecutor)new RainCommand());
/* 115 */     registerCommand("thunder", (CommandExecutor)new ThunderCommand());
/* 116 */     registerCommand("protect", (CommandExecutor)new ProtectCommand());
/* 117 */     registerCommand("countdown", (CommandExecutor)new CountdownCommand());
/* 118 */     registerCommand("performance", (CommandExecutor)new PerformanceCommand());
/*     */   }
/*     */   
/*     */   public static void registerEvents() {
/* 122 */     registerEvent((Listener)new PlayerJoinListener());
/* 123 */     registerEvent((Listener)new PlayerQuitListener());
/* 124 */     registerEvent((Listener)new PlayerMoveListener());
/* 125 */     registerEvent((Listener)new DestroyedBlocksListener());
/* 126 */     registerEvent((Listener)new PlayerLoginListener());
/* 127 */     registerEvent((Listener)new BlockBreakListener());
/* 128 */     registerEvent((Listener)new EntityExplodeListener());
/* 129 */     registerEvent((Listener)new PlayerInteractListener());
/* 130 */     registerEvent((Listener)new SignChangeListener());
/* 131 */     registerEvent((Listener)new PlayerChatListener());
/* 132 */     registerEvent((Listener)new BlockPlaceListener());
/* 133 */     registerEvent((Listener)new InventoryMoveListener());
/* 134 */     registerEvent((Listener)new InventoryListener());
/* 135 */     registerEvent((Listener)new ServerListPingListener());
/* 136 */     registerEvent((Listener)new PlayerDeathListener());
/* 137 */     registerEvent((Listener)new BlockedEnchantmentsListener());
/* 138 */     registerEvent((Listener)new BlockedItemsListener());
/* 139 */     registerEvent((Listener)new EntityDamageListener());
/* 140 */     registerEvent((Listener)new EntityDamageByEntityListener());
/* 141 */     registerEvent((Listener)new PlayerTeleportListener());
/* 142 */     registerEvent((Listener)new PlayerRegenerateListener());
/* 143 */     registerEvent((Listener)new PlayerHungerListener());
/* 144 */     registerEvent((Listener)new NoPortalListener());
/* 145 */     registerEvent((Listener)new PlayerCommandPreprocessListener());
/* 146 */     registerEvent((Listener)new HealtLoseListener());
/* 147 */     registerEvent((Listener)new SpectatorListener());
/* 148 */     registerEvent((Listener)new PlayerRespawnListener());
/* 149 */     registerEvent((Listener)new VaroEventListener());
/* 150 */     registerEvent((Listener)new HookListener());
/* 151 */     registerEvent((Listener)new VaroWorldListener());
/*     */     
/* 153 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_11))
/* 154 */       registerEvent((Listener)new PlayerAchievementListener()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\data\BukkitRegisterer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */