/*     */ package de.cuuky.varo.spawns;
/*     */ 
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Spawn
/*     */   implements VaroSerializeable
/*     */ {
/*  24 */   private static ArrayList<Spawn> spawns = new ArrayList<>();
/*     */   
/*     */   @VaroSerializeField(path = "location")
/*     */   private Location location;
/*     */   
/*     */   @VaroSerializeField(path = "nameTagLocation")
/*     */   private Location nameTagLocation;
/*     */   
/*     */   @VaroSerializeField(path = "nameTagName")
/*     */   private String nameTagName;
/*     */   
/*     */   @VaroSerializeField(path = "number")
/*     */   private int number;
/*     */   
/*     */   @VaroSerializeField(path = "playerId")
/*     */   private int playerId;
/*     */   
/*     */   private Entity armorStand;
/*     */   
/*     */   private VaroPlayer player;
/*     */   
/*     */   public Spawn() {
/*  46 */     spawns.add(this);
/*     */   }
/*     */   
/*     */   public Spawn(Location location) {
/*  50 */     this.number = generateId();
/*  51 */     this.location = location;
/*     */     
/*  53 */     setNameTag();
/*     */     
/*  55 */     spawns.add(this);
/*     */   }
/*     */   
/*     */   public Spawn(VaroPlayer player, Location location) {
/*  59 */     this.number = generateId();
/*  60 */     this.location = location;
/*  61 */     this.player = player;
/*     */     
/*  63 */     setNameTag();
/*     */     
/*  65 */     spawns.add(this);
/*     */   }
/*     */   
/*     */   public Spawn(int number, Location location) {
/*  69 */     if (getSpawn(number) != null) {
/*  70 */       getSpawn(number).remove();
/*     */     }
/*  72 */     this.number = number;
/*  73 */     this.location = location;
/*     */     
/*  75 */     setNameTag();
/*     */     
/*  77 */     spawns.add(this);
/*     */   }
/*     */   
/*     */   private int generateId() {
/*  81 */     int i = spawns.size() + 1;
/*  82 */     while (getSpawn(i) != null) {
/*  83 */       i++;
/*     */     }
/*  85 */     return i;
/*     */   }
/*     */   
/*     */   private String getNametagName() {
/*  89 */     return (this.player == null) ? ConfigMessages.SPAWNS_SPAWN_NUMBER.getValue().replace("%number%", String.valueOf(this.number)) : ConfigMessages.SPAWNS_SPAWN_PLAYER.getValue(this.player).replace("%number%", String.valueOf(this.number));
/*     */   }
/*     */   
/*     */   private void remove() {
/*  93 */     removeNameTag();
/*  94 */     spawns.remove(this);
/*     */   }
/*     */   
/*     */   private void removeNameTag() {
/*  98 */     if (this.armorStand == null) {
/*     */       return;
/*     */     }
/* 101 */     this.armorStand.remove();
/*     */   }
/*     */   
/*     */   private void setNameTag() {
/* 105 */     if (!ConfigSetting.SET_NAMETAGS_OVER_SPAWN.getValueAsBoolean() || !VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       return;
/*     */     }
/* 108 */     this.nameTagLocation = this.location.clone().add(0.0D, ConfigSetting.NAMETAG_SPAWN_HEIGHT.getValueAsInt(), 0.0D);
/* 109 */     this.armorStand = this.location.getWorld().spawnEntity(this.nameTagLocation, EntityType.valueOf("ARMOR_STAND"));
/*     */     
/*     */     try {
/* 112 */       this.armorStand.getClass().getDeclaredMethod("setVisible", new Class[] { boolean.class }).invoke(this.armorStand, new Object[] { Boolean.valueOf(false) });
/* 113 */       this.armorStand.getClass().getMethod("setCustomNameVisible", new Class[] { boolean.class }).invoke(this.armorStand, new Object[] { Boolean.valueOf(true) });
/* 114 */       this.armorStand.getClass().getDeclaredMethod("setGravity", new Class[] { boolean.class }).invoke(this.armorStand, new Object[] { Boolean.valueOf(false) });
/*     */       
/* 116 */       updateNametag();
/* 117 */     } catch (Exception e) {
/* 118 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void updateNametag() {
/* 123 */     if (this.armorStand == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 127 */       String nameTagName = getNametagName();
/* 128 */       String entName = (String)this.armorStand.getClass().getMethod("getCustomName", new Class[0]).invoke(this.armorStand, new Object[0]);
/*     */       
/* 130 */       if (entName == null || !nameTagName.equals(entName)) {
/* 131 */         this.nameTagName = nameTagName;
/* 132 */         this.armorStand.getClass().getMethod("setCustomName", new Class[] { String.class }).invoke(this.armorStand, new Object[] { nameTagName });
/*     */       } 
/* 134 */     } catch (Exception e) {
/* 135 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void delete() {
/* 140 */     this.location.getBlock().setType(Materials.GRASS_BLOCK.parseMaterial());
/* 141 */     this.location.add(0.0D, 1.0D, 0.0D);
/* 142 */     this.location.clone().add(1.0D, 0.0D, 0.0D).getBlock().setType(Material.AIR);
/* 143 */     this.location.clone().add(-1.0D, 0.0D, 0.0D).getBlock().setType(Material.AIR);
/* 144 */     this.location.clone().add(0.0D, 0.0D, 1.0D).getBlock().setType(Material.AIR);
/* 145 */     this.location.clone().add(0.0D, 0.0D, -1.0D).getBlock().setType(Material.AIR);
/*     */     
/* 147 */     remove();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {
/* 152 */     if (this.location == null) {
/* 153 */       remove();
/*     */     }
/* 155 */     if (this.playerId != -1) {
/* 156 */       this.player = VaroPlayer.getPlayer(this.playerId);
/*     */     }
/* 158 */     if (this.nameTagLocation != null && this.nameTagName != null) {
/* 159 */       for (Entity ent : this.nameTagLocation.getWorld().getEntities()) {
/* 160 */         if (!ent.getType().toString().contains("ARMOR_STAND")) {
/*     */           continue;
/*     */         }
/*     */         try {
/* 164 */           String entName = (String)ent.getClass().getMethod("getCustomName", new Class[0]).invoke(ent, new Object[0]);
/* 165 */           if (ent.getLocation().distance(this.nameTagLocation) < 1.0D && entName.equals(this.nameTagName)) {
/* 166 */             this.armorStand = ent;
/*     */             
/* 168 */             if (!ConfigSetting.SET_NAMETAGS_OVER_SPAWN.getValueAsBoolean() && this.armorStand != null) {
/* 169 */               this.armorStand.remove();
/* 170 */               this.armorStand = null; continue;
/*     */             } 
/* 172 */             updateNametag();
/*     */           }
/*     */         
/* 175 */         } catch (Exception e) {
/* 176 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*     */       
/* 180 */       if (this.armorStand == null) {
/* 181 */         setNameTag();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onSerializeStart() {
/* 187 */     this.playerId = (this.player != null) ? this.player.getId() : -1;
/*     */   }
/*     */   
/*     */   public Location getLocation() {
/* 191 */     return this.location;
/*     */   }
/*     */   
/*     */   public Location getNameTagLocation() {
/* 195 */     return this.nameTagLocation;
/*     */   }
/*     */   
/*     */   public int getNumber() {
/* 199 */     return this.number;
/*     */   }
/*     */   
/*     */   public VaroPlayer getPlayer() {
/* 203 */     return this.player;
/*     */   }
/*     */   
/*     */   public void setPlayer(VaroPlayer player) {
/* 207 */     this.player = player;
/*     */     
/* 209 */     updateNametag();
/*     */   }
/*     */   
/*     */   public static Spawn getSpawn(int number) {
/* 213 */     for (Spawn spawn : spawns) {
/* 214 */       if (spawn.getNumber() != number) {
/*     */         continue;
/*     */       }
/* 217 */       return spawn;
/*     */     } 
/*     */     
/* 220 */     return null;
/*     */   }
/*     */   
/*     */   public static Spawn getSpawn(VaroPlayer player) {
/* 224 */     for (Spawn spawn : spawns) {
/* 225 */       if (spawn.getPlayer() == null || !spawn.getPlayer().equals(player)) {
/*     */         continue;
/*     */       }
/* 228 */       return spawn;
/*     */     } 
/*     */     
/* 231 */     return null;
/*     */   }
/*     */   
/*     */   public static ArrayList<Spawn> getSpawnsClone() {
/* 235 */     return (ArrayList<Spawn>)spawns.clone();
/*     */   }
/*     */   
/*     */   public static ArrayList<Spawn> getSpawns() {
/* 239 */     return spawns;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\spawns\Spawn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */