/*    */ package de.cuuky.varo.spawns;
/*    */ 
/*    */ import de.cuuky.varo.serialize.VaroSerializeObject;
/*    */ 
/*    */ public class SpawnHandler
/*    */   extends VaroSerializeObject {
/*    */   public SpawnHandler() {
/*  8 */     super(Spawn.class, "/stats/spawns.yml");
/*    */     
/* 10 */     load();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onSave() {
/* 15 */     clearOld();
/*    */     
/* 17 */     for (Spawn spawn : Spawn.getSpawns()) {
/* 18 */       save(String.valueOf(spawn.getNumber()), spawn, getConfiguration());
/*    */     }
/* 20 */     saveFile();
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\spawns\SpawnHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */