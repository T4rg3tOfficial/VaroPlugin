/*     */ package de.cuuky.varo.serialize.serializer;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.serialize.VaroSerializeHandler;
/*     */ import de.cuuky.varo.serialize.VaroSerializeObject;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.configuration.MemorySection;
/*     */ 
/*     */ 
/*     */ public class VaroDeserializer
/*     */   extends VaroSerializeHandler
/*     */ {
/*     */   private VaroSerializeObject object;
/*     */   private MemorySection section;
/*     */   
/*     */   public VaroDeserializer(MemorySection section, VaroSerializeObject object) {
/*  23 */     this.section = section;
/*  24 */     this.object = object;
/*     */   }
/*     */   
/*     */   public VaroSerializeable deserialize() {
/*  28 */     VaroSerializeable instance = null;
/*  29 */     ArrayList<String> handled = new ArrayList<>();
/*  30 */     label72: for (String s : this.section.getKeys(true)) {
/*  31 */       for (String handl : handled) {
/*  32 */         if (s.contains(handl))
/*     */           continue label72; 
/*     */       } 
/*  35 */       Field field = (Field)this.object.getFieldLoader().getFields().get(s);
/*  36 */       if (field != null) {
/*  37 */         if (instance == null) {
/*     */           try {
/*  39 */             instance = this.object.getClazz().newInstance();
/*  40 */           } catch (InstantiationException|IllegalAccessException e1) {
/*  41 */             e1.printStackTrace();
/*     */             continue;
/*     */           } 
/*     */         }
/*     */         try {
/*  46 */           field.setAccessible(true);
/*     */ 
/*     */           
/*  49 */           Object obj = this.section.get(s);
/*  50 */           if (obj instanceof String && (
/*  51 */             (String)obj).equals(NULL_REPLACE)) {
/*  52 */             obj = null;
/*     */           }
/*  54 */           VaroSerializeObject handl = getHandler(field.getType());
/*  55 */           if (handl != null && obj != null) {
/*  56 */             handled.add(s);
/*  57 */             field.set(instance, (new VaroDeserializer((MemorySection)obj, handl)).deserialize());
/*     */             
/*     */             continue;
/*     */           } 
/*  61 */           if (Map.class.isAssignableFrom(field.getType())) {
/*  62 */             obj = this.section.getConfigurationSection(s).getValues(false);
/*  63 */             handled.add(s);
/*     */           } 
/*     */           
/*  66 */           if (field.getType() == Location.class) {
/*  67 */             if (obj != null)
/*  68 */               if (Bukkit.getWorld(this.section.getString(String.valueOf(s) + ".world")) != null) {
/*  69 */                 obj = new Location(Bukkit.getWorld(this.section.getString(String.valueOf(s) + ".world")), ((Double)this.section.get(String.valueOf(s) + ".x")).doubleValue(), ((Double)this.section.get(String.valueOf(s) + ".y")).doubleValue(), ((Double)this.section.get(String.valueOf(s) + ".z")).doubleValue());
/*     */               } else {
/*  71 */                 obj = null;
/*     */               }  
/*  73 */             handled.add(s);
/*     */           } 
/*     */           
/*  76 */           if (Collection.class.isAssignableFrom(field.getType())) {
/*  77 */             Class<?> clazz = (Class)this.object.getFieldLoader().getArrayTypes().get(field);
/*  78 */             if (clazz != null) {
/*  79 */               handl = getHandler((Class)this.object.getFieldLoader().getArrayTypes().get(field));
/*  80 */               if (handl != null) {
/*  81 */                 handled.add(s);
/*  82 */                 ArrayList<VaroSerializeable> newList = new ArrayList<>();
/*  83 */                 if (obj instanceof MemorySection) {
/*  84 */                   MemorySection listSection = (MemorySection)obj;
/*  85 */                   for (String listStr : listSection.getKeys(true)) {
/*  86 */                     Object listEntry = listSection.get(listStr);
/*  87 */                     if (!(listEntry instanceof MemorySection) || listStr.contains(".")) {
/*     */                       continue;
/*     */                     }
/*  90 */                     newList.add((new VaroDeserializer((MemorySection)listEntry, handl)).deserialize());
/*     */                   } 
/*     */                 } 
/*     */ 
/*     */                 
/*  95 */                 field.set(instance, newList);
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */             } 
/*     */           } 
/* 101 */           if (field.getType().isEnum() && obj instanceof String) {
/* 102 */             VaroSerializeable ser = getEnumByString((String)obj);
/* 103 */             if (ser != null) {
/* 104 */               obj = ser;
/*     */             }
/*     */           } 
/* 107 */           if (field.getType().isPrimitive() && obj instanceof String) {
/* 108 */             obj = Long.valueOf((String)obj);
/*     */           }
/* 110 */           field.set(instance, obj);
/* 111 */         } catch (IllegalArgumentException|IllegalAccessException|ExceptionInInitializerError|NullPointerException e) {
/* 112 */           e.printStackTrace();
/*     */         } 
/*     */         continue;
/*     */       } 
/* 116 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Could not deserialize field " + s + ": [FIELD NOT FOUND]");
/*     */     } 
/*     */     
/* 119 */     instance.onDeserializeEnd();
/* 120 */     return instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\serialize\serializer\VaroDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */