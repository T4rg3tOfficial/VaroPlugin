/*   */ package de.cuuky.varo.serialize.serializer.serializeable;
/*   */ 
/*   */ public enum VaroSerializeLoopType
/*   */ {
/* 5 */   CONTINUE,
/* 6 */   LOOP,
/* 7 */   LOOP_HANDLE;
/*   */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\serialize\serializer\serializeable\VaroSerializeLoopType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */