/*    */ package de.cuuky.varo.serialize.serializer.serializeable;
/*    */ 
/*    */ import de.cuuky.varo.serialize.VaroSerializeHandler;
/*    */ import de.cuuky.varo.serialize.VaroSerializeObject;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.configuration.MemorySection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroSerialize
/*    */   extends VaroSerializeHandler
/*    */ {
/* 21 */   private static ArrayList<VaroSerialize> serializes = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private VaroSerializeLoopType loopType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VaroSerialize(VaroSerializeLoopType loopType) {
/* 33 */     this.loopType = loopType;
/*    */     
/* 35 */     serializes.add(this);
/*    */   }
/*    */   
/*    */   public Object deserialize(Field field, Object obj) {
/* 39 */     return null;
/*    */   }
/*    */   
/*    */   public Object deserialize(Field field, Object obj, MemorySection section, String path, VaroSerializeObject object) {
/* 43 */     return null;
/*    */   }
/*    */   
/*    */   public VaroSerializeLoopType getLoopType() {
/* 47 */     return this.loopType;
/*    */   }
/*    */   
/*    */   public static ArrayList<VaroSerialize> getSerializes() {
/* 51 */     return serializes;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\serialize\serializer\serializeable\VaroSerialize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */