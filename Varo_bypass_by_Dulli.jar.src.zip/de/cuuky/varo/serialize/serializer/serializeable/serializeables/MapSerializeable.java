/*    */ package de.cuuky.varo.serialize.serializer.serializeable.serializeables;
/*    */ 
/*    */ import de.cuuky.varo.serialize.VaroSerializeObject;
/*    */ import de.cuuky.varo.serialize.serializer.serializeable.VaroSerialize;
/*    */ import de.cuuky.varo.serialize.serializer.serializeable.VaroSerializeLoopType;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.Map;
/*    */ import org.bukkit.configuration.MemorySection;
/*    */ 
/*    */ 
/*    */ public class MapSerializeable
/*    */   extends VaroSerialize
/*    */ {
/*    */   public MapSerializeable() {
/* 15 */     super(VaroSerializeLoopType.LOOP_HANDLE);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object deserialize(Field field, Object obj, MemorySection section, String path, VaroSerializeObject object) {
/* 20 */     if (!Map.class.isAssignableFrom(field.getType())) {
/* 21 */       return null;
/*    */     }
/* 23 */     return section.getConfigurationSection(path).getValues(false);
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\serialize\serializer\serializeable\serializeables\MapSerializeable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */