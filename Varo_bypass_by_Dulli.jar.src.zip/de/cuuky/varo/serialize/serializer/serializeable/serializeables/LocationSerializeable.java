/*    */ package de.cuuky.varo.serialize.serializer.serializeable.serializeables;
/*    */ 
/*    */ import de.cuuky.varo.serialize.VaroSerializeObject;
/*    */ import de.cuuky.varo.serialize.serializer.serializeable.VaroSerialize;
/*    */ import de.cuuky.varo.serialize.serializer.serializeable.VaroSerializeLoopType;
/*    */ import java.lang.reflect.Field;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.configuration.MemorySection;
/*    */ 
/*    */ 
/*    */ public class LocationSerializeable
/*    */   extends VaroSerialize
/*    */ {
/*    */   public LocationSerializeable() {
/* 16 */     super(VaroSerializeLoopType.LOOP_HANDLE);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object deserialize(Field field, Object obj, MemorySection section, String s, VaroSerializeObject object) {
/* 21 */     if (field.getType() == Location.class && 
/* 22 */       obj != null) {
/* 23 */       obj = new Location(Bukkit.getWorld(section.getString(String.valueOf(s) + ".world")), ((Double)section.get(String.valueOf(s) + ".x")).doubleValue(), ((Double)section.get(String.valueOf(s) + ".y")).doubleValue(), ((Double)section.get(String.valueOf(s) + ".z")).doubleValue());
/*    */     }
/* 25 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\serialize\serializer\serializeable\serializeables\LocationSerializeable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */