/*    */ package de.cuuky.varo.serialize.serializer.serializeable.serializeables;
/*    */ 
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ import de.cuuky.varo.serialize.serializer.serializeable.VaroSerialize;
/*    */ import de.cuuky.varo.serialize.serializer.serializeable.VaroSerializeLoopType;
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ public class EnumSerializeable
/*    */   extends VaroSerialize
/*    */ {
/*    */   public EnumSerializeable() {
/* 12 */     super(VaroSerializeLoopType.LOOP);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object deserialize(Field field, Object obj) {
/* 17 */     if (!field.getType().isEnum() || !(obj instanceof String)) {
/* 18 */       return null;
/*    */     }
/* 20 */     VaroSerializeable ser = getEnumByString((String)obj);
/* 21 */     if (ser == null) {
/* 22 */       return null;
/*    */     }
/* 24 */     return ser;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\serialize\serializer\serializeable\serializeables\EnumSerializeable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */