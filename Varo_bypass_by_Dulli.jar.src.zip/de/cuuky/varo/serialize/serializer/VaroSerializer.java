/*    */ package de.cuuky.varo.serialize.serializer;
/*    */ 
/*    */ import de.cuuky.varo.serialize.VaroSerializeHandler;
/*    */ import de.cuuky.varo.serialize.VaroSerializeObject;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroSerializer
/*    */   extends VaroSerializeHandler
/*    */ {
/*    */   private VaroSerializeable instance;
/*    */   private YamlConfiguration saveTo;
/*    */   private String saveUnder;
/*    */   
/*    */   public VaroSerializer(String saveUnder, VaroSerializeable instance, YamlConfiguration saveTo) {
/* 22 */     this.saveUnder = saveUnder;
/* 23 */     this.instance = instance;
/* 24 */     this.saveTo = saveTo;
/*    */     
/* 26 */     serialize();
/*    */   }
/*    */   
/*    */   public void serialize() {
/* 30 */     VaroSerializeObject handler = getHandler(this.instance.getClass());
/* 31 */     this.instance.onSerializeStart();
/*    */     
/* 33 */     ArrayList<String> list1 = new ArrayList<>();
/* 34 */     list1.addAll(handler.getFieldLoader().getFields().keySet());
/* 35 */     Collections.reverse(list1);
/* 36 */     for (String fieldIdent : list1) {
/*    */       try {
/* 38 */         Field field = (Field)handler.getFieldLoader().getFields().get(fieldIdent);
/* 39 */         field.setAccessible(true);
/*    */         
/* 41 */         Object obj = field.get(this.instance);
/* 42 */         if (obj != null) {
/* 43 */           if (obj instanceof java.util.List) {
/* 44 */             ArrayList<?> list = (ArrayList)obj;
/* 45 */             if (!list.isEmpty() && 
/* 46 */               list.get(0) instanceof VaroSerializeable) {
/* 47 */               for (int i = 0; i < list.size(); i++) {
/* 48 */                 Object listObject = list.get(i);
/*    */                 
/* 50 */                 VaroSerializeObject varoSerializeObject = getHandler(listObject.getClass());
/* 51 */                 if (varoSerializeObject != null);
/*    */               } 
/*    */ 
/*    */               
/*    */               continue;
/*    */             } 
/*    */ 
/*    */             
/* 59 */             if (obj instanceof Long) {
/* 60 */               obj = String.valueOf(((Long)obj).longValue());
/*    */             }
/*    */           } 
/* 63 */           if (field.getType() == Location.class) {
/* 64 */             Location loc = (Location)obj;
/* 65 */             if (loc.getWorld() == null) {
/* 66 */               obj = NULL_REPLACE;
/* 67 */               this.saveTo.set(String.valueOf(this.saveUnder) + "." + fieldIdent, NULL_REPLACE);
/*    */               
/*    */               continue;
/*    */             } 
/* 71 */             this.saveTo.set(String.valueOf(this.saveUnder) + "." + fieldIdent + ".world", loc.getWorld().getName());
/* 72 */             this.saveTo.set(String.valueOf(this.saveUnder) + "." + fieldIdent + ".x", Double.valueOf(loc.getX()));
/* 73 */             this.saveTo.set(String.valueOf(this.saveUnder) + "." + fieldIdent + ".y", Double.valueOf(loc.getY()));
/* 74 */             this.saveTo.set(String.valueOf(this.saveUnder) + "." + fieldIdent + ".z", Double.valueOf(loc.getZ()));
/*    */             
/*    */             continue;
/*    */           } 
/* 78 */           VaroSerializeObject handl = getHandler(obj.getClass());
/* 79 */           if (handl != null) {
/*    */             continue;
/*    */           }
/*    */         } else {
/*    */           
/* 84 */           obj = NULL_REPLACE;
/*    */         } 
/* 86 */         this.saveTo.set(String.valueOf(this.saveUnder) + "." + fieldIdent, (obj instanceof Enum) ? getStringByEnum((VaroSerializeable)obj) : obj);
/* 87 */       } catch (IllegalArgumentException|IllegalAccessException e) {
/* 88 */         e.printStackTrace();
/*    */         return;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\serialize\serializer\VaroSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */