/*    */ package de.cuuky.varo.serialize;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.serialize.field.FieldLoader;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ import de.cuuky.varo.serialize.serializer.VaroDeserializer;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import org.bukkit.configuration.MemorySection;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroSerializeObject
/*    */   extends VaroSerializeHandler
/*    */ {
/*    */   private Class<? extends VaroSerializeable> clazz;
/*    */   private YamlConfiguration configuration;
/*    */   private FieldLoader fieldLoader;
/*    */   private File file;
/*    */   
/*    */   public VaroSerializeObject(Class<? extends VaroSerializeable> clazz) {
/* 32 */     this.clazz = clazz;
/* 33 */     this.fieldLoader = new FieldLoader(clazz);
/*    */     
/* 35 */     handler.add(this);
/*    */   }
/*    */   
/*    */   public VaroSerializeObject(Class<? extends VaroSerializeable> clazz, String fileName) {
/* 39 */     this(clazz);
/*    */     
/* 41 */     if (files.get(fileName) != null) {
/* 42 */       this.file = files.get(fileName);
/* 43 */       this.configuration = configs.get(fileName);
/*    */     } else {
/* 45 */       this.file = new File("plugins/Varo", fileName);
/* 46 */       files.put(fileName, this.file);
/* 47 */       this.configuration = YamlConfiguration.loadConfiguration(this.file);
/* 48 */       configs.put(fileName, this.configuration);
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void clearOld() {
/* 53 */     Map<String, Object> configValues = this.configuration.getValues(false);
/* 54 */     for (Map.Entry<String, Object> entry : configValues.entrySet())
/* 55 */       this.configuration.set(entry.getKey(), null); 
/*    */   }
/*    */   
/*    */   protected void load() {
/* 59 */     for (String string : this.configuration.getKeys(true)) {
/* 60 */       Object obj = this.configuration.get(string);
/* 61 */       if (!(obj instanceof MemorySection) || 
/* 62 */         string.contains(".")) {
/*    */         continue;
/*    */       }
/* 65 */       (new VaroDeserializer((MemorySection)obj, this)).deserialize();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void save(String saveUnder, VaroSerializeable instance, YamlConfiguration saveTo) {
/*    */     try {
/*    */     
/* 73 */     } catch (NoClassDefFoundError e) {
/* 74 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Failed to save files - did you change the version while the server was running?");
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void saveFile() {
/*    */     try {
/* 80 */       this.configuration.save(this.file);
/* 81 */     } catch (IOException e) {
/* 82 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public Class<? extends VaroSerializeable> getClazz() {
/* 87 */     return this.clazz;
/*    */   }
/*    */   
/*    */   public YamlConfiguration getConfiguration() {
/* 91 */     return this.configuration;
/*    */   }
/*    */   
/*    */   public FieldLoader getFieldLoader() {
/* 95 */     return this.fieldLoader;
/*    */   }
/*    */   
/*    */   public void onSave() {}
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\serialize\VaroSerializeObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */