/*    */ package de.cuuky.varo.item.hook;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemHook
/*    */ {
/* 13 */   private static ArrayList<ItemHook> itemHooks = new ArrayList<>();
/*    */   
/*    */   private ItemHookListener hookListener;
/*    */   private boolean dropable;
/*    */   private boolean dragable;
/*    */   private Player player;
/*    */   private ItemStack stack;
/*    */   
/*    */   public ItemHook(Player player, ItemStack stack, int slot, ItemHookListener listener) {
/* 22 */     this.hookListener = listener;
/* 23 */     this.stack = stack;
/* 24 */     this.player = player;
/* 25 */     this.dropable = false;
/* 26 */     this.dragable = false;
/*    */     
/* 28 */     player.getInventory().setItem(slot, stack);
/*    */     
/* 30 */     if (getItemHook(stack, player) != null) {
/* 31 */       getItemHook(stack, player).remove();
/*    */     }
/* 33 */     player.updateInventory();
/*    */     
/* 35 */     itemHooks.add(this);
/*    */   }
/*    */   
/*    */   public void setDropable(boolean dropable) {
/* 39 */     this.dropable = dropable;
/*    */   }
/*    */   
/*    */   public boolean isDropable() {
/* 43 */     return this.dropable;
/*    */   }
/*    */   
/*    */   public void setDragable(boolean dragable) {
/* 47 */     this.dragable = dragable;
/*    */   }
/*    */   
/*    */   public boolean isDragable() {
/* 51 */     return this.dragable;
/*    */   }
/*    */   
/*    */   public ItemStack getItemStack() {
/* 55 */     return this.stack;
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 59 */     return this.player;
/*    */   }
/*    */   
/*    */   public void remove() {
/* 63 */     itemHooks.remove(this);
/*    */   }
/*    */   
/*    */   public ItemHookListener getHookListener() {
/* 67 */     return this.hookListener;
/*    */   }
/*    */   
/*    */   public static ItemHook getItemHook(ItemStack stack, Player player) {
/* 71 */     for (ItemHook hook : itemHooks) {
/* 72 */       if (hook.getItemStack().equals(stack) && hook.getPlayer().equals(player))
/* 73 */         return hook; 
/*    */     } 
/* 75 */     return null;
/*    */   }
/*    */   
/*    */   public static ArrayList<ItemHook> getItemHooks() {
/* 79 */     return itemHooks;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\item\hook\ItemHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */