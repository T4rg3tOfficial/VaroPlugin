/*     */ package de.cuuky.varo.item;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.utils.JavaUtils;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.inventory.meta.SkullMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemBuilder
/*     */ {
/*     */   private static Method addFlagMethod;
/*     */   private static String[] attributes;
/*     */   private static Class<?> itemFlagClass;
/*     */   private static Object[] itemFlags;
/*     */   
/*     */   static {
/*     */     try {
/*  29 */       if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*  30 */         itemFlagClass = Class.forName("org.bukkit.inventory.ItemFlag");
/*     */         
/*  32 */         attributes = new String[] { "HIDE_ATTRIBUTES", "HIDE_DESTROYS", "HIDE_ENCHANTS", "HIDE_PLACED_ON", "HIDE_POTION_EFFECTS", "HIDE_UNBREAKABLE" };
/*  33 */         itemFlags = new Object[attributes.length];
/*     */         
/*  35 */         for (int i = 0; i < attributes.length; i++) {
/*     */           try {
/*  37 */             itemFlags[i] = itemFlagClass.getDeclaredField(attributes[i]).get(null);
/*  38 */           } catch (IllegalArgumentException|IllegalAccessException|NoSuchFieldException|SecurityException e) {
/*  39 */             e.printStackTrace();
/*     */           } 
/*     */         } 
/*     */         
/*     */         try {
/*  44 */           addFlagMethod = Class.forName("org.bukkit.inventory.meta.ItemMeta").getDeclaredMethod("addItemFlags", new Class[] { Array.newInstance(itemFlagClass, 1).getClass() });
/*  45 */           addFlagMethod.setAccessible(true);
/*  46 */         } catch (NoSuchMethodException|SecurityException|NegativeArraySizeException e) {
/*  47 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*  50 */     } catch (ClassNotFoundException e) {
/*  51 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private int amount = 1; private String displayName;
/*     */   private ArrayList<String> lore;
/*     */   
/*     */   public ItemBuilder amount(int amount) {
/*  66 */     this.amount = amount;
/*  67 */     return this;
/*     */   }
/*     */   private String playerName; private ItemStack stack;
/*     */   public ItemStack build() {
/*  71 */     ItemMeta stackMeta = this.stack.getItemMeta();
/*  72 */     if (this.displayName != null && this.stack.getType() != Material.AIR) {
/*  73 */       stackMeta.setDisplayName(this.displayName);
/*     */     }
/*  75 */     if (this.lore != null)
/*  76 */       stackMeta.setLore(this.lore); 
/*  77 */     this.stack.setItemMeta(stackMeta);
/*  78 */     deleteDamageAnnotation();
/*  79 */     this.stack.setAmount(this.amount);
/*     */     
/*  81 */     return this.stack;
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemStack buildSkull() {
/*  86 */     this.stack = Materials.PLAYER_HEAD.parseItem();
/*  87 */     SkullMeta skullMeta = (SkullMeta)this.stack.getItemMeta();
/*     */     
/*  89 */     skullMeta.setDisplayName((this.displayName != null) ? (String.valueOf(Main.getColorCode()) + this.displayName) : (String.valueOf(Main.getColorCode()) + this.playerName));
/*  90 */     skullMeta.setOwner((this.playerName != null) ? this.playerName : this.displayName);
/*     */     
/*  92 */     if (this.lore != null) {
/*  93 */       skullMeta.setLore(this.lore);
/*     */     }
/*  95 */     this.stack.setItemMeta((ItemMeta)skullMeta);
/*  96 */     this.stack.setAmount(this.amount);
/*     */     
/*  98 */     return this.stack;
/*     */   }
/*     */   
/*     */   public void deleteDamageAnnotation() {
/* 102 */     ItemMeta meta = this.stack.getItemMeta();
/* 103 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/* 104 */       for (Enchantment key : meta.getEnchants().keySet()) {
/* 105 */         meta.removeEnchant(key);
/*     */       }
/*     */     } else {
/*     */       try {
/*     */         byte b;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         int i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         Object[] arrayOfObject;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 126 */         for (i = (arrayOfObject = itemFlags).length, b = 0; b < i; ) { Object obj = arrayOfObject[b];
/* 127 */           Object[] s = (Object[])Array.newInstance(itemFlagClass, 1);
/* 128 */           Array.set(s, 0, obj);
/*     */           
/* 130 */           addFlagMethod.invoke(meta, new Object[] { s }); b++; }
/*     */       
/* 132 */       } catch (Exception e) {
/* 133 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */     
/* 137 */     this.stack.setItemMeta(meta);
/*     */   }
/*     */   
/*     */   public ItemBuilder displayname(String displayname) {
/* 141 */     this.displayName = displayname;
/* 142 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder itemstack(ItemStack stack) {
/* 146 */     this.stack = stack;
/* 147 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder lore(ArrayList<String> lore) {
/* 151 */     this.lore = lore;
/* 152 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder lore(String lore) {
/* 156 */     this.lore = JavaUtils.collectionToArray(new String[] { lore });
/* 157 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder lore(String[] lore) {
/* 161 */     this.lore = JavaUtils.collectionToArray(lore);
/* 162 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder player(Player player) {
/* 166 */     this.playerName = player.getName();
/* 167 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder playername(String playername) {
/* 171 */     this.playerName = playername;
/* 172 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\item\ItemBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */