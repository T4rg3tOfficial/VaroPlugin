/*     */ package de.cuuky.varo.game;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.bot.discord.VaroDiscordBot;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.game.end.WinnerCheck;
/*     */ import de.cuuky.varo.game.leaderboard.TopScoreList;
/*     */ import de.cuuky.varo.game.start.AutoStart;
/*     */ import de.cuuky.varo.game.start.ProtectionTime;
/*     */ import de.cuuky.varo.game.state.GameState;
/*     */ import de.cuuky.varo.game.threads.VaroMainHeartbeatThread;
/*     */ import de.cuuky.varo.game.threads.VaroStartThread;
/*     */ import de.cuuky.varo.game.world.VaroWorldHandler;
/*     */ import de.cuuky.varo.game.world.border.decrease.BorderDecreaseDayTimer;
/*     */ import de.cuuky.varo.game.world.border.decrease.BorderDecreaseMinuteTimer;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*     */ import de.cuuky.varo.spawns.sort.PlayerSort;
/*     */ import de.cuuky.varo.utils.varo.VaroUtils;
/*     */ import java.awt.Color;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VaroGame
/*     */   implements VaroSerializeable
/*     */ {
/*     */   @VaroSerializeField(path = "autostart")
/*     */   private AutoStart autostart;
/*     */   @VaroSerializeField(path = "borderDecrease")
/*     */   private BorderDecreaseDayTimer borderDecrease;
/*     */   @VaroSerializeField(path = "gamestate")
/*     */   private GameState gamestate;
/*     */   @VaroSerializeField(path = "lastCoordsPost")
/*     */   private Date lastCoordsPost;
/*     */   @VaroSerializeField(path = "lastDayTimer")
/*     */   private Date lastDayTimer;
/*     */   @VaroSerializeField(path = "lobby")
/*     */   private Location lobby;
/*     */   private int startScheduler;
/*     */   private boolean finaleJoinStart;
/*     */   private boolean firstTime;
/*     */   private VaroMainHeartbeatThread mainThread;
/*     */   private VaroStartThread startThread;
/*     */   private BorderDecreaseMinuteTimer minuteTimer;
/*     */   private ProtectionTime protection;
/*     */   private VaroWorldHandler varoWorldHandler;
/*     */   private TopScoreList topScores;
/*     */   
/*     */   public VaroGame() {
/*  65 */     Main.setVaroGame(this);
/*     */   }
/*     */   
/*     */   private void loadVariables() {
/*  69 */     if (this.startThread != null) {
/*  70 */       this.startThread.loadVaraibles();
/*     */     }
/*  72 */     if (this.mainThread != null) {
/*  73 */       this.mainThread.loadVariables();
/*     */     }
/*  75 */     this.topScores = new TopScoreList();
/*     */   }
/*     */   
/*     */   public void init() {
/*  79 */     startRefreshTimer();
/*  80 */     loadVariables();
/*     */     
/*  82 */     this.varoWorldHandler = new VaroWorldHandler();
/*     */     
/*  84 */     this.gamestate = GameState.LOBBY;
/*  85 */     this.borderDecrease = new BorderDecreaseDayTimer(true);
/*     */   }
/*     */   
/*     */   public void start() {
/*  89 */     if (hasStarted() || isStarting()) {
/*     */       return;
/*     */     }
/*  92 */     if (ConfigSetting.DO_RANDOMTEAM_AT_START.getValueAsInt() > 0) {
/*  93 */       VaroUtils.doRandomTeam(ConfigSetting.DO_RANDOMTEAM_AT_START.getValueAsInt());
/*  94 */       Bukkit.broadcastMessage(String.valueOf(Main.getPrefix()) + "Alle Spieler haben einen zufaelligen Teampartner erhalten!");
/*     */     } 
/*     */     
/*  97 */     if (ConfigSetting.DO_SPAWN_GENERATE_AT_START.getValueAsBoolean())
/*     */     {
/*  99 */       Bukkit.broadcastMessage(String.valueOf(Main.getPrefix()) + "Die Loecher fuer den Spawn wurden generiert!");
/*     */     }
/*     */     
/* 102 */     if (ConfigSetting.DO_SORT_AT_START.getValueAsBoolean()) {
/* 103 */       (new PlayerSort()).sortPlayers();
/* 104 */       Bukkit.broadcastMessage(String.valueOf(Main.getPrefix()) + "Alle Spieler wurden sortiert!");
/*     */     } 
/*     */     
/* 107 */     if (ConfigSetting.REMOVE_PLAYERS_ARENT_AT_START.getValueAsBoolean()) {
/* 108 */       removeArentAtStart();
/*     */     }
/* 110 */     if (this.minuteTimer != null) {
/* 111 */       this.minuteTimer.remove();
/*     */     }
/* 113 */     this.startScheduler = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), (Runnable)(this.startThread = new VaroStartThread()), 0L, 20L);
/*     */   }
/*     */   
/*     */   public void abort() {
/* 117 */     Bukkit.getScheduler().cancelTask(this.startScheduler);
/* 118 */     Bukkit.broadcastMessage("§7Der Start wurde §cabgebrochen§7!");
/*     */     
/* 120 */     this.startThread = null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void removeArentAtStart() {
/* 125 */     for (VaroPlayer varoplayer : VaroPlayer.getVaroPlayer().clone()) {
/* 126 */       if (!varoplayer.isOnline())
/* 127 */         varoplayer.delete(); 
/*     */     } 
/*     */   }
/*     */   public void end(WinnerCheck check) {
/* 131 */     this.gamestate = GameState.END;
/*     */     
/* 133 */     for (VaroPlayer vp : check.getPlaces().get(Integer.valueOf(1))) {
/* 134 */       if (!vp.isOnline()) {
/*     */         continue;
/*     */       }
/* 137 */       Player p = vp.getPlayer();
/* 138 */       p.getWorld().spawnEntity(p.getLocation().clone().add(1.0D, 0.0D, 0.0D), EntityType.FIREWORK);
/* 139 */       p.getWorld().spawnEntity(p.getLocation().clone().add(-1.0D, 0.0D, 0.0D), EntityType.FIREWORK);
/* 140 */       p.getWorld().spawnEntity(p.getLocation().clone().add(0.0D, 0.0D, 1.0D), EntityType.FIREWORK);
/* 141 */       p.getWorld().spawnEntity(p.getLocation().clone().add(0.0D, 0.0D, -1.0D), EntityType.FIREWORK);
/*     */     } 
/*     */     
/* 144 */     String first = "";
/* 145 */     String second = "";
/* 146 */     String third = "";
/* 147 */     for (int i = 1; i <= 3; i++) {
/*     */       
/* 149 */       ArrayList<VaroPlayer> won = (ArrayList<VaroPlayer>)check.getPlaces().get(Integer.valueOf(i));
/*     */       
/* 151 */       if (won == null) {
/*     */         break;
/*     */       }
/* 154 */       String names = "";
/* 155 */       for (VaroPlayer vp : won)
/* 156 */         names = String.valueOf(names) + (!won.toArray()[won.size() - 1].equals(vp) ? (String.valueOf(vp.getName()) + ((won.size() > 2) ? (won.toArray()[won.size() - 2].equals(vp) ? "" : ", ") : "")) : (String.valueOf((won.size() == 1) ? "" : " & ") + vp.getName())); 
/* 157 */       names = String.valueOf(names) + ((((VaroPlayer)won.get(0)).getTeam() != null) ? (" (#" + ((VaroPlayer)won.get(0)).getTeam().getName() + ")") : "");
/*     */       
/* 159 */       switch (i) {
/*     */         case 1:
/* 161 */           first = names;
/*     */           break;
/*     */         case 2:
/* 164 */           second = names;
/*     */           break;
/*     */         case 3:
/* 167 */           third = names;
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 172 */     if (first.contains("&")) {
/* 173 */       Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.WIN, ConfigMessages.ALERT_WINNER_TEAM.getValue().replace("%winnerPlayers%", first));
/* 174 */       Bukkit.broadcastMessage(ConfigMessages.GAME_WIN_TEAM.getValue().replace("%winnerPlayers%", first));
/*     */     } else {
/* 176 */       Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.WIN, ConfigMessages.ALERT_WINNER.getValue().replace("%player%", first));
/* 177 */       Bukkit.broadcastMessage(ConfigMessages.GAME_WIN.getValue().replace("%player%", first));
/*     */     } 
/*     */     
/* 180 */     VaroDiscordBot db = Main.getBotLauncher().getDiscordbot();
/* 181 */     if (db != null && db.isEnabled()) {
/* 182 */       if (db.getResultChannel() != null && db.isEnabled()) {
/* 183 */         db.sendMessage(":first_place: " + first + ((second != null) ? ("\n:second_place: " + second) : "") + ((third != null) ? ("\n:third_place: " + third) : "") + "\n\nHerzlichen Glueckwunsch!", "Das Projekt ist nun vorbei!", Color.MAGENTA, Main.getBotLauncher().getDiscordbot().getResultChannel());
/*     */       }
/* 185 */       if (Main.getBotLauncher().getDiscordbot().getResultChannel() != null) {
/* 186 */         File file = new File("plugins/Varo/logs", "logs.yml");
/* 187 */         if (file.exists()) {
/* 188 */           db.sendFile("Die Logs des Projektes", file, Main.getBotLauncher().getDiscordbot().getResultChannel());
/*     */         }
/*     */       } 
/*     */     } 
/* 192 */     if (ConfigSetting.STOP_SERVER_ON_WIN.isIntActivated()) {
/* 193 */       Bukkit.getServer().broadcastMessage("§7Der Server wird in " + Main.getColorCode() + ConfigSetting.STOP_SERVER_ON_WIN.getValueAsInt() + " Sekunden §7heruntergefahren...");
/* 194 */       Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/* 198 */               Bukkit.getServer().shutdown();
/*     */             }
/* 200 */           },  (ConfigSetting.STOP_SERVER_ON_WIN.getValueAsInt() * 20));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void startRefreshTimer() {
/* 205 */     Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), (Runnable)(this.mainThread = new VaroMainHeartbeatThread()), 0L, 20L);
/*     */   }
/*     */   
/*     */   public TopScoreList getTopScores() {
/* 209 */     return this.topScores;
/*     */   }
/*     */   
/*     */   public VaroMainHeartbeatThread getMainThread() {
/* 213 */     return this.mainThread;
/*     */   }
/*     */   
/*     */   public AutoStart getAutoStart() {
/* 217 */     return this.autostart;
/*     */   }
/*     */   
/*     */   public void setStartThread(VaroStartThread startThread) {
/* 221 */     this.startThread = startThread;
/*     */   }
/*     */   
/*     */   public boolean getFinaleJoinStart() {
/* 225 */     return this.finaleJoinStart;
/*     */   }
/*     */   
/*     */   public GameState getGameState() {
/* 229 */     return this.gamestate;
/*     */   }
/*     */   
/*     */   public Date getLastCoordsPost() {
/* 233 */     return this.lastCoordsPost;
/*     */   }
/*     */   
/*     */   public Date getLastDayTimer() {
/* 237 */     return this.lastDayTimer;
/*     */   }
/*     */   
/*     */   public Location getLobby() {
/* 241 */     return this.lobby;
/*     */   }
/*     */   
/*     */   public ProtectionTime getProtection() {
/* 245 */     return this.protection;
/*     */   }
/*     */   
/*     */   public boolean hasStarted() {
/* 249 */     return (this.gamestate != GameState.LOBBY);
/*     */   }
/*     */   
/*     */   public boolean isFirstTime() {
/* 253 */     return this.firstTime;
/*     */   }
/*     */   
/*     */   public boolean isRunning() {
/* 257 */     return (this.gamestate == GameState.STARTED);
/*     */   }
/*     */   
/*     */   public boolean isStarting() {
/* 261 */     return (this.startThread != null);
/*     */   }
/*     */   
/*     */   public VaroWorldHandler getVaroWorldHandler() {
/* 265 */     return this.varoWorldHandler;
/*     */   }
/*     */   
/*     */   public void setAutoStart(AutoStart autoStart) {
/* 269 */     this.autostart = autoStart;
/*     */   }
/*     */   
/*     */   public void setBorderDecrease(BorderDecreaseDayTimer borderDecrease) {
/* 273 */     this.borderDecrease = borderDecrease;
/*     */   }
/*     */   
/*     */   public void setMinuteTimer(BorderDecreaseMinuteTimer minuteTimer) {
/* 277 */     this.minuteTimer = minuteTimer;
/*     */   }
/*     */   
/*     */   public void setFinaleJoinStart(boolean finaleJoinStart) {
/* 281 */     this.finaleJoinStart = finaleJoinStart;
/*     */   }
/*     */   
/*     */   public void setGamestate(GameState gamestate) {
/* 285 */     this.gamestate = gamestate;
/*     */   }
/*     */   
/*     */   public void setLastCoordsPost(Date lastCoordsPost) {
/* 289 */     this.lastCoordsPost = lastCoordsPost;
/*     */   }
/*     */   
/*     */   public void setLastDayTimer(Date lastDayTimer) {
/* 293 */     this.lastDayTimer = lastDayTimer;
/*     */   }
/*     */   
/*     */   public void setLobby(Location lobby) {
/* 297 */     this.lobby = lobby;
/*     */   }
/*     */   
/*     */   public void setProtection(ProtectionTime protection) {
/* 301 */     this.protection = protection;
/*     */   }
/*     */   
/*     */   public void setFirstTime(boolean firstTime) {
/* 305 */     this.firstTime = firstTime;
/*     */   }
/*     */   
/*     */   public int getStartScheduler() {
/* 309 */     return this.startScheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {
/* 314 */     if (this.gamestate == GameState.STARTED) {
/* 315 */       this.minuteTimer = new BorderDecreaseMinuteTimer();
/*     */     }
/* 317 */     startRefreshTimer();
/* 318 */     loadVariables();
/*     */     
/* 320 */     this.varoWorldHandler = new VaroWorldHandler();
/*     */   }
/*     */   
/*     */   public void onSerializeStart() {}
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\game\VaroGame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */