/*    */ package de.cuuky.varo.game;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.game.start.AutoStart;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import de.cuuky.varo.game.world.border.decrease.BorderDecreaseDayTimer;
/*    */ import de.cuuky.varo.serialize.VaroSerializeObject;
/*    */ 
/*    */ public class VaroGameHandler
/*    */   extends VaroSerializeObject {
/*    */   static {
/* 12 */     registerEnum(GameState.class);
/* 13 */     registerClass(AutoStart.class);
/* 14 */     registerClass(BorderDecreaseDayTimer.class);
/*    */   }
/*    */   
/*    */   public VaroGameHandler() {
/* 18 */     super(VaroGame.class, "/stats/game.yml");
/*    */     
/* 20 */     load();
/*    */     
/* 22 */     if (Main.getVaroGame() == null) {
/* 23 */       (new VaroGame()).init();
/*    */     }
/*    */   }
/*    */   
/*    */   public void onSave() {
/* 28 */     clearOld();
/*    */     
/* 30 */     save("current", Main.getVaroGame(), getConfiguration());
/*    */     
/* 32 */     saveFile();
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\game\VaroGameHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */