/*    */ package de.cuuky.varo.game.lobby;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.team.request.VaroTeamRequest;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import de.cuuky.varo.item.hook.ItemHookListener;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LobbyItem
/*    */ {
/*    */   public static void giveItems(Player player) {
/* 22 */     if (!ConfigSetting.TEAMREQUEST_ENABLED.getValueAsBoolean() || !ConfigSetting.TEAMREQUEST_LOBBYITEMS.getValueAsBoolean())
/*    */       return; 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\game\lobby\LobbyItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */