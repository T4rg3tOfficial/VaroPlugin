/*    */ package de.cuuky.varo.game.leaderboard;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.team.VaroTeam;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TopScoreList
/*    */ {
/*    */   private Comparator<VaroPlayer> playerSort;
/*    */   private Comparator<VaroTeam> teamSort;
/*    */   private ArrayList<VaroPlayer> topPlayer;
/*    */   private ArrayList<VaroTeam> topTeams;
/*    */   
/*    */   public TopScoreList() {
/* 19 */     this.topPlayer = new ArrayList<>();
/* 20 */     this.topTeams = new ArrayList<>();
/*    */     
/* 22 */     this.playerSort = new Comparator<VaroPlayer>()
/*    */       {
/*    */         public int compare(VaroPlayer o1, VaroPlayer o2)
/*    */         {
/* 26 */           if (o1.getStats().getKills() == o2.getStats().getKills()) {
/* 27 */             return 0;
/*    */           }
/* 29 */           return (o1.getStats().getKills() > o2.getStats().getKills()) ? -1 : 1;
/*    */         }
/*    */       };
/*    */     
/* 33 */     this.teamSort = new Comparator<VaroTeam>()
/*    */       {
/*    */         public int compare(VaroTeam o1, VaroTeam o2)
/*    */         {
/* 37 */           if (o1.getKills() == o2.getKills()) {
/* 38 */             return 0;
/*    */           }
/* 40 */           return (o1.getKills() > o2.getKills()) ? -1 : 1;
/*    */         }
/*    */       };
/*    */     
/* 44 */     update();
/*    */   }
/*    */   
/*    */   public VaroPlayer getPlayer(int rank) {
/* 48 */     if (rank - 1 < this.topPlayer.size()) {
/* 49 */       return (VaroPlayer)this.topPlayer.toArray()[rank - 1];
/*    */     }
/* 51 */     return null;
/*    */   }
/*    */   
/*    */   public VaroTeam getTeam(int rank) {
/* 55 */     if (rank - 1 < this.topTeams.size()) {
/* 56 */       return (VaroTeam)this.topTeams.toArray()[rank - 1];
/*    */     }
/* 58 */     return null;
/*    */   }
/*    */   
/*    */   public void update() {
/* 62 */     this.topPlayer.clear();
/* 63 */     this.topTeams.clear();
/*    */     
/* 65 */     for (VaroPlayer player : VaroPlayer.getVaroPlayer()) {
/* 66 */       int kills = player.getStats().getKills();
/*    */       
/* 68 */       if (kills > 0) {
/* 69 */         this.topPlayer.add(player);
/*    */       }
/*    */     } 
/* 72 */     for (VaroTeam team : VaroTeam.getTeams()) {
/* 73 */       int kills = team.getKills();
/*    */       
/* 75 */       if (kills > 0) {
/* 76 */         this.topTeams.add(team);
/*    */       }
/*    */     } 
/* 79 */     Collections.sort(this.topPlayer, this.playerSort);
/* 80 */     Collections.sort(this.topTeams, this.teamSort);
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\game\leaderboard\TopScoreList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */