/*    */ package de.cuuky.varo.game.start;
/*    */ 
/*    */ public enum StartDelay
/*    */ {
/*  5 */   WEEK(604800L, "Woche", "einer"),
/*  6 */   DAY(86400L, "Tag", "einem"),
/*  7 */   HOUR(3600L, "Stunde", "einer"),
/*  8 */   HALF_HOUR(1800L, "Stunde", "einer halben"),
/*  9 */   TEN_MINTUES(600L, "Minuten", "zehn"),
/* 10 */   FIVE_MINTUES(300L, "Minuten", "fuenf"),
/* 11 */   FOUR_MINTUES(240L, "Minuten", "vier"),
/* 12 */   THREE_MINTUES(180L, "Minuten", "drei"),
/* 13 */   TWO_MINTUES(120L, "Minuten", "zwei"),
/* 14 */   MINTUE(60L, "Minute", "einer"),
/* 15 */   GO(0L, null, null);
/*    */   private String article;
/*    */   private String unit;
/*    */   private long delay;
/*    */   private boolean used;
/*    */   
/*    */   StartDelay(long delay, String unit, String article) {
/* 22 */     this.delay = delay * 1000L;
/* 23 */     this.unit = unit;
/* 24 */     this.article = article;
/*    */   }
/*    */   
/*    */   public double getDelay() {
/* 28 */     return this.delay;
/*    */   }
/*    */   
/*    */   public String getFormated(String insert) {
/* 32 */     return String.valueOf(this.article) + " " + insert + this.unit;
/*    */   }
/*    */   
/*    */   public String getUnit() {
/* 36 */     return this.unit;
/*    */   }
/*    */   
/*    */   public boolean isUsed() {
/* 40 */     return this.used;
/*    */   }
/*    */   
/*    */   public void setUsed(boolean used) {
/* 44 */     this.used = used;
/*    */   }
/*    */   
/*    */   public static StartDelay getStartDelay(long delay) {
/* 48 */     StartDelay lastDelay = null; byte b; int i; StartDelay[] arrayOfStartDelay;
/* 49 */     for (i = (arrayOfStartDelay = values()).length, b = 0; b < i; ) { StartDelay sd = arrayOfStartDelay[b];
/* 50 */       if (delay >= sd.getDelay() && !sd.isUsed())
/*    */       {
/*    */         
/* 53 */         if (lastDelay == null || lastDelay.getDelay() < sd.getDelay())
/* 54 */           lastDelay = sd;  } 
/*    */       b++; }
/*    */     
/* 57 */     lastDelay.setUsed(true);
/* 58 */     return lastDelay; } public static void reset() {
/*    */     byte b;
/*    */     int i;
/*    */     StartDelay[] arrayOfStartDelay;
/* 62 */     for (i = (arrayOfStartDelay = values()).length, b = 0; b < i; ) { StartDelay sd = arrayOfStartDelay[b];
/* 63 */       sd.setUsed(false);
/*    */       b++; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\game\start\StartDelay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */