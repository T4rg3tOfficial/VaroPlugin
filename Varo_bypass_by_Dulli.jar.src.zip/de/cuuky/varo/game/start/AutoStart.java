/*     */ package de.cuuky.varo.game.start;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*     */ import de.cuuky.varo.utils.JavaUtils;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.lang.time.DateUtils;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class AutoStart
/*     */   implements VaroSerializeable
/*     */ {
/*     */   private int sched;
/*     */   @VaroSerializeField(path = "start")
/*     */   private Date start;
/*     */   
/*     */   public AutoStart() {
/*  23 */     Main.getVaroGame().setAutoStart(this);
/*     */   }
/*     */   
/*     */   public AutoStart(Calendar start) {
/*  27 */     this.start = start.getTime();
/*  28 */     this.start.setSeconds(0);
/*     */     
/*  30 */     start();
/*  31 */     Main.getVaroGame().setAutoStart(this);
/*     */     
/*  33 */     postMessage(String.valueOf(Main.getProjectName()) + " §7wird am " + Main.getColorCode() + getDayByInt(start.get(7)) + " §7den " + Main.getColorCode() + getWithZero(start.get(5)) + "§7." + Main.getColorCode() + getWithZero(start.get(2) + 1) + "§7." + Main.getColorCode() + start.get(1) + " §7um " + Main.getColorCode() + getWithZero(start.get(11)) + "§7:" + Main.getColorCode() + getWithZero(start.get(12)) + " §7starten!");
/*     */   }
/*     */   
/*     */   private long getDateDiff(Date date1, Date date2, TimeUnit timeUnit) {
/*  37 */     long diffInMillies = date2.getTime() - date1.getTime();
/*  38 */     return timeUnit.convert(diffInMillies, TimeUnit.MILLISECONDS);
/*     */   }
/*     */   
/*     */   private String getDayByInt(int i) {
/*  42 */     switch (i) {
/*     */       case 1:
/*  44 */         return "Sonntag";
/*     */       case 2:
/*  46 */         return "Montag";
/*     */       case 3:
/*  48 */         return "Dienstag";
/*     */       case 4:
/*  50 */         return "Mittwoch";
/*     */       case 5:
/*  52 */         return "Donnerstag";
/*     */       case 6:
/*  54 */         return "Freitag";
/*     */       case 7:
/*  56 */         return "Samstag";
/*     */     } 
/*     */ 
/*     */     
/*  60 */     return null;
/*     */   }
/*     */   
/*     */   private String getWithZero(int i) {
/*  64 */     return (i < 10) ? ("0" + i) : String.valueOf(i);
/*     */   }
/*     */   
/*     */   private void postMessage(String message) {
/*  68 */     if (Main.getBotLauncher().getDiscordbot() != null && Main.getBotLauncher().getDiscordbot().isEnabled() && Main.getBotLauncher().getDiscordbot().getAnnouncementChannel() != null)
/*  69 */       Main.getBotLauncher().getDiscordbot().sendRawMessage(String.valueOf(JavaUtils.replaceAllColors(message)) + " " + Main.getBotLauncher().getDiscordbot().getMentionRole(), Main.getBotLauncher().getDiscordbot().getAnnouncementChannel()); 
/*  70 */     Bukkit.broadcastMessage(message);
/*     */   }
/*     */ 
/*     */   
/*     */   private void start() {
/*  75 */     if ((new Date()).after(this.start)) {
/*  76 */       stop();
/*     */       
/*     */       return;
/*     */     } 
/*  80 */     Calendar current = new GregorianCalendar();
/*  81 */     long delay = getDateDiff(current.getTime(), this.start, TimeUnit.MILLISECONDS);
/*  82 */     final StartDelay startDelay = StartDelay.getStartDelay(delay);
/*  83 */     long seconds = (long)(delay - startDelay.getDelay());
/*     */     
/*  85 */     this.sched = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  89 */             Bukkit.getScheduler().cancelTask(AutoStart.this.sched);
/*  90 */             if (startDelay == StartDelay.GO) {
/*  91 */               AutoStart.this.stop();
/*  92 */               Main.getVaroGame().start();
/*  93 */               Bukkit.broadcastMessage(String.valueOf(Main.getProjectName()) + " §7wird gestartet...");
/*     */               
/*     */               return;
/*     */             } 
/*  97 */             AutoStart.this.postMessage(String.valueOf(Main.getProjectName()) + " §7startet in " + startDelay.getFormated("§7") + "!");
/*     */             
/*  99 */             AutoStart.this.start();
/*     */           }
/* 101 */         },  seconds / 1000L * 20L + 20L);
/*     */   }
/*     */   
/*     */   public void delay(int seconds) {
/* 105 */     Bukkit.getScheduler().cancelTask(this.sched);
/* 106 */     this.start = DateUtils.addMinutes(this.start, seconds);
/* 107 */     StartDelay.reset();
/* 108 */     start();
/*     */   }
/*     */   
/*     */   public void stop() {
/* 112 */     Bukkit.getScheduler().cancelTask(this.sched);
/* 113 */     Main.getVaroGame().setAutoStart(null);
/* 114 */     StartDelay.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {
/* 119 */     start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSerializeStart() {}
/*     */   
/*     */   public Date getStart() {
/* 126 */     return this.start;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\game\start\AutoStart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */