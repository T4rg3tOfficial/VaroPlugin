/*    */ package de.cuuky.varo.game.start;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class ProtectionTime
/*    */ {
/*    */   private int scheduler;
/*    */   
/*    */   public ProtectionTime() {
/* 14 */     startGeneralTimer(ConfigSetting.STARTPERIOD_PROTECTIONTIME.getValueAsInt());
/*    */   }
/*    */   
/*    */   public ProtectionTime(int Timer) {
/* 18 */     startGeneralTimer(Timer);
/*    */   }
/*    */   
/*    */   private void startGeneralTimer(final int timer) {
/* 22 */     this.scheduler = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           private int protectionTimer;
/*    */ 
/*    */           
/*    */           public void run() {
/* 28 */             if (this.protectionTimer == 0) {
/* 29 */               Bukkit.broadcastMessage(ConfigMessages.PROTECTION_TIME_OVER.getValue());
/* 30 */               Main.getVaroGame().setProtection(null);
/* 31 */               Bukkit.getScheduler().cancelTask(ProtectionTime.this.scheduler);
/* 32 */             } else if (this.protectionTimer % ConfigSetting.STARTPERIOD_PROTECTIONTIME_BROADCAST_INTERVAL.getValueAsInt() == 0 && this.protectionTimer != timer) {
/* 33 */               Bukkit.broadcastMessage(ConfigMessages.PROTECTION_TIME_UPDATE.getValue().replace("%minutes%", ProtectionTime.this.getCountdownMin(this.protectionTimer)).replace("%seconds%", ProtectionTime.this.getCountdownSec(this.protectionTimer)));
/*    */             } 
/* 35 */             this.protectionTimer--;
/*    */           }
/* 37 */         }1L, 20L);
/*    */   }
/*    */   
/*    */   private String getCountdownMin(int sec) {
/* 41 */     int min = sec / 60;
/*    */     
/* 43 */     if (min < 10) {
/* 44 */       return "0" + min;
/*    */     }
/* 46 */     return (new StringBuilder(String.valueOf(min))).toString();
/*    */   }
/*    */   
/*    */   private String getCountdownSec(int sec) {
/* 50 */     sec %= 60;
/*    */     
/* 52 */     if (sec < 10) {
/* 53 */       return "0" + sec;
/*    */     }
/* 55 */     return (new StringBuilder(String.valueOf(sec))).toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\game\start\ProtectionTime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */