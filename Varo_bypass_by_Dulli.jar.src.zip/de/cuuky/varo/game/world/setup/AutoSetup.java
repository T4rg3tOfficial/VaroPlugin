/*    */ package de.cuuky.varo.game.world.setup;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.game.world.VaroWorld;
/*    */ import de.cuuky.varo.spawns.spawn.SpawnChecker;
/*    */ import de.cuuky.varo.utils.BlockUtils;
/*    */ import de.cuuky.varo.version.BukkitVersion;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import java.io.File;
/*    */ import java.util.Calendar;
/*    */ import java.util.GregorianCalendar;
/*    */ import org.bukkit.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoSetup
/*    */ {
/*    */   public AutoSetup() {
/* 24 */     if (Main.getVaroGame().hasStarted()) {
/*    */       return;
/*    */     }
/* 27 */     setupPlugin();
/*    */   }
/*    */   
/*    */   private void setupPlugin() {
/* 31 */     VaroWorld world = Main.getVaroGame().getVaroWorldHandler().getMainWorld();
/*    */     
/* 33 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "AutoSetup: " + "Searching for terrain now... (" + world.getWorld().getName() + ")");
/*    */     
/* 35 */     int x = 0, z = 0;
/* 36 */     while (!SpawnChecker.checkSpawns(world.getWorld(), x, z, ConfigSetting.AUTOSETUP_SPAWNS_RADIUS.getValueAsInt(), ConfigSetting.AUTOSETUP_SPAWNS_AMOUNT.getValueAsInt())) {
/* 37 */       x += 100;
/* 38 */       z += 100;
/*    */     } 
/*    */     
/* 41 */     Location middle = new Location(world.getWorld(), x, world.getWorld().getMaxHeight(), z);
/*    */     
/* 43 */     if (ConfigSetting.AUTOSETUP_PORTAL_ENABLED.getValueAsBoolean()) {
/* 44 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "AutoSetup: " + "Setting up the portal...");
/* 45 */       int width = ConfigSetting.AUTOSETUP_PORTAL_WIDTH.getValueAsInt(), height = ConfigSetting.AUTOSETUP_PORTAL_HEIGHT.getValueAsInt();
/*    */       
/* 47 */       if (width < 4 || height < 5) {
/* 48 */         System.out.println(String.valueOf(Main.getConsolePrefix()) + "AutoSetup: The size of the portal is too small!");
/*    */       } else {
/*    */       
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 55 */     if (ConfigSetting.AUTOSETUP_LOBBY_ENABLED.getValueAsBoolean()) {
/* 56 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "AutoSetup: " + "Loading the lobby...");
/*    */       
/* 58 */       File file = new File(ConfigSetting.AUTOSETUP_LOBBY_SCHEMATIC.getValueAsString());
/* 59 */       Location lobby = new Location(world.getWorld(), x, (world.getWorld().getMaxHeight() - 50), z);
/* 60 */       if (!file.exists()) {
/*    */       
/*    */       } else {
/*    */       
/*    */       } 
/* 65 */       Main.getVaroGame().setLobby(lobby);
/*    */     } 
/*    */     
/* 68 */     if (ConfigSetting.AUTOSETUP_BORDER.isIntActivated() && VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/* 69 */       Main.getVaroGame().getVaroWorldHandler().setBorderSize(ConfigSetting.AUTOSETUP_BORDER.getValueAsInt(), 0L, null);
/* 70 */       world.getVaroBorder().setBorderCenter(middle);
/*    */     } 
/*    */     
/* 73 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "AutoSetup: " + "Setting the spawns...");
/* 74 */     int yPos = world.getWorld().getMaxHeight();
/* 75 */     while (BlockUtils.isAir((new Location(world.getWorld(), x, yPos, z)).getBlock())) {
/* 76 */       yPos--;
/*    */     }
/* 78 */     middle.getWorld().setSpawnLocation(x, yPos, z);
/*    */ 
/*    */     
/* 81 */     if (ConfigSetting.AUTOSETUP_TIME_HOUR.isIntActivated() && ConfigSetting.AUTOSETUP_TIME_MINUTE.isIntActivated()) {
/* 82 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "AutoSetup: " + "Setting up AutoStart...");
/* 83 */       Calendar start = new GregorianCalendar();
/* 84 */       start.set(11, ConfigSetting.AUTOSETUP_TIME_HOUR.getValueAsInt());
/* 85 */       start.set(12, ConfigSetting.AUTOSETUP_TIME_MINUTE.getValueAsInt());
/* 86 */       start.set(13, 0);
/* 87 */       start.set(14, 0);
/*    */       
/* 89 */       if ((new GregorianCalendar()).after(start)) {
/* 90 */         start.add(5, 1);
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 95 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "AutoSetup: " + "Finished!");
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\game\world\setup\AutoSetup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */