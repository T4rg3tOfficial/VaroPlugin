/*     */ package de.cuuky.varo.game.world;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.game.world.border.decrease.BorderDecrease;
/*     */ import de.cuuky.varo.game.world.border.decrease.DecreaseReason;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.messaging.PluginMessageListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VaroWorldHandler
/*     */ {
/*     */   private VaroWorld mainVaroWorld;
/*     */   private ArrayList<VaroWorld> worlds;
/*     */   private double borderSize;
/*     */   
/*     */   public VaroWorldHandler() {
/*  27 */     World mainworld = Bukkit.getWorld((String)Main.getDataManager().getPropertiesReader().getConfiguration().get("level-name"));
/*  28 */     this.mainVaroWorld = new VaroWorld(mainworld);
/*     */     
/*  30 */     this.worlds = new ArrayList<>();
/*  31 */     this.worlds.add(this.mainVaroWorld);
/*     */     
/*  33 */     if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*  34 */       this.borderSize = this.mainVaroWorld.getVaroBorder().getBorderSize();
/*     */     }
/*  36 */     for (World world : Bukkit.getWorlds()) {
/*  37 */       if (!world.equals(this.mainVaroWorld.getWorld()))
/*  38 */         addWorld(world); 
/*     */     } 
/*  40 */     if (VersionUtils.getVersion() == BukkitVersion.ONE_8)
/*  41 */       disableWorldDownloader(); 
/*     */   }
/*     */   
/*     */   private void disableWorldDownloader() {
/*  45 */     Bukkit.getServer().getMessenger().registerIncomingPluginChannel((Plugin)Main.getInstance(), "WDL|INIT", new PluginMessageListener()
/*     */         {
/*     */           public void onPluginMessageReceived(String channel, Player player, byte[] data)
/*     */           {
/*  49 */             if (player.hasPermission("varo.worlddownloader")) {
/*     */               return;
/*     */             }
/*  52 */             Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, String.valueOf(player.getName()) + " nutzt einen WorldDownloader!");
/*  53 */             Bukkit.broadcastMessage("§4" + player.getName() + " nutzt einen WorldDownloader!");
/*  54 */             player.kickPlayer("§4WorldDownloader sind bei Varos untersagt");
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public void addWorld(World world) {
/*  60 */     VaroWorld vworld = new VaroWorld(world);
/*  61 */     this.worlds.add(vworld);
/*     */     
/*  63 */     if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7) && ConfigSetting.WORLD_SNCHRONIZE_BORDER.getValueAsBoolean())
/*  64 */       vworld.getVaroBorder().setBorderSize(this.borderSize, 0L); 
/*     */   }
/*     */   
/*     */   public void decreaseBorder(final DecreaseReason reason) {
/*  68 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7) || !reason.isEnabled()) {
/*     */       return;
/*     */     }
/*  71 */     BorderDecrease decr = new BorderDecrease(reason.getSize(), reason.getDecreaseSpeed());
/*  72 */     decr.setStartHook(new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  76 */             VaroWorldHandler.this.borderSize = VaroWorldHandler.this.borderSize - reason.getSize();
/*  77 */             reason.postBroadcast();
/*     */           }
/*     */         });
/*     */     
/*  81 */     decr.setFinishHook(new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  85 */             reason.postAlert();
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public void setBorderSize(double size, long time, World world) {
/*  91 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       return;
/*     */     }
/*  94 */     this.borderSize = size;
/*  95 */     if (ConfigSetting.WORLD_SNCHRONIZE_BORDER.getValueAsBoolean()) {
/*  96 */       for (VaroWorld vworld : this.worlds)
/*  97 */         vworld.getVaroBorder().setBorderSize(size, time); 
/*     */     } else {
/*  99 */       VaroWorld vworld = (world != null) ? getVaroWorld(world) : this.mainVaroWorld;
/* 100 */       vworld.getVaroBorder().setBorderSize(size, time);
/*     */     } 
/*     */   }
/*     */   
/*     */   public VaroWorld getVaroWorld(World world) {
/* 105 */     for (VaroWorld vworld : this.worlds) {
/* 106 */       if (vworld.getWorld().equals(world))
/* 107 */         return vworld; 
/*     */     } 
/* 109 */     throw new NullPointerException("Couldn't find VaroWorld for " + world.getName());
/*     */   }
/*     */   
/*     */   public double getBorderSize(World world) {
/* 113 */     if (ConfigSetting.WORLD_SNCHRONIZE_BORDER.getValueAsBoolean()) {
/* 114 */       return this.borderSize;
/*     */     }
/* 116 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/* 117 */       return 0.0D;
/*     */     }
/* 119 */     VaroWorld vworld = (world != null) ? getVaroWorld(world) : this.mainVaroWorld;
/* 120 */     return vworld.getVaroBorder().getBorderSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<VaroWorld> getWorlds() {
/* 125 */     return this.worlds;
/*     */   }
/*     */   
/*     */   public VaroWorld getMainWorld() {
/* 129 */     return this.mainVaroWorld;
/*     */   }
/*     */   
/*     */   public Location getTeleportLocation() {
/* 133 */     return (Main.getVaroGame().getLobby() != null) ? Main.getVaroGame().getLobby() : this.mainVaroWorld.getWorld().getSpawnLocation().add(0.0D, 5.0D, 0.0D);
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\game\world\VaroWorldHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */