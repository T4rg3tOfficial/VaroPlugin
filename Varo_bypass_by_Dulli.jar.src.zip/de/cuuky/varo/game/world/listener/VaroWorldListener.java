/*    */ package de.cuuky.varo.game.world.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.world.WorldLoadEvent;
/*    */ 
/*    */ public class VaroWorldListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onWorldLoad(WorldLoadEvent event) {
/* 13 */     Main.getVaroGame().getVaroWorldHandler().addWorld(event.getWorld());
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\game\world\listener\VaroWorldListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */