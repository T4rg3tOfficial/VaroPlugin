/*    */ package de.cuuky.varo.game.world.generators;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.game.world.schematic.SchematicLoader;
/*    */ import de.cuuky.varo.utils.BlockUtils;
/*    */ import de.cuuky.varo.utils.JavaUtils;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LobbyGenerator
/*    */ {
/* 19 */   private static ArrayList<Materials> glassTypes = new ArrayList<>();
/*    */   static {
/* 21 */     glassTypes.add(Materials.ORANGE_STAINED_GLASS);
/* 22 */     glassTypes.add(Materials.MAGENTA_STAINED_GLASS);
/* 23 */     glassTypes.add(Materials.LIGHT_BLUE_STAINED_GLASS);
/* 24 */     glassTypes.add(Materials.YELLOW_STAINED_GLASS);
/* 25 */     glassTypes.add(Materials.LIME_STAINED_GLASS);
/* 26 */     glassTypes.add(Materials.PINK_STAINED_GLASS);
/* 27 */     glassTypes.add(Materials.CYAN_STAINED_GLASS);
/* 28 */     glassTypes.add(Materials.PURPLE_STAINED_GLASS);
/*    */   }
/*    */   
/*    */   private Location last;
/*    */   
/*    */   public LobbyGenerator(Location loc, File file) {
/*    */     try {
/* 35 */       (new SchematicLoader(file)).paste(loc);
/* 36 */     } catch (Error e) {
/* 37 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Du brauchst WorldEdit, um den SchematicLoader zu nutzen!");
/*    */       
/*    */       return;
/*    */     } 
/* 41 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Autosetup: Loaded schematic " + file.getName());
/*    */   }
/*    */   
/*    */   public LobbyGenerator(Location curr, int height, int size) {
/* 45 */     makeWall(curr.clone().add(-5.0D, -2.0D, -5.0D), size, 0, size);
/* 46 */     makeWall(curr, 0, height, -size);
/* 47 */     makeWall(curr, -size, -height, 0);
/* 48 */     makeWall(curr, 0, height, size);
/* 49 */     makeWall(curr, size, -height, 0);
/*    */   }
/*    */   
/*    */   private void makeWall(Location one, int x1, int y1, int z1) {
/* 53 */     Location from = (this.last != null) ? this.last : one;
/* 54 */     Location to = from.clone().add(x1, y1, z1);
/* 55 */     this.last = to;
/*    */     
/* 57 */     int topBlockX = (from.getBlockX() < to.getBlockX()) ? to.getBlockX() : from.getBlockX();
/* 58 */     int bottomBlockX = (from.getBlockX() > to.getBlockX()) ? to.getBlockX() : from.getBlockX();
/* 59 */     int topBlockY = (from.getBlockY() < to.getBlockY()) ? to.getBlockY() : from.getBlockY();
/* 60 */     int bottomBlockY = (from.getBlockY() > to.getBlockY()) ? to.getBlockY() : from.getBlockY();
/* 61 */     int topBlockZ = (from.getBlockZ() < to.getBlockZ()) ? to.getBlockZ() : from.getBlockZ();
/* 62 */     int bottomBlockZ = (from.getBlockZ() > to.getBlockZ()) ? to.getBlockZ() : from.getBlockZ();
/*    */     
/* 64 */     for (int x = bottomBlockX; x <= topBlockX; x++) {
/* 65 */       for (int y = bottomBlockY; y <= topBlockY; y++) {
/* 66 */         for (int z = bottomBlockZ; z <= topBlockZ; z++)
/* 67 */           BlockUtils.setBlock(to.getWorld().getBlockAt(x, y, z), glassTypes.get(JavaUtils.randomInt(0, glassTypes.size() - 1))); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\game\world\generators\LobbyGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */