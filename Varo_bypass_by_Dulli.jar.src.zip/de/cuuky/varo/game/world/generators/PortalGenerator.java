/*    */ package de.cuuky.varo.game.world.generators;
/*    */ 
/*    */ import de.cuuky.varo.utils.BlockUtils;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.World;
/*    */ 
/*    */ 
/*    */ public class PortalGenerator
/*    */ {
/*    */   public PortalGenerator(World world, int xPos, int zPos, int width, int height) {
/* 13 */     int yPos = world.getMaxHeight();
/* 14 */     while (BlockUtils.isAir((new Location(world, xPos, yPos, zPos)).getBlock())) {
/* 15 */       yPos--;
/*    */     }
/* 17 */     int offset = width / 2;
/* 18 */     for (int y = 1; y < height - 1; y++) {
/* 19 */       for (int i = 1; i < width - 1; i++) {
/* 20 */         world.getBlockAt(xPos - offset + i, yPos + y, zPos).setType(Materials.NETHER_PORTAL.parseMaterial());
/*    */       }
/*    */       
/* 23 */       world.getBlockAt(xPos - offset, yPos + y, zPos).setType(Material.OBSIDIAN);
/* 24 */       world.getBlockAt(xPos - offset + width - 1, yPos + y, zPos).setType(Material.OBSIDIAN);
/*    */     } 
/*    */     
/* 27 */     for (int x = 0; x < width; x++) {
/* 28 */       world.getBlockAt(xPos - offset + x, yPos, zPos).setType(Material.OBSIDIAN);
/* 29 */       world.getBlockAt(xPos - offset + x, yPos + height - 1, zPos).setType(Material.OBSIDIAN);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\game\world\generators\PortalGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */