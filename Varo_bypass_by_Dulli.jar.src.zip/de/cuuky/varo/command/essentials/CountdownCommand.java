/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountdownCommand
/*    */   implements CommandExecutor
/*    */ {
/* 17 */   int sched = -1;
/* 18 */   int time = 0;
/*    */ 
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 22 */     if (!sender.hasPermission("varo.countdowm")) {
/* 23 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 24 */       return false;
/*    */     } 
/*    */     
/* 27 */     if (this.sched != -1) {
/* 28 */       Bukkit.getScheduler().cancelTask(this.sched);
/* 29 */       this.sched = -1;
/*    */       
/* 31 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Countdown wurde abgebrochen!");
/* 32 */       return false;
/*    */     } 
/*    */     
/* 35 */     if (args.length != 1) {
/* 36 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/countdown <seconds>");
/* 37 */       return false;
/*    */     } 
/*    */     
/* 40 */     this.time = 0;
/*    */     try {
/* 42 */       this.time = Integer.parseInt(args[0]);
/* 43 */     } catch (NumberFormatException e) {
/* 44 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + " §7ist keine Zahl!");
/*    */     } 
/*    */     
/* 47 */     if (this.time < 1) {
/* 48 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Countdown kann nicht - sein!");
/* 49 */       return false;
/*    */     } 
/*    */     
/* 52 */     this.sched = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 56 */             if (CountdownCommand.this.time == 0) {
/* 57 */               Bukkit.broadcastMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Los geht's!");
/* 58 */               Bukkit.getScheduler().cancelTask(CountdownCommand.this.sched);
/* 59 */               CountdownCommand.this.time = -1;
/* 60 */               CountdownCommand.this.sched = -1;
/*    */               
/*    */               return;
/*    */             } 
/* 64 */             Bukkit.broadcastMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + CountdownCommand.this.time);
/* 65 */             CountdownCommand.this.time--;
/*    */           }
/* 67 */         },  0L, 20L);
/* 68 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\CountdownCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */