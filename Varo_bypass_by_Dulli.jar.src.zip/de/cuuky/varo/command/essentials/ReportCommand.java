/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReportCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 19 */     if (!ConfigSetting.REPORTSYSTEM_ENABLED.getValueAsBoolean()) {
/* 20 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cReports §7wurden in der Config deaktiviert!");
/* 21 */       return false;
/*    */     } 
/*    */     
/* 24 */     if (!(sender instanceof Player)) {
/* 25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Only for Player");
/* 26 */       return false;
/*    */     } 
/*    */     
/* 29 */     Player player = Bukkit.getPlayerExact(sender.getName());
/*    */     
/* 31 */     if (args.length == 0 || args.length > 1) {
/* 32 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7------ §cReport §7------");
/* 33 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§c/report §7<Player>");
/* 34 */       if (sender.hasPermission("varo.reports"))
/* 35 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§c/report list"); 
/* 36 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7-------------------");
/* 37 */       return false;
/*    */     } 
/*    */     
/* 40 */     if (args[0].equals("list") && player.hasPermission("varo.reports"))
/*    */     {
/* 42 */       return false;
/*    */     }
/*    */     
/* 45 */     VaroPlayer reported = VaroPlayer.getPlayer(args[0]);
/* 46 */     if (reported == null) {
/* 47 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Dieser Spieler existiert nicht!");
/* 48 */       return false;
/*    */     } 
/*    */ 
/*    */     
/* 52 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\ReportCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */