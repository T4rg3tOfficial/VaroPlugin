/*     */ package de.cuuky.varo.command.essentials;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class SpeedCommand
/*     */   implements CommandExecutor
/*     */ {
/*     */   private float getRealMoveSpeed(float userSpeed, boolean isFly) {
/*  15 */     float defaultSpeed = isFly ? 0.1F : 0.2F;
/*  16 */     float maxSpeed = 1.0F;
/*     */     
/*  18 */     if (userSpeed < 1.0F) {
/*  19 */       return defaultSpeed * userSpeed;
/*     */     }
/*  21 */     float ratio = (userSpeed - 1.0F) / 9.0F * (maxSpeed - defaultSpeed);
/*  22 */     return ratio + defaultSpeed;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/*  28 */     if (!sender.hasPermission("varo.speed")) {
/*  29 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/*  30 */       return false;
/*     */     } 
/*     */     
/*  33 */     if (args.length == 1) {
/*  34 */       Float speed; if (!(sender instanceof Player)) {
/*  35 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Entweder '/speed <Speed> [Player/@a]' oder Spieler sein!");
/*  36 */         return false;
/*     */       } 
/*     */       
/*  39 */       Player p = (Player)sender;
/*     */       
/*     */       try {
/*  42 */         speed = Float.valueOf(args[0]);
/*  43 */         speed = Float.valueOf(getRealMoveSpeed(Float.valueOf(args[0]).floatValue(), p.isFlying()));
/*  44 */       } catch (Exception e) {
/*  45 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du hast gueltigen keinen §bSpeed §7angegeben!");
/*  46 */         return false;
/*     */       } 
/*     */       
/*  49 */       if (Float.valueOf(args[0]).floatValue() > 10.0F || Float.valueOf(args[0]).floatValue() < 0.0F) {
/*  50 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Speed muss 0-10 betragen!");
/*  51 */         return false;
/*     */       } 
/*     */       
/*  54 */       if (p.isFlying()) {
/*  55 */         p.setFlySpeed(speed.floatValue());
/*     */       } else {
/*  57 */         p.setWalkSpeed(speed.floatValue());
/*  58 */       }  sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Deine " + Main.getColorCode() + (p.isFlying() ? "Flug" : "Lauf") + "-Geschwindigkeit §7betraegt nun " + args[0] + "!");
/*  59 */     } else if (args.length == 2) {
/*     */       try {
/*  61 */         if (Float.valueOf(args[0]).floatValue() > 10.0F || Float.valueOf(args[0]).floatValue() < 0.0F) {
/*  62 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Speed muss 0-10 betragen!");
/*  63 */           return false;
/*     */         } 
/*  65 */       } catch (Exception e) {
/*  66 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du hast gueltigen keinen " + Main.getColorCode() + "Speed §7angegeben!");
/*  67 */         return false;
/*     */       } 
/*     */       
/*  70 */       if (args[1].equalsIgnoreCase("@a")) {
/*  71 */         for (Player pl : Bukkit.getOnlinePlayers()) {
/*  72 */           Float float_ = null;
/*     */           try {
/*  74 */             float_ = Float.valueOf(args[0]);
/*  75 */             float_ = Float.valueOf(getRealMoveSpeed(Float.valueOf(args[0]).floatValue(), pl.isFlying()));
/*  76 */           } catch (Exception e) {
/*  77 */             sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du hast gueltigen keinen " + Main.getColorCode() + "Speed §7angegeben!");
/*  78 */             return false;
/*     */           } 
/*     */           
/*  81 */           if (pl.isFlying()) {
/*  82 */             pl.setFlySpeed(float_.floatValue()); continue;
/*     */           } 
/*  84 */           pl.setWalkSpeed(float_.floatValue());
/*     */         } 
/*  86 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Speed erfolgreich fuer alle gesetzt!");
/*  87 */         return false;
/*     */       } 
/*     */       
/*  90 */       Player to = Bukkit.getPlayerExact(args[1]);
/*  91 */       if (to == null) {
/*  92 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + args[1] + "§7 nicht gefunden!");
/*  93 */         return false;
/*     */       } 
/*     */       
/*  96 */       Float speed = null;
/*     */       try {
/*  98 */         speed = Float.valueOf(args[0]);
/*  99 */         speed = Float.valueOf(getRealMoveSpeed(Float.valueOf(args[0]).floatValue(), to.isFlying()));
/* 100 */       } catch (Exception e) {
/* 101 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du hast gueltigen keinen §bSpeed §7angegeben!");
/* 102 */         return false;
/*     */       } 
/*     */       
/* 105 */       if (to.isFlying()) {
/* 106 */         to.setFlySpeed(speed.floatValue());
/*     */       } else {
/* 108 */         to.setWalkSpeed(speed.floatValue());
/* 109 */       }  sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + to.getName() + "'s " + Main.getColorCode() + (to.isFlying() ? "Flug" : "Lauf") + "-Geschwindigkeit §7betraegt nun " + args[0] + "!");
/*     */     } else {
/* 111 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/speed §7<Speed> [Player]");
/* 112 */     }  return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\SpeedCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */