/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class ChatClearCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 17 */     if (!sender.hasPermission("varo.chatclear")) {
/* 18 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 19 */       return false;
/*    */     } 
/*    */     
/* 22 */     for (int i = 0; i < 100; i++) {
/* 23 */       for (Player pl : VersionUtils.getOnlinePlayer())
/* 24 */         pl.sendMessage(""); 
/*    */     } 
/* 26 */     Bukkit.broadcastMessage(String.valueOf(Main.getPrefix()) + "§7Der Chat wurde §7gecleart§7!");
/* 27 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\ChatClearCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */