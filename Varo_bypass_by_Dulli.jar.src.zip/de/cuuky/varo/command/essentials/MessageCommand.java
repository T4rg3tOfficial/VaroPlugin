/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.utils.JavaUtils;
/*    */ import java.util.HashMap;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class MessageCommand
/*    */   implements CommandExecutor
/*    */ {
/* 16 */   public static HashMap<String, String> lastChat = new HashMap<>();
/*    */ 
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 20 */     if (args.length == 0) {
/* 21 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/msg §7<Player> <Message>");
/* 22 */       return false;
/*    */     } 
/*    */     
/* 25 */     if (!Main.getVaroGame().hasStarted() && !sender.hasPermission("varo.setup")) {
/* 26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du kannst nicht als nicht-Admin vor dem " + Main.getProjectName() + "-Start §7privat schreiben.");
/* 27 */       return false;
/*    */     } 
/*    */     
/* 30 */     Player to = Bukkit.getPlayerExact(args[0]);
/* 31 */     if (to == null) {
/* 32 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + args[0] + " §7nicht gefunden!");
/* 33 */       return false;
/*    */     } 
/*    */     
/* 36 */     if (sender.getName().equals(to.getName())) {
/* 37 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Nein.");
/* 38 */       return false;
/*    */     } 
/*    */     
/* 41 */     String message = JavaUtils.getArgsToString(JavaUtils.removeString(args, 0), " ");
/* 42 */     to.sendMessage(String.valueOf(Main.getColorCode()) + sender.getName() + " §8-> §7Dir§8: §f" + message);
/* 43 */     sender.sendMessage("§7Du §8-> " + Main.getColorCode() + to.getName() + "§8: §f" + message);
/* 44 */     if (lastChat.containsKey(to.getName())) {
/* 45 */       lastChat.remove(to.getName());
/*    */     }
/* 47 */     lastChat.put(to.getName(), sender.getName());
/* 48 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\MessageCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */