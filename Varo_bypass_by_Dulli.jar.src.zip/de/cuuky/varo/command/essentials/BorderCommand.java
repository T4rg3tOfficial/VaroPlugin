/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.game.world.VaroWorldHandler;
/*    */ import de.cuuky.varo.version.BukkitVersion;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import de.cuuky.varo.version.types.Sounds;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class BorderCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
/* 19 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/* 20 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Nicht verfuegbar vor der 1.8!");
/* 21 */       return false;
/*    */     } 
/*    */     
/* 24 */     if (args.length == 0) {
/* 25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Die Border ist " + Main.getColorCode() + ((sender instanceof Player) ? Main.getVaroGame().getVaroWorldHandler().getVaroWorld(((Player)sender).getWorld()).getVaroBorder().getBorderSize() : Main.getVaroGame().getVaroWorldHandler().getMainWorld().getVaroBorder().getBorderSize()) + " §7Bloecke gross!");
/* 26 */       if (sender instanceof Player) {
/* 27 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du bist " + Main.getColorCode() + (int)Main.getVaroGame().getVaroWorldHandler().getVaroWorld(((Player)sender).getWorld()).getVaroBorder().getBorderDistanceTo((Player)sender) + "§7 Bloecke von der Border entfernt!");
/*    */       }
/* 29 */       if (sender.hasPermission("varo.setup")) {
/* 30 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du kannst die Groesse der Border mit " + Main.getColorCode() + "/border <Groesse> [Sekunden] §7setzen!");
/* 31 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Mittelpunkt der Border wird zu deinem derzeiten Punkt gesetzt");
/*    */       } 
/* 33 */       return false;
/* 34 */     }  if (args.length >= 1 && sender.hasPermission("varo.setup")) {
/* 35 */       int borderSize; Player p = (sender instanceof Player) ? (Player)sender : null;
/* 36 */       int inSeconds = -1;
/*    */       
/*    */       try {
/* 39 */         borderSize = Integer.parseInt(args[0]);
/* 40 */       } catch (NumberFormatException e) {
/* 41 */         p.sendMessage(String.valueOf(Main.getPrefix()) + "§7Das ist keine Zahl!");
/* 42 */         return false;
/*    */       } 
/*    */       
/* 45 */       VaroWorldHandler worldHandler = Main.getVaroGame().getVaroWorldHandler();
/* 46 */       if (p != null)
/* 47 */         worldHandler.getVaroWorld(p.getWorld()).getVaroBorder().setBorderCenter(p.getLocation()); 
/*    */       try {
/* 49 */         inSeconds = Integer.parseInt(args[1]);
/* 50 */         worldHandler.setBorderSize(borderSize, inSeconds, (p != null) ? p.getWorld() : null);
/* 51 */       } catch (ArrayIndexOutOfBoundsException e) {
/* 52 */         worldHandler.setBorderSize(borderSize, 0L, (p != null) ? p.getWorld() : null);
/* 53 */       } catch (NumberFormatException e) {
/* 54 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Das ist keine Zahl!");
/* 55 */         return false;
/*    */       } 
/*    */       
/* 58 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.BORDER_COMMAND_SET_BORDER.getValue().replace("%size%", String.valueOf(borderSize)));
/* 59 */       if (p != null)
/* 60 */         p.playSound(p.getLocation(), Sounds.NOTE_BASS_DRUM.bukkitSound(), 1.0F, 1.0F); 
/*    */     } else {
/* 62 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 63 */     }  return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\BorderCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */