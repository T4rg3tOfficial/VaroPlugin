/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MuteCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 19 */     if (!sender.hasPermission("varo.mute")) {
/* 20 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 21 */       return false;
/*    */     } 
/*    */     
/* 24 */     if (args.length != 1) {
/* 25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/mute <Player/@a>");
/* 26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/unmute <Player/@a>");
/* 27 */       return false;
/*    */     } 
/*    */     
/* 30 */     if (args[0].equalsIgnoreCase("@a")) {
/* 31 */       for (VaroPlayer varoPlayer : VaroPlayer.getOnlinePlayer()) {
/* 32 */         if (varoPlayer.getPlayer().isOp());
/*    */       } 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 38 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Erfolgreich alle Spieler gemuted!");
/* 39 */       return false;
/*    */     } 
/*    */     
/* 42 */     if (Bukkit.getPlayerExact(args[0]) == null) {
/* 43 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + " §7nicht gefunden!");
/* 44 */       return false;
/*    */     } 
/*    */     
/* 47 */     Player player = Bukkit.getPlayerExact(args[0]);
/* 48 */     if (player.isOp()) {
/* 49 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Ein Admin kann nicht gemutet werden!");
/* 50 */       return false;
/*    */     } 
/*    */     
/* 53 */     VaroPlayer vp = VaroPlayer.getPlayer(player);
/*    */ 
/*    */     
/* 56 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + " §7erfolgreich gemuted!");
/* 57 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\MuteCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */