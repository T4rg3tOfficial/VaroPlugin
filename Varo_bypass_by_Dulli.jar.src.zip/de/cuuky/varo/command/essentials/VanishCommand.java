/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.vanish.Vanish;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class VanishCommand
/*    */   implements CommandExecutor
/*    */ {
/* 17 */   public static ArrayList<String> vanished = new ArrayList<>();
/*    */ 
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 21 */     if (!sender.hasPermission("varo.vanish")) {
/* 22 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 23 */       return false;
/*    */     } 
/*    */     
/* 26 */     if (args.length == 0) {
/* 27 */       if (!(sender instanceof Player)) {
/* 28 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Not for console. Type /vanish [Player]");
/* 29 */         return false;
/*    */       } 
/*    */       
/* 32 */       Vanish v = Vanish.getVanish((Player)sender);
/* 33 */       if (v == null) {
/* 34 */         v = new Vanish((Player)sender);
/* 35 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du bist nun " + Main.getColorCode() + "gevanished§7!");
/* 36 */         return false;
/*    */       } 
/*    */       
/* 39 */       v.remove();
/* 40 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du bist nun " + Main.getColorCode() + "unvanished§7!");
/* 41 */     } else if (args.length == 1) {
/* 42 */       Player player = Bukkit.getPlayerExact(args[0]);
/* 43 */       if (player == null) {
/* 44 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + args[0] + " §7nicht gefunden!");
/* 45 */         return false;
/*    */       } 
/*    */       
/* 48 */       Vanish v = Vanish.getVanish(player);
/* 49 */       if (v == null) {
/* 50 */         v = new Vanish(player);
/* 51 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + player.getName() + " §7erfolgreich gevanished!");
/* 52 */         player.sendMessage(String.valueOf(Main.getPrefix()) + "Du bist nun " + Main.getColorCode() + "gevanished§7!");
/* 53 */         return false;
/*    */       } 
/*    */       
/* 56 */       v.remove();
/* 57 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + player.getName() + " §7erfolgreich unvanished!");
/* 58 */       player.sendMessage(String.valueOf(Main.getPrefix()) + "Du bist nun " + Main.getColorCode() + "unvanished§7!");
/*    */     } else {
/* 60 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/vanish §7[Spieler]");
/* 61 */     }  return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\VanishCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */