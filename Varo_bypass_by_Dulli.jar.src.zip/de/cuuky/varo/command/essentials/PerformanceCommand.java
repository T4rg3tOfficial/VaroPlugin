/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.threads.LagCounter;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Entity;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PerformanceCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 20 */     if (!sender.hasPermission("varo.performance")) {
/* 21 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 22 */       return false;
/*    */     } 
/*    */     
/* 25 */     if (args.length == 0) {
/* 26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§c§lPerformance Command§7§l:");
/* 27 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§c/performance clear §8- §7Fuehrt einen RAM-Cleaner aus");
/* 28 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§c/performance help §8- §7Zeigt Methoden zur Performanceverbesserung");
/* 29 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§c/performance entityclear §8- §7Entfernt Items auf dem Boden etc. (ausgenommen Spieler, ArmorStands, Tiere)");
/* 30 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cTIPP: §7/usage zeigt die Ausnutzung deines Servers");
/* 31 */       return false;
/*    */     } 
/*    */     
/* 34 */     if (args[0].equalsIgnoreCase("improve") || args[0].equalsIgnoreCase("clear")) {
/* 35 */       Runtime r = Runtime.getRuntime();
/* 36 */       double ramUsage = ((r.totalMemory() - r.freeMemory()) / 1048576L);
/* 37 */       System.gc();
/* 38 */       double ramCleared = ramUsage - ((r.totalMemory() - r.freeMemory()) / 1048576L);
/* 39 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "RAM wurde um §c" + ramCleared + "MB §7geleert!");
/* 40 */     } else if (args[0].equalsIgnoreCase("help")) {
/* 41 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Derzeitige TPS: §c" + Math.round(LagCounter.getTPS()) + "§7 - Normalwert §c18-20 §7TPS");
/*    */       
/* 43 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Folgende Einstellungen koennten die Performance vermindern - das Ausschalten erhoeht eventuell die Performance:");
/* 44 */       sender.sendMessage(Main.getPrefix()); byte b; int i; ConfigSetting[] arrayOfConfigSetting;
/* 45 */       for (i = (arrayOfConfigSetting = ConfigSetting.values()).length, b = 0; b < i; ) { ConfigSetting ce = arrayOfConfigSetting[b];
/* 46 */         if (ce.isReducingPerformance() && ce.getValue() instanceof Boolean && ce.getValueAsBoolean())
/* 47 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "- §7Die Einstellung §c" + ce.getPath() + " §7vermindert die Performance");  b++; }
/*    */       
/* 49 */       int entities = 0;
/* 50 */       for (World world : Bukkit.getWorlds()) {
/* 51 */         for (Entity entity : world.getEntities()) {
/* 52 */           if (!entity.getType().toString().contains("ARMOR_STAND") && !(entity instanceof org.bukkit.entity.LivingEntity))
/* 53 */             entities++; 
/*    */         } 
/* 55 */       }  sender.sendMessage(String.valueOf(Main.getPrefix()) + "Es sind §c" + entities + " §7Entities (ausgenommen Spieler, ArmorStands, Tiere) geladen - alle nicht-Spieler zu entfernen koennte die Performance erhoehen");
/* 56 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Es sind §c" + (Bukkit.getPluginManager().getPlugins()).length + " §7Plugins aktiviert - bitte alle nicht noetigen entfernen");
/* 57 */     } else if (args[0].equalsIgnoreCase("entityclear")) {
/* 58 */       for (World world : Bukkit.getWorlds()) {
/* 59 */         for (Entity entity : world.getEntities()) {
/* 60 */           if (!entity.getType().toString().contains("ARMOR_STAND") && !(entity instanceof org.bukkit.entity.LivingEntity))
/* 61 */             entity.remove(); 
/*    */         } 
/* 63 */       }  sender.sendMessage(String.valueOf(Main.getPrefix()) + "Alle Nicht- Spieler,Tiere oder ArmorStands entfernt!");
/*    */     } 
/*    */     
/* 66 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\PerformanceCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */