/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.utils.JavaUtils;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class ReplyCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 16 */     if (args.length == 0) {
/* 17 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/r §7<Message>");
/* 18 */       return false;
/*    */     } 
/*    */     
/* 21 */     if (!MessageCommand.lastChat.containsKey(sender.getName())) {
/* 22 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Letzter Chat konnte " + Main.getColorCode() + "nicht §7gefunden werden.");
/* 23 */       return false;
/*    */     } 
/*    */     
/* 26 */     String to1 = MessageCommand.lastChat.get(sender.getName());
/* 27 */     Player to = Bukkit.getPlayerExact(to1);
/*    */     
/* 29 */     if (to == null) {
/* 30 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + to1 + " §7ist nicht mehr online!");
/* 31 */       return false;
/*    */     } 
/*    */     
/* 34 */     String message = JavaUtils.getArgsToString(args, " ");
/* 35 */     to.sendMessage(String.valueOf(Main.getColorCode()) + sender.getName() + " §8-> §7Dir§8: §f" + message);
/* 36 */     sender.sendMessage("§7Du §8-> " + Main.getColorCode() + to.getName() + "§8: §f" + message);
/* 37 */     if (MessageCommand.lastChat.containsKey(to.getName())) {
/* 38 */       MessageCommand.lastChat.remove(to.getName());
/*    */     }
/* 40 */     MessageCommand.lastChat.put(to.getName(), sender.getName());
/* 41 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\ReplyCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */