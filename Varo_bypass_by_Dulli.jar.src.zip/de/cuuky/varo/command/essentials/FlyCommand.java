/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class FlyCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 17 */     if (!sender.hasPermission("varo.fly")) {
/* 18 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 19 */       return false;
/*    */     } 
/*    */     
/* 22 */     if (args.length == 0) {
/* 23 */       if (!(sender instanceof Player)) {
/* 24 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Entweder /fly [Player/@a] oder Spieler sein!");
/* 25 */         return false;
/*    */       } 
/*    */       
/* 28 */       Player p = (Player)sender;
/* 29 */       p.setAllowFlight(true);
/* 30 */       p.setFlying(true);
/* 31 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du kannst jetzt §afliegen§7!");
/* 32 */     } else if (args.length == 1) {
/* 33 */       if (args[0].equalsIgnoreCase("@a")) {
/* 34 */         for (VaroPlayer player : VaroPlayer.getOnlinePlayer()) {
/* 35 */           player.getPlayer().setAllowFlight(true);
/* 36 */           player.getPlayer().setFlying(true);
/*    */         } 
/*    */         
/* 39 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Jeder kann jetzt fliegen!");
/* 40 */         return false;
/*    */       } 
/*    */       
/* 43 */       Player to = Bukkit.getPlayerExact(args[0]);
/* 44 */       if (to == null) {
/* 45 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + "§7 nicht gefunden!");
/* 46 */         return false;
/*    */       } 
/*    */       
/* 49 */       to.setAllowFlight(true);
/* 50 */       to.setFlying(true);
/* 51 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + to.getName() + " §7kann jetzt §afliegen§7!");
/*    */     } else {
/* 53 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/fly [Player/@a]");
/* 54 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/unfly [Player/@a]");
/*    */     } 
/* 56 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\FlyCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */