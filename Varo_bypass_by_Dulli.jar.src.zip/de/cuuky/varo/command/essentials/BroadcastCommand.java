/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ 
/*    */ public class BroadcastCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 15 */     if (!sender.hasPermission("varo.broadcast")) {
/* 16 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 17 */       return false;
/*    */     } 
/*    */     
/* 20 */     if (args.length == 0) {
/* 21 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/bc <Message>");
/* 22 */       return false;
/*    */     } 
/*    */     
/* 25 */     String msg = ""; byte b; int i; String[] arrayOfString;
/* 26 */     for (i = (arrayOfString = args).length, b = 0; b < i; ) { String arg = arrayOfString[b];
/* 27 */       if (!msg.equals("")) {
/* 28 */         msg = String.valueOf(msg) + " " + arg;
/*    */       } else {
/* 30 */         msg = arg;
/*    */       }  b++; }
/* 32 */      Bukkit.broadcastMessage("§7[§cBroadcast§7] §c" + msg.replace("&", "§"));
/* 33 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\BroadcastCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */