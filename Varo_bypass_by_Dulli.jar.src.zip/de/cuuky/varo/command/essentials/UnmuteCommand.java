/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.listener.helper.cancelable.CancelAbleType;
/*    */ import de.cuuky.varo.listener.helper.cancelable.VaroCancelAble;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class UnmuteCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 19 */     if (!sender.hasPermission("varo.unmute")) {
/* 20 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 21 */       return false;
/*    */     } 
/*    */     
/* 24 */     if (args.length != 1) {
/* 25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/mute <Player/@a>");
/* 26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/unmute <Player/@a>");
/* 27 */       return false;
/*    */     } 
/*    */     
/* 30 */     if (args[0].equalsIgnoreCase("@a")) {
/* 31 */       for (VaroPlayer varoPlayer : VaroPlayer.getOnlinePlayer()) {
/* 32 */         VaroCancelAble.removeCancelAble(varoPlayer, CancelAbleType.MUTE);
/*    */       }
/*    */       
/* 35 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Erfolgreich alle Spieler entmuted!");
/* 36 */       return false;
/*    */     } 
/*    */     
/* 39 */     if (Bukkit.getPlayerExact(args[0]) == null) {
/* 40 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + " §7nicht gefunden!");
/* 41 */       return false;
/*    */     } 
/*    */     
/* 44 */     Player player = Bukkit.getPlayerExact(args[0]);
/* 45 */     VaroPlayer vp = VaroPlayer.getPlayer(player);
/* 46 */     VaroCancelAble.removeCancelAble(vp, CancelAbleType.MUTE);
/*    */     
/* 48 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + " §7erfolgreich entmuted!");
/* 49 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\UnmuteCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */