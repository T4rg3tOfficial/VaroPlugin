/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class UnflyCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 17 */     if (!sender.hasPermission("varo.unfly")) {
/* 18 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 19 */       return false;
/*    */     } 
/*    */     
/* 22 */     if (args.length == 0) {
/* 23 */       if (!(sender instanceof Player)) {
/* 24 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Entweder /unfly [Player/@a] oder Spieler sein!");
/* 25 */         return false;
/*    */       } 
/*    */       
/* 28 */       Player p = (Player)sender;
/* 29 */       p.setAllowFlight(false);
/* 30 */       p.setFlying(false);
/* 31 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du kannst jetzt nicht mehr fliegen!");
/* 32 */     } else if (args.length == 1) {
/*    */       
/* 34 */       if (args[0].equalsIgnoreCase("@a")) {
/* 35 */         for (VaroPlayer player : VaroPlayer.getOnlinePlayer()) {
/* 36 */           player.getPlayer().setAllowFlight(false);
/* 37 */           player.getPlayer().setFlying(false);
/*    */         } 
/*    */         
/* 40 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Niemand kann mehr fliegen!");
/* 41 */         return false;
/*    */       } 
/*    */       
/* 44 */       Player to = Bukkit.getPlayerExact(args[0]);
/* 45 */       if (to == null) {
/* 46 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + "§7 nicht gefunden!");
/* 47 */         return false;
/*    */       } 
/*    */       
/* 50 */       to.setAllowFlight(false);
/* 51 */       to.setFlying(false);
/* 52 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + to.getName() + " §7kann jetzt nicht mehr fliegen!");
/*    */     } else {
/* 54 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/fly [Player/@a]");
/* 55 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/unfly [Player/@a]");
/*    */     } 
/*    */     
/* 58 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\UnflyCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */