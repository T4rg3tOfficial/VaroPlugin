/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class DayCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 16 */     if (!sender.hasPermission("varo.day")) {
/* 17 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 18 */       return false;
/*    */     } 
/*    */     
/* 21 */     World world = (sender instanceof Player) ? ((Player)sender).getWorld() : Main.getVaroGame().getVaroWorldHandler().getMainWorld().getWorld();
/* 22 */     world.setTime(1000L);
/* 23 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "Es ist jetzt " + Main.getColorCode() + "Tag§7!");
/* 24 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\essentials\DayCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */