/*     */ package de.cuuky.varo.command.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*     */ import de.cuuky.varo.entity.player.stats.stat.Rank;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ 
/*     */ public class StatsCommand
/*     */   extends VaroCommand
/*     */ {
/*     */   public enum SetArgumentType
/*     */   {
/*  17 */     ADMIN_IGNORE("adminignore"),
/*  18 */     COUNTDOWN("countdown"),
/*  19 */     EPISODES_PLAYED("episodesplayed"),
/*  20 */     KILLS("kills"),
/*  21 */     PLAYER_STATE("playerstate"),
/*  22 */     RANK("rank"),
/*  23 */     SESSIONS("sessions"),
/*  24 */     WINS("wins"),
/*  25 */     YOUTUBE_LINK("youtubelink");
/*     */     
/*     */     private String arg;
/*     */     
/*     */     SetArgumentType(String arg) {
/*  30 */       this.arg = arg;
/*     */     }
/*     */     
/*     */     public boolean execute(String value, VaroPlayer vp, CommandSender sender) {
/*     */       try {
/*  35 */         switch (this) {
/*     */           case null:
/*  37 */             vp.setAdminIgnore(Boolean.valueOf(value).booleanValue());
/*     */             break;
/*     */           case KILLS:
/*  40 */             vp.getStats().setKills(Integer.valueOf(value).intValue());
/*     */             break;
/*     */           case SESSIONS:
/*  43 */             vp.getStats().setSessions(Integer.valueOf(value).intValue());
/*     */             break;
/*     */           case EPISODES_PLAYED:
/*  46 */             vp.getStats().setSessionsPlayed(Integer.valueOf(value).intValue());
/*     */             break;
/*     */           case RANK:
/*  49 */             vp.setRank(new Rank(value));
/*     */             break;
/*     */           case COUNTDOWN:
/*  52 */             vp.getStats().setCountdown(Integer.valueOf(value).intValue());
/*     */             break;
/*     */           case PLAYER_STATE:
/*  55 */             vp.getStats().setState(PlayerState.getByName(value));
/*     */             break;
/*     */           case WINS:
/*  58 */             vp.getStats().setWins(Integer.valueOf(value).intValue());
/*     */             break;
/*     */           case YOUTUBE_LINK:
/*  61 */             vp.getStats().setYoutubeLink(value);
/*     */             break;
/*     */         } 
/*     */         
/*  65 */         vp.update();
/*  66 */       } catch (Exception e) {
/*  67 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Wert '" + Main.getColorCode() + value + "§7' §7konnte nicht fuer " + toString() + " gesetzt werden!");
/*  68 */         return false;
/*     */       } 
/*  70 */       return true;
/*     */     }
/*     */     
/*     */     public String getArg() {
/*  74 */       return this.arg;
/*     */     }
/*     */     
/*     */     public void remove(VaroPlayer vp) {
/*  78 */       switch (this) {
/*     */         case null:
/*  80 */           vp.setAdminIgnore(false);
/*     */           break;
/*     */         case KILLS:
/*  83 */           vp.getStats().setKills(0);
/*     */           break;
/*     */         case SESSIONS:
/*  86 */           vp.getStats().setSessions(ConfigSetting.SESSIONS_PER_DAY.getValueAsInt());
/*     */           break;
/*     */         case EPISODES_PLAYED:
/*  89 */           vp.getStats().setSessionsPlayed(0);
/*     */           break;
/*     */         case RANK:
/*  92 */           vp.setRank(null);
/*     */           break;
/*     */         case COUNTDOWN:
/*  95 */           vp.getStats().setCountdown(ConfigSetting.PLAY_TIME.getValueAsInt() * 60);
/*     */           break;
/*     */         case PLAYER_STATE:
/*  98 */           vp.getStats().setState(PlayerState.ALIVE);
/*     */           break;
/*     */         case WINS:
/* 101 */           vp.getStats().setWins(0);
/*     */           break;
/*     */         case YOUTUBE_LINK:
/* 104 */           vp.getStats().setYoutubeLink(null);
/*     */           break;
/*     */       } 
/*     */       
/* 108 */       vp.update(); } public static SetArgumentType getByName(String name) {
/*     */       byte b;
/*     */       int i;
/*     */       SetArgumentType[] arrayOfSetArgumentType;
/* 112 */       for (i = (arrayOfSetArgumentType = values()).length, b = 0; b < i; ) { SetArgumentType type = arrayOfSetArgumentType[b];
/* 113 */         if (type.getArg().equalsIgnoreCase(name))
/* 114 */           return type;  b++; }
/*     */       
/* 116 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public StatsCommand() {
/* 121 */     super("stats", "Bearbeiten von Stats", "varo.stats", new String[] { "stat" });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 126 */     if (args.length == 0) {
/* 127 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " stats §7<Spieler/@a>");
/* 128 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " stats set §7<Spieler/@a> <Stat> <Value>");
/* 129 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " stats remove §7<Spieler/@a> <Stat>");
/* 130 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " stats reset §7<Spieler/@a>");
/* 131 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " stats odvReset §7<Spieler/@a> | Resettet alles ausser Kills, Wins, Rank, Team und YT-Link");
/*     */       
/*     */       return;
/*     */     } 
/* 135 */     String t = (args.length == 1) ? args[0] : args[1];
/* 136 */     VaroPlayer target = VaroPlayer.getPlayer(t);
/* 137 */     if (target == null && !t.equalsIgnoreCase("@a")) {
/* 138 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + t + " §7nicht gefunden!");
/*     */       
/*     */       return;
/*     */     } 
/* 142 */     if (args.length == 1) {
/* 143 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Stats von " + Main.getColorCode() + target.getName() + "§7:");
/* 144 */       sender.sendMessage(Main.getPrefix()); byte b; int i; String[] arrayOfString;
/* 145 */       for (i = (arrayOfString = target.getStats().getStatsListed()).length, b = 0; b < i; ) { String stat = arrayOfString[b];
/* 146 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + stat); b++; }
/*     */       
/*     */       return;
/*     */     } 
/* 150 */     if (args[0].equalsIgnoreCase("set") || args[0].equalsIgnoreCase("remove")) {
/* 151 */       if (args.length == 2) {
/* 152 */         byte b; int i; SetArgumentType[] arrayOfSetArgumentType; for (i = (arrayOfSetArgumentType = SetArgumentType.values()).length, b = 0; b < i; ) { SetArgumentType all = arrayOfSetArgumentType[b];
/* 153 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "STAT: " + Main.getColorCode() + all.getArg()); b++; }
/*     */         
/*     */         return;
/*     */       } 
/* 157 */       SetArgumentType type = SetArgumentType.getByName(args[2]);
/* 158 */       if (args[0].equalsIgnoreCase("set")) {
/* 159 */         if (args.length != 4) {
/* 160 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " stats set §7<Spieler/@a> <Stat> <Value>");
/*     */           
/*     */           return;
/*     */         } 
/* 164 */       } else if (args.length != 3) {
/* 165 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " stats remove §7<Spieler/@a> <Stat>");
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 170 */       if (type == null) {
/* 171 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Stat '" + Main.getColorCode() + args[2] + "§7' konnte nicht gefunden werden!");
/*     */         
/*     */         return;
/*     */       } 
/* 175 */       if (target == null) {
/* 176 */         if (args[0].equalsIgnoreCase("set")) {
/* 177 */           for (VaroPlayer all : VaroPlayer.getVaroPlayer()) {
/* 178 */             if (!type.execute(args[3], all, sender)) {
/* 179 */               sender.sendMessage(String.valueOf(Main.getPrefix()) + "Vorgang fuer alle Spieler abgebrochen!");
/*     */               return;
/*     */             } 
/*     */           } 
/* 183 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Stat '" + Main.getColorCode() + type.getArg() + "§7' fuer alle Spieler erfolgreich auf '" + Main.getColorCode() + args[3] + "§7' gesetzt!");
/*     */         } else {
/* 185 */           for (VaroPlayer all : VaroPlayer.getVaroPlayer()) {
/* 186 */             type.remove(all);
/*     */           }
/* 188 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Stat '" + Main.getColorCode() + type.getArg() + "§7' fuer alle Spieler erfolgreich zurueckgesetzt/entfernt!");
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 194 */       if (args[0].equalsIgnoreCase("set")) {
/* 195 */         if (type.execute(args[3], target, sender))
/* 196 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Stat '" + Main.getColorCode() + type.getArg() + "§7' fuer '" + Main.getColorCode() + target.getName() + "§7' erfolgreich auf '" + Main.getColorCode() + args[3] + "§7' gesetzt!"); 
/*     */       } else {
/* 198 */         type.remove(target);
/* 199 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Stat '" + Main.getColorCode() + type.getArg() + "§7' fuer '" + Main.getColorCode() + target.getName() + "§7' erfolgreich zurueckgesetzt/entfernt!");
/*     */       } 
/* 201 */     } else if (args[0].equalsIgnoreCase("reset")) {
/* 202 */       if (target == null) {
/* 203 */         for (VaroPlayer all : VaroPlayer.getVaroPlayer()) {
/* 204 */           all.getStats().loadDefaults();
/*     */         }
/* 206 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Alle Spieler erfolgreich zurueckgesetzt!");
/*     */         
/*     */         return;
/*     */       } 
/* 210 */       target.getStats().loadDefaults();
/*     */       
/* 212 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler '" + Main.getColorCode() + target.getName() + "§7' erfolgreich zurueckgesetzt!");
/* 213 */     } else if (args[0].equalsIgnoreCase("odvreset")) {
/* 214 */       if (target == null) {
/* 215 */         for (VaroPlayer all : VaroPlayer.getVaroPlayer()) {
/* 216 */           all.getStats().loadStartDefaults();
/* 217 */           all.getStats().setState(PlayerState.ALIVE);
/* 218 */           if (all.getTeam() != null) {
/* 219 */             all.getTeam().removeMember(all);
/*     */           }
/*     */         } 
/* 222 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Alle Spieler erfolgreich ODV-zurueckgesetzt!");
/*     */         
/*     */         return;
/*     */       } 
/* 226 */       target.getStats().loadStartDefaults();
/* 227 */       target.getStats().setState(PlayerState.ALIVE);
/* 228 */       if (target.getTeam() != null) {
/* 229 */         target.getTeam().removeMember(target);
/*     */       }
/* 231 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler '" + Main.getColorCode() + target.getName() + "§7' erfolgreich ODV-zurueckgesetzt!");
/*     */     } else {
/* 233 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Not found! Type " + Main.getColorCode() + label + " stats §7for help.");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\varo\StatsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */