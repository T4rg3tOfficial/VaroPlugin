/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.game.suro.SuroStart;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class IntroCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   private SuroStart suroStart;
/*    */   
/*    */   public IntroCommand() {
/* 16 */     super("intro", "Startet das SURO Intro", "varo.intro", new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 21 */     if (this.suroStart != null) {
/* 22 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Intro laeuft bereits!");
/*    */       
/*    */       return;
/*    */     } 
/* 26 */     if (Main.getVaroGame().hasStarted()) {
/* 27 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Das Spiel wurde bereits gestartet!");
/*    */       
/*    */       return;
/*    */     } 
/* 31 */     this.suroStart = new SuroStart();
/* 32 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "Und los geht's!");
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\varo\IntroCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */