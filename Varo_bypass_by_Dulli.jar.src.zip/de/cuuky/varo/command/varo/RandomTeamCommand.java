/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.utils.varo.VaroUtils;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class RandomTeamCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public RandomTeamCommand() {
/* 14 */     super("randomteam", "Gibt allen Spielern, die noch kein Team haben, einen zufaelligen Teampartner mit Groesse", "varo.randomteam", new String[] { "rt" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vpsender, Command cmd, String label, String[] args) {
/* 19 */     if (args.length != 1) {
/* 20 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/varo randomTeam <Teamgroesse>");
/*    */       
/*    */       return;
/*    */     } 
/* 24 */     int teamsize = 0;
/*    */     try {
/* 26 */       teamsize = Integer.parseInt(args[0]);
/* 27 */     } catch (NumberFormatException e) {
/* 28 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + args[0] + " §7ist keine Zahl!");
/*    */       
/*    */       return;
/*    */     } 
/* 32 */     if (teamsize < 1) {
/* 33 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Die Teamgroesse muss mindestens 1 betragen.");
/*    */       return;
/*    */     } 
/* 36 */     VaroUtils.doRandomTeam(teamsize);
/*    */ 
/*    */     
/* 39 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Alle Spieler, die ohne Teams waren, sind nun in " + Main.getColorCode() + teamsize + "§7er Teams!");
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\varo\RandomTeamCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */