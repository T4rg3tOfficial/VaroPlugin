/*     */ package de.cuuky.varo.command.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.team.VaroTeam;
/*     */ import de.cuuky.varo.utils.UUIDUtils;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ 
/*     */ public class TeamCommand
/*     */   extends VaroCommand
/*     */ {
/*     */   public TeamCommand() {
/*  15 */     super("team", "Hauptcommand fuer das Managen der Teams", "varo.teams", new String[] { "teams" });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/*  20 */     if (args.length == 0) {
/*  21 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getProjectName() + " §7Team setup Befehle:");
/*  22 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo team create §7<Teamname> <Spieler 1, 2, 3...>");
/*  23 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo team remove §7<Team/TeamID/Player/@a>");
/*  24 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo team add §7<Player> <Team/TeamID>");
/*  25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo team rename §7<Team-Name> <Neuer Team-Name>");
/*  26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo team colorcode §7<Team-Name> remove/<Farbcode>");
/*  27 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo team list");
/*     */       
/*     */       return;
/*     */     } 
/*  31 */     if (args[0].equalsIgnoreCase("create")) {
/*  32 */       if (args.length < 2) {
/*  33 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "/varo team create <Teamname> [Spieler 1, Spieler 2, Spieler 3...]");
/*     */         
/*     */         return;
/*     */       } 
/*  37 */       if (args[1].contains("#")) {
/*  38 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Der Name darf kein '#' enthalten. (Wird automatisch hinzugefuegt)");
/*     */         
/*     */         return;
/*     */       } 
/*  42 */       VaroTeam team = VaroTeam.getTeam(args[1]);
/*     */       
/*  44 */       if (team != null) {
/*  45 */         boolean teamIdentical = true;
/*  46 */         for (int j = 2; j < args.length; j++) {
/*  47 */           VaroPlayer player = VaroPlayer.getPlayer(args[j]);
/*  48 */           if (!team.getMember().contains(player) || player == null) {
/*  49 */             teamIdentical = false;
/*     */           }
/*     */         } 
/*  52 */         if (teamIdentical) {
/*  53 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Dieses Team ist bereits registriert.");
/*     */         } else {
/*  55 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cDas Team konnte nicht registriert werden, der Teamname ist bereits belegt.");
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*  60 */       team = new VaroTeam(args[1]);
/*  61 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Team " + Main.getColorCode() + team.getName() + " §7mit der ID " + Main.getColorCode() + team.getId() + " §7erfolgreich erstellt!");
/*     */       
/*  63 */       for (int i = 2; i < args.length; i++) {
/*  64 */         String arg = args[i];
/*     */         
/*  66 */         VaroPlayer varoplayer = VaroPlayer.getPlayer(arg);
/*  67 */         if (varoplayer == null) {
/*     */           String uuid;
/*     */           try {
/*  70 */             uuid = UUIDUtils.getUUID(arg).toString();
/*  71 */           } catch (Exception e) {
/*  72 */             sender.sendMessage(String.valueOf(Main.getPrefix()) + "§c" + arg + " wurde nicht gefunden.");
/*     */             
/*     */             try {
/*  75 */               String newName = UUIDUtils.getNamesChanged(arg);
/*  76 */               sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cEin Spieler, der in den letzten 30 Tagen " + arg + " hiess, hat sich in §7" + newName + " §cumbenannt.");
/*  77 */               sender.sendMessage(String.valueOf(Main.getPrefix()) + "Benutze \"/varo team add\", um diese Person einem Team hinzuzufuegen.");
/*  78 */             } catch (Exception f) {
/*  79 */               sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cIn den letzten 30 Tagen gab es keinen Spieler mit diesem Namen.");
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/*  84 */           varoplayer = new VaroPlayer(arg, uuid);
/*     */         } 
/*     */         
/*  87 */         team.addMember(varoplayer);
/*  88 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler " + Main.getColorCode() + varoplayer.getName() + " §7erfolgreich hinzugefuegt!");
/*     */       }  return;
/*     */     } 
/*  91 */     if (args[0].equalsIgnoreCase("remove") || args[0].equalsIgnoreCase("delete")) {
/*  92 */       if (args.length != 2) {
/*  93 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "/varo team remove <Team/TeamID/Player>");
/*     */         
/*     */         return;
/*     */       } 
/*  97 */       VaroTeam team = VaroTeam.getTeam(args[1]);
/*  98 */       VaroPlayer varoplayer = VaroPlayer.getPlayer(args[1]);
/*     */       
/* 100 */       if (team != null) {
/* 101 */         team.delete();
/* 102 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Team erfolgreich geloescht!");
/* 103 */       } else if (varoplayer != null) {
/* 104 */         varoplayer.getTeam().removeMember(varoplayer);
/* 105 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler " + Main.getColorCode() + varoplayer.getName() + " §7erfolgreich aus seinem Team entfernt!");
/* 106 */       } else if (args[1].equalsIgnoreCase("@a")) {
/* 107 */         while (VaroTeam.getTeams().size() > 0) {
/* 108 */           ((VaroTeam)VaroTeam.getTeams().get(0)).delete();
/*     */         }
/* 110 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Alle Teams erfolgreich geloescht!");
/*     */       } else {
/* 112 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Team, TeamID oder Spieler nicht gefunden!");
/*     */       }  return;
/* 114 */     }  if (args[0].equalsIgnoreCase("list")) {
/* 115 */       if (VaroTeam.getTeams().isEmpty()) {
/* 116 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Keine Teams gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/* 120 */       int teamNumber = VaroTeam.getTeams().size();
/* 121 */       int teamPages = 1 + teamNumber / 30;
/*     */       
/* 123 */       int lastTeamOnPage = 30;
/* 124 */       int page = 1;
/*     */       
/* 126 */       if (args.length != 1) {
/*     */         try {
/* 128 */           page = Integer.parseInt(args[1]);
/* 129 */         } catch (NumberFormatException e) {
/* 130 */           String uuid; page = 1;
/*     */         } 
/*     */         
/* 133 */         lastTeamOnPage = page * 30;
/*     */       } 
/*     */       
/* 136 */       if (page == teamPages) {
/* 137 */         lastTeamOnPage = teamNumber;
/*     */       }
/*     */       
/* 140 */       if (page > teamPages) {
/* 141 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Keine Seite " + page + " der Teams gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/* 145 */       if (teamPages == 1) {
/* 146 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§lListe aller " + Main.getColorCode() + " §lTeams§7§l:");
/*     */       } else {
/* 148 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§lListe der " + Main.getColorCode() + " §lTeams§7§l " + ((page - 1) * 30 + 1) + " bis " + lastTeamOnPage + ":");
/*     */       } 
/*     */       
/* 151 */       for (int i = (page - 1) * 30; i < lastTeamOnPage; i++) {
/* 152 */         VaroTeam team = VaroTeam.getTeams().get(i);
/* 153 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + " §l" + team.getId() + "§7; " + Main.getColorCode() + team.getName());
/* 154 */         String list = "";
/* 155 */         for (VaroPlayer member : team.getMember())
/* 156 */           list = list.isEmpty() ? (String.valueOf(Main.getColorCode()) + member.getName()) : (String.valueOf(list) + "§7, " + Main.getColorCode() + member.getName()); 
/* 157 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "  " + list);
/* 158 */         sender.sendMessage(Main.getPrefix());
/*     */       } 
/*     */       
/* 161 */       int lastTeamNextSeite = 0;
/* 162 */       if (page + 1 < teamPages) {
/* 163 */         lastTeamNextSeite = (page + 1) * 30;
/* 164 */       } else if (page + 1 == teamPages) {
/* 165 */         lastTeamNextSeite = teamNumber;
/*     */       } 
/* 167 */       if (page < teamPages)
/* 168 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo team list " + (page + 1) + " §7fuer " + Main.getColorCode() + "Teams §7 " + (page * 30 + 1) + " bis " + lastTeamNextSeite);  return;
/*     */     } 
/* 170 */     if (args[0].equalsIgnoreCase("rename"))
/* 171 */     { if (args.length != 3) {
/* 172 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo team rename §7<Team/TeamID> <Team>");
/*     */         
/*     */         return;
/*     */       } 
/* 176 */       if (args[1].startsWith("#") || args[2].startsWith("#")) {
/* 177 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Deine Teamnamen duerfen nicht mit " + Main.getColorCode() + "# §7anfangen!");
/*     */         
/*     */         return;
/*     */       } 
/* 181 */       VaroTeam team = VaroTeam.getTeam(args[1]);
/*     */       
/* 183 */       if (team == null) {
/* 184 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Team nicht gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/* 188 */       team.setName(args[2]);
/* 189 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Das Team " + Main.getColorCode() + args[1] + " §7wurde erfolgreich in " + Main.getColorCode() + team.getName() + " §7umbenannt!"); }
/* 190 */     else { if (args[0].equalsIgnoreCase("add")) {
/* 191 */         if (args.length != 3) {
/* 192 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "/varo team add <Player> <Team/TeamID>");
/*     */           
/*     */           return;
/*     */         } 
/* 196 */         VaroPlayer varoplayer = VaroPlayer.getPlayer(args[1]);
/* 197 */         VaroTeam team = VaroTeam.getTeam(args[2]);
/*     */         
/* 199 */         if (team == null) {
/* 200 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Team nicht gefunden!");
/*     */           
/*     */           return;
/*     */         } 
/* 204 */         if (varoplayer == null) {
/* 205 */           String uuid = null;
/*     */           try {
/* 207 */             uuid = UUIDUtils.getUUID(args[1]).toString();
/* 208 */           } catch (Exception e) {
/* 209 */             sender.sendMessage(String.valueOf(Main.getPrefix()) + args[1] + " besitzt keinen Minecraft-Account!");
/*     */             
/*     */             return;
/*     */           } 
/* 213 */           varoplayer = new VaroPlayer(args[1], uuid);
/*     */         } 
/*     */         
/* 216 */         if (varoplayer.getTeam() != null) {
/* 217 */           if (varoplayer.getTeam().equals(team)) {
/* 218 */             sender.sendMessage(String.valueOf(Main.getPrefix()) + "Dieser Spieler ist bereits in diesem Team!");
/*     */             
/*     */             return;
/*     */           } 
/* 222 */           varoplayer.getTeam().removeMember(varoplayer);
/* 223 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + varoplayer.getName() + " §7wurde aus seinem jetzigen Team entfernt!");
/*     */         } 
/*     */         
/* 226 */         team.addMember(varoplayer);
/* 227 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler " + Main.getColorCode() + varoplayer.getName() + " §7erfolgreich in das Team " + Main.getColorCode() + team.getName() + " §7gesetzt!"); return;
/*     */       } 
/* 229 */       if (args[0].equalsIgnoreCase("colorcode")) {
/* 230 */         if (args.length != 3) {
/* 231 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo team colorcode §7<Team/TeamID> remove/<Farbcode>");
/*     */           
/*     */           return;
/*     */         } 
/* 235 */         VaroTeam team = VaroTeam.getTeam(args[1]);
/* 236 */         if (team == null) {
/* 237 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Team nicht gefunden!");
/*     */           
/*     */           return;
/*     */         } 
/* 241 */         if (args[2].equalsIgnoreCase("remove")) {
/* 242 */           team.setColorCode(null);
/* 243 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Team-Farbcode vom Team " + team.getDisplay() + " §7erfolgreich entfernt");
/*     */           
/*     */           return;
/*     */         } 
/* 247 */         team.setColorCode(args[2]);
/* 248 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Team-Farbcode vom Team " + team.getDisplay() + " §7erfolgreich geaendert!");
/*     */       } else {
/* 250 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Befehl nicht gefunden! " + Main.getColorCode() + "/team");
/*     */       }  }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\varo\TeamCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */