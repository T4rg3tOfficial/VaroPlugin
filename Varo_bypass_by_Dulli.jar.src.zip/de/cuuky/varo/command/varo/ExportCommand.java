/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.team.VaroTeam;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ 
/*    */ 
/*    */ public class ExportCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public ExportCommand() {
/* 19 */     super("export", "Optionen zum Exportieren", "varo.export", new String[] { "Exportiert, Teams, Spieler etc." });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 24 */     if (args.length == 0) {
/* 25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7----- §l" + Main.getColorCode() + "Export" + "§7 -----");
/* 26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo export players | Exportiert alle Spieler");
/*    */     } 
/*    */     
/* 29 */     if (args.length != 1) {
/* 30 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo export players | Exportiert alle Spieler");
/*    */       
/*    */       return;
/*    */     } 
/* 34 */     if (args[0].equalsIgnoreCase("players")) {
/* 35 */       File file = new File("plugins/Varo/exports/players.yml");
/* 36 */       if (file.exists()) {
/* 37 */         file.delete();
/*    */       }
/* 39 */       YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
/* 40 */       ArrayList<VaroPlayer> finished = new ArrayList<>();
/*    */       
/* 42 */       for (VaroPlayer player : VaroPlayer.getVaroPlayer()) {
/* 43 */         if (finished.contains(player)) {
/*    */           continue;
/*    */         }
/* 46 */         if (player.getTeam() == null) {
/* 47 */           yaml.set(String.valueOf(player.getName()) + ".name", player.getName());
/* 48 */           yaml.set(String.valueOf(player.getName()) + ".youtubeLink", (player.getStats().getYoutubeLink() == null) ? "/" : player.getStats().getYoutubeLink());
/* 49 */           finished.add(player);
/*    */         } 
/*    */       } 
/*    */       
/* 53 */       for (VaroTeam team : VaroTeam.getTeams()) {
/* 54 */         String pref = "#" + team.getName();
/* 55 */         yaml.set(String.valueOf(pref) + ".id", Integer.valueOf(team.getId()));
/* 56 */         for (VaroPlayer teamPl : team.getMember()) {
/* 57 */           if (finished.contains(teamPl)) {
/*    */             continue;
/*    */           }
/* 60 */           yaml.set(String.valueOf(pref) + ".member." + teamPl.getName() + ".name", teamPl.getName());
/* 61 */           yaml.set(String.valueOf(pref) + ".member." + teamPl.getName() + ".youtubeLink", (teamPl.getStats().getYoutubeLink() == null) ? "/" : teamPl.getStats().getYoutubeLink());
/*    */         } 
/*    */       } 
/*    */       
/*    */       try {
/* 66 */         yaml.save(file);
/* 67 */       } catch (IOException e) {
/* 68 */         e.printStackTrace();
/*    */       } 
/*    */       
/* 71 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Successfully saved to '/plugins/Varo/exports/players.yml'!");
/*    */     } else {
/* 73 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Command not found.");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\varo\ExportCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */