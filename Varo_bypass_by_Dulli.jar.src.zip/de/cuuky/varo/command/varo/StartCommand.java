/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.game.VaroGame;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class StartCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public StartCommand() {
/* 14 */     super("start", "Startet das Varo", "varo.start", new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 19 */     VaroGame game = Main.getVaroGame();
/* 20 */     if (game.isStarting()) {
/* 21 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Das Spiel startet bereits!");
/*    */       
/*    */       return;
/*    */     } 
/* 25 */     if (game.hasStarted()) {
/* 26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Das Spiel wurde bereits gestartet!");
/*    */       
/*    */       return;
/*    */     } 
/* 30 */     game.start();
/* 31 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spiel erfolgreich gestartet!");
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\varo\StartCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */