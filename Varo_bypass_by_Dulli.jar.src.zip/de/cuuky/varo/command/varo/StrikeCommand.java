/*     */ package de.cuuky.varo.command.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.stat.Strike;
/*     */ import java.text.SimpleDateFormat;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StrikeCommand
/*     */   extends VaroCommand
/*     */ {
/*     */   public StrikeCommand() {
/*  17 */     super("strike", "Benutze diesen Command um einen Spieler zu striken", "varo.strike", new String[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/*  22 */     if (args.length == 0) {
/*  23 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7------ " + Main.getColorCode() + "Strike §7-----");
/*  24 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo strike §7<Player> [Grund]");
/*  25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo strike list §7<Player>");
/*  26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo strike remove §7<Player> <StrikeNummer>");
/*  27 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7-----------------------");
/*     */       
/*     */       return;
/*     */     } 
/*  31 */     if (VaroPlayer.getPlayer(args[0]) != null) {
/*  32 */       VaroPlayer varoPlayer = VaroPlayer.getPlayer(args[0]);
/*     */       
/*  34 */       String reason = ""; byte b; int i; String[] arrayOfString;
/*  35 */       for (i = (arrayOfString = args).length, b = 0; b < i; ) { String key = arrayOfString[b];
/*  36 */         if (!key.equals(args[0]))
/*     */         {
/*  38 */           reason = String.valueOf(reason) + key; } 
/*     */         b++; }
/*     */       
/*  41 */       if (reason.isEmpty()) {
/*  42 */         reason = "Ohne Begruendung";
/*     */       }
/*     */       
/*  45 */       Strike strike = new Strike(reason, varoPlayer, (sender instanceof org.bukkit.command.ConsoleCommandSender) ? "CONSOLE" : sender.getName());
/*  46 */       varoPlayer.getStats().addStrike(strike);
/*  47 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du hast " + varoPlayer.getName() + " gestriket!"); return;
/*     */     } 
/*  49 */     if (args[0].equalsIgnoreCase("remove")) {
/*  50 */       if (args.length != 3) {
/*  51 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/strike remove §7<Spieler> <Zahl>");
/*     */         
/*     */         return;
/*     */       } 
/*  55 */       VaroPlayer varoPlayer = VaroPlayer.getPlayer(args[1]);
/*     */       
/*  57 */       if (varoPlayer == null) {
/*  58 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + args[1] + " §7nicht gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/*  62 */       if (varoPlayer.getStats().getStrikes().size() < 1) {
/*  63 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + varoPlayer.getName() + " §7hat keine Strikes!");
/*     */         
/*     */         return;
/*     */       } 
/*  67 */       int num = -1;
/*     */       try {
/*  69 */         num = Integer.parseInt(args[2]) - 1;
/*  70 */       } catch (NumberFormatException e) {
/*  71 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + args[2] + " ist keine Zahl!");
/*     */         
/*     */         return;
/*     */       } 
/*  75 */       if (num >= varoPlayer.getStats().getStrikes().size()) {
/*  76 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Strike " + args[2] + " nicht gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/*  80 */       varoPlayer.getStats().removeStrike(varoPlayer.getStats().getStrikes().get(num));
/*  81 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du hast " + Main.getColorCode() + varoPlayer.getName() + " §7einen Strike entfernt! Er hat noch " + Main.getColorCode() + varoPlayer.getStats().getStrikes().size() + " §7Strikes!");
/*  82 */     } else if (args[0].equalsIgnoreCase("list")) {
/*  83 */       if (args.length != 2) {
/*  84 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/strike list §7<Spieler>");
/*     */         
/*     */         return;
/*     */       } 
/*  88 */       VaroPlayer varoPlayer = VaroPlayer.getPlayer(args[1]);
/*     */       
/*  90 */       if (varoPlayer == null) {
/*  91 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + args[1] + " §7nicht gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/*  95 */       if (varoPlayer.getStats().getStrikes().size() < 1) {
/*  96 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + varoPlayer.getName() + " §7hat keine Strikes!");
/*     */         
/*     */         return;
/*     */       } 
/* 100 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Strikes von " + Main.getColorCode() + varoPlayer.getName() + "§7:");
/* 101 */       for (Strike strike : varoPlayer.getStats().getStrikes()) {
/* 102 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Strike Nr." + strike.getStrikeNumber() + "§8:");
/* 103 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Reason: §7" + strike.getReason());
/* 104 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Striker: §7" + strike.getStriker());
/* 105 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Acquired: §7" + (new SimpleDateFormat("dd:MM:yyy HH:mm")).format(strike.getAcquiredDate()));
/*     */       } 
/*     */     } else {
/* 108 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Nicht gefunden! " + Main.getColorCode() + "/strike §7fuer Hilfe.");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\varo\StrikeCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */