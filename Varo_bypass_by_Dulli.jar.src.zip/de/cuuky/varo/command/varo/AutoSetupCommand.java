/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ 
/*    */ public class AutoSetupCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public AutoSetupCommand() {
/* 15 */     super("autosetup", "Setzt den Server automatisch auf", "varo.autosetup", new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 20 */     if (args.length >= 1 && 
/* 21 */       args[0].equalsIgnoreCase("run")) {
/* 22 */       if (!ConfigSetting.AUTOSETUP_ENABLED.getValueAsBoolean()) {
/* 23 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Der AutoSetup wurde noch nicht in der Config eingerichtet!");
/*    */         
/*    */         return;
/*    */       } 
/*    */       
/* 28 */       for (VaroPlayer player : VaroPlayer.getOnlinePlayer()) {
/* 29 */         player.getPlayer().teleport(Main.getVaroGame().getVaroWorldHandler().getTeleportLocation());
/*    */       }
/* 31 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Der AutoSetup ist fertig.");
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 36 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo autosetup run §7startet den Autosetup");
/* 37 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cVorsicht: §7Dieser Befehl setzt neue Spawns, Lobby, Portal, Border und §loptional§7 einen Autostart.");
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\varo\AutoSetupCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */