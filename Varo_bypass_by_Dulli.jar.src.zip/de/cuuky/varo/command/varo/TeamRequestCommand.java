/*     */ package de.cuuky.varo.command.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.team.request.VaroTeamRequest;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class TeamRequestCommand
/*     */   extends VaroCommand
/*     */ {
/*     */   public TeamRequestCommand() {
/*  18 */     super("teamrequest", "Sendet einem anderen Spieler eine Teamanfrage", null, new String[] { "tr", "request" });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer player, Command cmd, String label, String[] args) {
/*  23 */     if (!(sender instanceof Player)) {
/*  24 */       System.out.println("Not for console!");
/*     */       
/*     */       return;
/*     */     } 
/*  28 */     if (!ConfigSetting.TEAMREQUEST_ENABLED.getValueAsBoolean()) {
/*  29 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Das " + Main.getColorCode() + "Teamanfragen-System §7wurde in der Config deaktiviert!");
/*     */       
/*     */       return;
/*     */     } 
/*  33 */     if (Main.getVaroGame().hasStarted()) {
/*  34 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du kannst dein Team nicht wechseln, da " + Main.getProjectName() + " schon gestartet ist!");
/*     */       
/*     */       return;
/*     */     } 
/*  38 */     if (args.length == 0) {
/*  39 */       sendInfo((Player)sender); return;
/*     */     } 
/*  41 */     if (args[0].equals("help")) {
/*  42 */       sendInfo((Player)sender);
/*     */       
/*     */       return;
/*     */     } 
/*  46 */     if (args[0].equalsIgnoreCase("invite")) {
/*  47 */       if (args.length < 2) {
/*  48 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/tr invite §7<Player 1, Player 2, ...>"); return;
/*     */       }  byte b;
/*     */       int i;
/*     */       String[] arrayOfString;
/*  52 */       for (i = (arrayOfString = args).length, b = 0; b < i; ) { String arg = arrayOfString[b];
/*  53 */         if (!arg.equals(args[0])) {
/*     */ 
/*     */           
/*  56 */           VaroPlayer invite = VaroPlayer.getPlayer(arg);
/*  57 */           if (invite == null)
/*  58 */           { sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + arg + " §7nicht gefunden!");
/*     */             
/*     */              }
/*     */           
/*  62 */           else if (invite.equals(player))
/*  63 */           { sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du kannst dich nicht selbst einladen!"); }
/*     */           
/*     */           else
/*     */           
/*  67 */           { if (VaroTeamRequest.getByAll(player, invite) != null) {
/*  68 */               sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du hast bereits eine Anfrage an §7" + arg + " §7verschickt! Versuche es in " + ConfigSetting.TEAMREQUEST_EXPIRETIME.getValueAsInt() + " Sekunden erneut!");
/*     */               
/*     */               return;
/*     */             } 
/*  72 */             if (invite.getTeam() != null && player.getTeam() != null && 
/*  73 */               invite.getTeam().equals(player.getTeam()))
/*  74 */             { sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du und " + Main.getColorCode() + invite.getName() + " §7sind bereits im selben Team!"); }
/*     */             
/*     */             else
/*     */             
/*  78 */             { invite.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.TEAMREQUEST_TEAM_REQUEST_RECIEVED.getValue(player).replace("%invitor%", player.getName()));
/*  79 */               player.sendMessage(String.valueOf(Main.getPrefix()) + "Du hast eine Teamanfrage an " + Main.getColorCode() + invite.getName() + " §7gesendet"); }  } 
/*     */         }  b++; }
/*     */     
/*  82 */     } else if (args[0].equalsIgnoreCase("accept") || args[0].equalsIgnoreCase("decline")) {
/*  83 */       if (args.length != 2) {
/*  84 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/tr accept/decline <Player>");
/*     */         
/*     */         return;
/*     */       } 
/*  88 */       if (Bukkit.getPlayerExact(args[1]) == null) {
/*  89 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Spieler " + Main.getColorCode() + args[1] + " §7nicht gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/*  93 */       VaroPlayer varoPlayer = VaroPlayer.getPlayer(Bukkit.getPlayerExact(args[1]));
/*  94 */       VaroTeamRequest tr = VaroTeamRequest.getByAll(varoPlayer, player);
/*     */       
/*  96 */       if (tr == null) {
/*  97 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Einladung von " + Main.getColorCode() + args[1] + " §7nicht gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/* 101 */       if (args[0].equalsIgnoreCase("accept")) {
/* 102 */         player.sendMessage(String.valueOf(Main.getPrefix()) + "Du hast die Anfrage von " + Main.getColorCode() + varoPlayer.getName() + " §7angenommen");
/* 103 */         varoPlayer.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + player.getName() + " §7hat deine Team anfrage angenommen!");
/* 104 */         tr.accept();
/*     */       } else {
/* 106 */         player.sendMessage(String.valueOf(Main.getPrefix()) + "Du hast die Anfrage von " + Main.getColorCode() + varoPlayer.getName() + " §abgelehnt!");
/* 107 */         varoPlayer.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + player.getName() + " §7hat deine Team anfrage abgelehnt!");
/* 108 */         tr.decline();
/*     */       } 
/* 110 */     } else if (args[0].equalsIgnoreCase("revoke")) {
/* 111 */       if (args.length != 2) {
/* 112 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/tr revoke <Player>");
/*     */         
/*     */         return;
/*     */       } 
/* 116 */       if (Bukkit.getPlayer(args[1]) == null) {
/* 117 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Spieler §7" + args[1] + " §7nicht gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/* 121 */       VaroTeamRequest.getByAll(player, VaroPlayer.getPlayer(args[1]));
/* 122 */       VaroTeamRequest tr = VaroTeamRequest.getByInvitor(VaroPlayer.getPlayer(args[1]));
/*     */       
/* 124 */       if (tr == null) {
/* 125 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du hast keine Einladung an " + Main.getColorCode() + args[1] + " §7verschickt!");
/*     */         
/*     */         return;
/*     */       } 
/* 129 */       tr.revoke();
/* 130 */     } else if (args[0].equalsIgnoreCase("leave")) {
/* 131 */       if (args.length != 1) {
/* 132 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/tr leave");
/*     */         
/*     */         return;
/*     */       } 
/* 136 */       if (player.getTeam() == null) {
/* 137 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du bist in keinem Team!");
/*     */         
/*     */         return;
/*     */       } 
/* 141 */       player.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du hast dein Team " + Main.getColorCode() + player.getTeam().getDisplay() + " §7erfolgreich verlassen!");
/* 142 */       player.getTeam().removeMember(player);
/*     */     } else {
/* 144 */       player.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + args[0] + " §kein Argument!");
/* 145 */       sendInfo(player.getPlayer());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendInfo(Player sender) {
/* 152 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7--- " + Main.getColorCode() + "TeamRequestor-System §7---");
/* 153 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo tr invite §7<Player 1, Player 2, ...>");
/* 154 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo tr revoke §7<Player>");
/* 155 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo tr decline §7<Player>");
/* 156 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo tr accept §7<Player>");
/* 157 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo tr leave");
/* 158 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo tr help");
/* 159 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7--------------------------");
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\varo\TeamRequestCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */