/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GameCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public GameCommand() {
/* 15 */     super("game", "Öffnet das Spieloptionen Menue", "varo.game", new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 20 */     if (!(sender instanceof org.bukkit.entity.Player)) {
/* 21 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du musst ein Spieler sein!");
/*    */       return;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\varo\GameCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */