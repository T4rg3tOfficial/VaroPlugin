/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class AbortCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public AbortCommand() {
/* 13 */     super("abort", "Bricht den Startcountdown ab", "varo.abort", new String[] { "abbruch", "abbrechen", "stop" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 18 */     if (!Main.getVaroGame().isStarting()) {
/* 19 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Der Startcountdown ist nicht aktiv!");
/*    */       
/*    */       return;
/*    */     } 
/* 23 */     Main.getVaroGame().abort();
/* 24 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "Startcountdown erfolgreich gestoppt!");
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\command\varo\AbortCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */