/*    */ package de.cuuky.varo.recovery.recoveries;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.recovery.FileZipper;
/*    */ import de.cuuky.varo.utils.JavaUtils;
/*    */ import java.io.File;
/*    */ import java.nio.file.Paths;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroBackup
/*    */   extends FileZipper
/*    */ {
/* 16 */   private static ArrayList<VaroBackup> backups = new ArrayList<>();
/*    */   static {
/* 18 */     loadBackups();
/*    */   }
/*    */   
/*    */   public VaroBackup() {
/* 22 */     super(new File("plugins/Varo/backups/" + JavaUtils.getCurrentDateAsFileable() + ".zip"));
/*    */     
/* 24 */     Main.getDataManager().save();
/*    */     
/* 26 */     zip(getFiles("plugins/Varo"), Paths.get("plugins/Varo", new String[0]));
/*    */     
/* 28 */     backups.add(this);
/*    */   }
/*    */   
/*    */   private ArrayList<File> getFiles(String path) {
/* 32 */     File pathFile = new File(path);
/* 33 */     ArrayList<File> files = new ArrayList<>(); byte b; int i;
/*    */     File[] arrayOfFile;
/* 35 */     for (i = (arrayOfFile = pathFile.listFiles()).length, b = 0; b < i; ) { File file = arrayOfFile[b];
/* 36 */       if (file.isDirectory()) {
/* 37 */         files.addAll(getFiles(file.getPath()));
/*    */       } else {
/* 39 */         files.add(file);
/*    */       }  b++; }
/*    */     
/* 42 */     return files;
/*    */   }
/*    */   
/*    */   public VaroBackup(File file) {
/* 46 */     super(file);
/*    */   }
/*    */   
/*    */   public void delete() {
/* 50 */     this.zipFile.delete();
/* 51 */     backups.remove(this);
/*    */   }
/*    */   
/*    */   private static void loadBackups() {
/* 55 */     File file = new File("plugins/Varo/backups/");
/* 56 */     if (!file.isDirectory())
/*    */       return;  byte b; int i;
/*    */     File[] arrayOfFile;
/* 59 */     for (i = (arrayOfFile = file.listFiles()).length, b = 0; b < i; ) { File listFile = arrayOfFile[b];
/* 60 */       if (listFile.getName().endsWith(".zip"))
/* 61 */         backups.add(new VaroBackup(listFile)); 
/*    */       b++; }
/*    */   
/*    */   } public static VaroBackup getBackup(String filename) {
/* 65 */     for (VaroBackup backup : backups) {
/* 66 */       if (!backup.getZipFile().getName().equals(filename.endsWith(".zip") ? filename : (String.valueOf(filename) + ".zip"))) {
/*    */         continue;
/*    */       }
/* 69 */       return backup;
/*    */     } 
/*    */     
/* 72 */     return null;
/*    */   }
/*    */   
/*    */   public static ArrayList<VaroBackup> getBackups() {
/* 76 */     return backups;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\recovery\recoveries\VaroBackup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */