/*    */ package de.cuuky.varo.recovery.recoveries;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.recovery.FileZipper;
/*    */ import de.cuuky.varo.threads.LagCounter;
/*    */ import de.cuuky.varo.utils.JavaUtils;
/*    */ import java.io.File;
/*    */ import java.nio.file.Paths;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.plugin.PluginDescriptionFile;
/*    */ 
/*    */ public class VaroBugreport
/*    */   extends FileZipper
/*    */ {
/*    */   private static List<String> exeptions;
/*    */   private String discordBotToken;
/*    */   
/*    */   static {
/* 25 */     String[] exc = { "chatlogs.yml", "blocklogs.yml", "presets", "backups" };
/*    */     
/* 27 */     exeptions = Arrays.asList(exc);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public VaroBugreport() {
/* 33 */     super(new File("plugins/Varo/bugreports/bugreport-" + JavaUtils.getCurrentDateAsFileable() + ".zip"));
/* 34 */     ArrayList<File> files = getFiles("plugins/Varo");
/*    */     
/* 36 */     this.discordBotToken = ConfigSetting.DISCORDBOT_TOKEN.getValueAsString();
/* 37 */     ConfigSetting.DISCORDBOT_TOKEN.setValue("hidden", true);
/*    */     
/* 39 */     postInformation();
/* 40 */     files.add(new File("logs/latest.log"));
/*    */     
/* 42 */     zip(files, Paths.get("", new String[0]));
/*    */     
/* 44 */     ConfigSetting.DISCORDBOT_TOKEN.setValue(this.discordBotToken, true);
/*    */   }
/*    */   
/*    */   private void postInformation() {
/* 48 */     PluginDescriptionFile pdf = Main.getInstance().getDescription();
/* 49 */     Runtime r = Runtime.getRuntime();
/*    */     
/* 51 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "----------------------");
/* 52 */     System.out.println(Main.getConsolePrefix());
/* 53 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Plugin Version: " + pdf.getVersion());
/* 54 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Plugins enabled: " + (Bukkit.getPluginManager().getPlugins()).length);
/* 55 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Server-Version: " + Bukkit.getVersion());
/* 56 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "System OS: " + System.getProperty("os.name"));
/* 57 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "System Version: " + System.getProperty("os.version"));
/* 58 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Java Version: " + System.getProperty("java.version"));
/* 59 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Total memory usage: " + ((r.totalMemory() - r.freeMemory()) / 1048576L) + "MB!");
/* 60 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Total memory available: " + (r.maxMemory() / 1048576L) + "MB!");
/* 61 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "TPS: " + (Math.round(LagCounter.getTPS() * 100.0D) / 100.0D));
/* 62 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Date: " + (new SimpleDateFormat("dd.MM.yyyy HH:mm")).format(new Date()));
/* 63 */     System.out.println(Main.getConsolePrefix());
/* 64 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "----------------------");
/*    */   }
/*    */   
/*    */   private ArrayList<File> getFiles(String path) {
/* 68 */     File pathFile = new File(path);
/* 69 */     ArrayList<File> files = new ArrayList<>(); byte b; int i;
/*    */     File[] arrayOfFile;
/* 71 */     for (i = (arrayOfFile = pathFile.listFiles()).length, b = 0; b < i; ) { File file = arrayOfFile[b];
/* 72 */       if (!exeptions.contains(file.getName()))
/*    */       {
/*    */         
/* 75 */         if (file.isDirectory()) {
/* 76 */           files.addAll(getFiles(file.getPath()));
/*    */         } else {
/* 78 */           files.add(file);
/*    */         }  }  b++; }
/*    */     
/* 81 */     return files;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\recovery\recoveries\VaroBugreport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */