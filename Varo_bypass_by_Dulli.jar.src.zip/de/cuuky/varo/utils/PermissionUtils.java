/*    */ package de.cuuky.varo.utils;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PermissionUtils
/*    */ {
/*    */   public static String getLuckPermsPrefix(VaroPlayer player) {
/*    */     try {
/* 11 */       Object api = Class.forName("me.lucko.luckperms.LuckPerms").getDeclaredMethod("getApi", new Class[0]).invoke(null, new Object[0]);
/*    */       
/* 13 */       Object user = api.getClass().getMethod("getUser", new Class[] { String.class }).invoke(api, new Object[] { player.getUuid() });
/* 14 */       String groupname = (String)user.getClass().getMethod("getPrimaryGroup", new Class[0]).invoke(api, new Object[0]);
/*    */       
/* 16 */       Object group = api.getClass().getMethod("getGroup", new Class[] { String.class }).invoke(api, new Object[] { groupname });
/* 17 */       Object cachedData = group.getClass().getMethod("getCachedData", new Class[0]).invoke(group, new Object[0]);
/*    */       
/* 19 */       Object contexts = Class.forName("me.lucko.luckperms.api.Contexts").getDeclaredMethod("allowAll", new Class[0]).invoke(null, new Object[0]);
/*    */       
/* 21 */       Object metadata = cachedData.getClass().getMethod("getMetaData", new Class[] { contexts.getClass() }).invoke(cachedData, new Object[] { contexts });
/* 22 */       return (String)metadata.getClass().getMethod("getPrefix", new Class[0]).invoke(metadata, new Object[0]);
/* 23 */     } catch (Throwable throwable) {
/*    */       
/* 25 */       return "";
/*    */     } 
/*    */   }
/*    */   
/*    */   public static String getPermissionsExPrefix(VaroPlayer player) {
/*    */     try {
/* 31 */       Object permissionUser = Class.forName("ru.tehkode.permissions.bukkit.PermissionsEx").getDeclaredMethod("getUser", new Class[] { String.class }).invoke(null, new Object[] { player.getName() });
/* 32 */       Object group = ((Object[])permissionUser.getClass().getDeclaredMethod("getGroups", new Class[0]).invoke(permissionUser, new Object[0]))[0];
/*    */       
/* 34 */       return (String)group.getClass().getMethod("getPrefix", new Class[0]).invoke(group, new Object[0]);
/* 35 */     } catch (Throwable throwable) {
/*    */       
/* 37 */       return "";
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\var\\utils\PermissionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */