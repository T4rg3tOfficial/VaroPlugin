/*    */ package de.cuuky.varo.utils.varo;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Scanner;
/*    */ 
/*    */ public class ServerPropertiesReader
/*    */ {
/*    */   private HashMap<String, String> configuration;
/*    */   
/*    */   public ServerPropertiesReader() {
/* 13 */     this.configuration = new HashMap<>();
/*    */     
/* 15 */     readProperties();
/*    */   }
/*    */   
/*    */   private void readProperties() {
/* 19 */     Scanner scanner = null;
/*    */     try {
/* 21 */       scanner = new Scanner(new File("server.properties"));
/* 22 */       while (scanner.hasNextLine()) {
/* 23 */         String[] line = scanner.nextLine().split("=");
/* 24 */         if (line.length != 2) {
/*    */           continue;
/*    */         }
/* 27 */         this.configuration.put(line[0], line[1]);
/*    */       }
/*    */     
/* 30 */     } catch (FileNotFoundException e) {
/* 31 */       e.printStackTrace();
/*    */     } finally {
/* 33 */       scanner.close();
/*    */     } 
/*    */   }
/*    */   
/*    */   public HashMap<String, String> getConfiguration() {
/* 38 */     return this.configuration;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\var\\utils\varo\ServerPropertiesReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */