/*    */ package de.cuuky.varo.utils.varo;
/*    */ 
/*    */ import org.bukkit.Location;
/*    */ 
/*    */ public class LocationFormat {
/*    */   private Location location;
/*    */   
/*    */   public LocationFormat(Location location) {
/*  9 */     this.location = location;
/*    */   }
/*    */   
/*    */   public String format(String format) {
/* 13 */     return format.replace("x", String.valueOf(this.location.getBlockX())).replace("y", String.valueOf(this.location.getBlockY())).replace("z", String.valueOf(this.location.getBlockZ())).replace("world", this.location.getWorld().getName());
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\var\\utils\varo\LocationFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */