/*    */ package de.cuuky.varo.utils.varo;
/*    */ 
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import java.util.GregorianCalendar;
/*    */ 
/*    */ public class OutSideTimeChecker
/*    */ {
/*    */   private GregorianCalendar date1;
/*    */   private GregorianCalendar date2;
/*    */   
/*    */   public OutSideTimeChecker() {
/* 12 */     refreshDates();
/*    */   }
/*    */   
/*    */   private void refreshDates() {
/* 16 */     this.date1 = new GregorianCalendar();
/* 17 */     this.date1.set(13, 0);
/* 18 */     this.date2 = (GregorianCalendar)this.date1.clone();
/*    */     
/* 20 */     this.date1.set(11, ConfigSetting.ONLY_JOIN_BETWEEN_HOURS_HOUR1.getValueAsInt());
/* 21 */     this.date1.set(12, ConfigSetting.ONLY_JOIN_BETWEEN_HOURS_MINUTE1.getValueAsInt());
/* 22 */     this.date2.set(11, ConfigSetting.ONLY_JOIN_BETWEEN_HOURS_HOUR2.getValueAsInt());
/* 23 */     this.date2.set(12, ConfigSetting.ONLY_JOIN_BETWEEN_HOURS_MINUTE2.getValueAsInt());
/*    */     
/* 25 */     if (this.date2.before(this.date1))
/* 26 */       this.date2.add(5, 1); 
/*    */   }
/*    */   
/*    */   public boolean canJoin() {
/* 30 */     if (!ConfigSetting.ONLY_JOIN_BETWEEN_HOURS.getValueAsBoolean()) {
/* 31 */       return true;
/*    */     }
/* 33 */     GregorianCalendar current = new GregorianCalendar();
/* 34 */     refreshDates();
/* 35 */     if (current.after(this.date1) && current.before(this.date2)) {
/* 36 */       return true;
/*    */     }
/* 38 */     return false;
/*    */   }
/*    */   
/*    */   public GregorianCalendar getDate1() {
/* 42 */     return this.date1;
/*    */   }
/*    */   
/*    */   public GregorianCalendar getDate2() {
/* 46 */     return this.date2;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\var\\utils\varo\OutSideTimeChecker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */