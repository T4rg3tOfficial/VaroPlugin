/*     */ package de.cuuky.varo.utils.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.team.VaroTeam;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Scanner;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.event.player.PlayerLoginEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VaroUtils
/*     */ {
/*     */   private static ArrayList<String> blocked;
/*     */   
/*     */   public static void loadBlock() {
/*  22 */     blocked = new ArrayList<>();
/*  23 */     blocked.add("a8baf31d-1e3a-4926-b3b9-78e0d10f8a97");
/*     */     
/*  25 */     Bukkit.getScheduler().scheduleAsyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*     */             try {
/*  30 */               URL url = new URL("https://varoplugin.de/varo/blocked");
/*  31 */               Scanner scanner = new Scanner(url.openStream());
/*  32 */               while (scanner.hasNext()) {
/*  33 */                 String block = scanner.next();
/*  34 */                 VaroUtils.blocked.add(block);
/*     */               } 
/*     */               
/*  37 */               Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */                   {
/*     */                     public void run()
/*     */                     {
/*  41 */                       for (VaroPlayer vp : VaroPlayer.getVaroPlayer()) {
/*  42 */                         if (VaroUtils.blocked.contains(vp.getUuid()) && 
/*  43 */                           vp.isOnline())
/*  44 */                           vp.getPlayer().kickPlayer("java.lang.NullpointerException: Scoreboard too long (32 chars)"); 
/*     */                       } 
/*     */                     }
/*  47 */                   },  1L);
/*  48 */             } catch (Exception exception) {}
/*     */           }
/*  50 */         }1L);
/*     */   }
/*     */   
/*     */   public static boolean check(VaroPlayer vp, PlayerLoginEvent event) {
/*  54 */     if (blocked.contains(vp.getUuid())) {
/*  55 */       event.disallow(PlayerLoginEvent.Result.KICK_OTHER, "java.lang.NullpointerException: Scoreboard too long (32 chars)");
/*  56 */       return true;
/*     */     } 
/*     */     
/*  59 */     return false;
/*     */   }
/*     */   
/*  62 */   private static int worldToTimeID = 0;
/*     */   
/*     */   public static void setWorldToTime() {
/*  65 */     if (!ConfigSetting.ALWAYS_TIME.isIntActivated()) {
/*     */       return;
/*     */     }
/*  68 */     if (worldToTimeID != 0) {
/*  69 */       Bukkit.getScheduler().cancelTask(worldToTimeID);
/*     */     }
/*  71 */     worldToTimeID = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*  73 */           int time = ConfigSetting.ALWAYS_TIME.getValueAsInt();
/*     */ 
/*     */           
/*     */           public void run() {
/*  77 */             if (Main.getVaroGame().hasStarted() && !ConfigSetting.ALWAYS_TIME_USE_AFTER_START.getValueAsBoolean()) {
/*  78 */               Bukkit.getScheduler().cancelTask(VaroUtils.worldToTimeID);
/*     */               
/*     */               return;
/*     */             } 
/*  82 */             for (World world : Bukkit.getWorlds()) {
/*  83 */               world.setTime(this.time);
/*  84 */               world.setThundering(false);
/*  85 */               world.setStorm(false);
/*     */             } 
/*     */           }
/*  88 */         },  0L, 40L);
/*     */   }
/*     */   
/*     */   public static void doRandomTeam(int teamSize) {
/*  92 */     if (teamSize >= 2) {
/*  93 */       ArrayList<VaroPlayer> finished = new ArrayList<>();
/*  94 */       for (VaroPlayer vp : VaroPlayer.getOnlinePlayer()) {
/*  95 */         if (finished.contains(vp) || vp.getStats().isSpectator() || vp.getTeam() != null) {
/*     */           continue;
/*     */         }
/*  98 */         ArrayList<VaroPlayer> teamMember = new ArrayList<>();
/*  99 */         teamMember.add(vp);
/* 100 */         finished.add(vp);
/*     */         
/* 102 */         int missingMember = teamSize - 1;
/* 103 */         for (VaroPlayer othervp : VaroPlayer.getOnlinePlayer()) {
/* 104 */           if (missingMember == 0) {
/*     */             break;
/*     */           }
/* 107 */           if (finished.contains(othervp) || othervp.getStats().isSpectator() || othervp.getTeam() != null) {
/*     */             continue;
/*     */           }
/* 110 */           teamMember.add(othervp);
/* 111 */           finished.add(othervp);
/* 112 */           missingMember--;
/*     */         } 
/*     */         
/* 115 */         if (teamMember.size() != teamSize) {
/* 116 */           vp.getPlayer().sendMessage(String.valueOf(Main.getPrefix()) + "§7Fuer dich wurden nicht genug" + Main.getColorCode() + " Teampartner §7gefunden!");
/*     */         }
/* 118 */         String teamName = "";
/* 119 */         for (VaroPlayer teamPl : teamMember) {
/* 120 */           teamName = String.valueOf(teamName) + teamPl.getName().substring(0, teamPl.getName().length() / teamSize);
/*     */         }
/* 122 */         VaroTeam team = new VaroTeam(teamName);
/* 123 */         for (VaroPlayer teamPl : teamMember)
/* 124 */           team.addMember(teamPl); 
/*     */       } 
/* 126 */     } else if (teamSize == 1) {
/* 127 */       for (VaroPlayer pl : VaroPlayer.getOnlinePlayer()) {
/* 128 */         if (pl.getTeam() != null || pl.getStats().isSpectator()) {
/*     */           continue;
/*     */         }
/* 131 */         (new VaroTeam((pl.getName().length() == 16) ? pl.getName().substring(0, 15) : pl.getName())).addMember(pl);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\var\\utils\varo\VaroUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */