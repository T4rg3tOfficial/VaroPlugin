/*    */ package de.cuuky.varo.utils;
/*    */ 
/*    */ import de.cuuky.varo.version.BukkitVersion;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.block.Block;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BlockUtils
/*    */ {
/*    */   private static boolean isGrass(Material type) {
/* 17 */     if (!type.toString().contains("GRASS")) {
/* 18 */       return false;
/*    */     }
/* 20 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_11)) {
/* 21 */       return !type.toString().equals("GRASS");
/*    */     }
/* 23 */     return !type.toString().contains("BLOCK");
/*    */   }
/*    */   
/*    */   public static boolean isAir(Block block) {
/* 27 */     Material type = block.getType();
/*    */     
/* 29 */     return !(!isGrass(type) && !type.toString().endsWith("AIR") && Materials.POPPY.parseMaterial() != type && type != Materials.SUNFLOWER.parseMaterial() && type != Materials.LILY_PAD.parseMaterial() && !type.name().contains("LEAVES") && !type.name().contains("WOOD") && type != Materials.SNOW.parseMaterial() && !type.name().contains("GLASS") && type != Materials.VINE.parseMaterial());
/*    */   }
/*    */   
/*    */   public static boolean isSame(Materials mat, Block block) {
/* 33 */     if (mat.getData() == block.getData() && mat.parseMaterial().equals(block.getType())) {
/* 34 */       return true;
/*    */     }
/* 36 */     return false;
/*    */   }
/*    */   
/*    */   public static void setBlock(Block block, Materials mat) {
/* 40 */     block.setType(mat.parseMaterial());
/*    */     
/* 42 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_11))
/*    */       try {
/* 44 */         block.getClass().getDeclaredMethod("setData", new Class[] { byte.class }).invoke(block, new Object[] { Byte.valueOf((byte)mat.getData()) });
/* 45 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException e) {
/* 46 */         e.printStackTrace();
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\var\\utils\BlockUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */