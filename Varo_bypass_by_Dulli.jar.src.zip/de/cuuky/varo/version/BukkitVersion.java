/*    */ package de.cuuky.varo.version;
/*    */ 
/*    */ public enum BukkitVersion
/*    */ {
/*  5 */   ONE_10(10),
/*  6 */   ONE_11(11),
/*  7 */   ONE_12(12),
/*  8 */   ONE_13(13),
/*  9 */   ONE_14(14),
/* 10 */   ONE_15(15),
/* 11 */   ONE_7(7),
/* 12 */   ONE_8(8),
/* 13 */   ONE_9(9);
/*    */   
/*    */   private int identifier;
/*    */   
/*    */   BukkitVersion(int identifier) {
/* 18 */     this.identifier = identifier;
/*    */   }
/*    */   
/*    */   public boolean isHigherThan(BukkitVersion ver) {
/* 22 */     return (this.identifier > ver.identifier);
/*    */   }
/*    */   
/*    */   public static BukkitVersion getVersion(String v) {
/* 26 */     int versionNumber = Integer.valueOf(v.split("1_")[1].split("_")[0]).intValue(); byte b; int i; BukkitVersion[] arrayOfBukkitVersion;
/* 27 */     for (i = (arrayOfBukkitVersion = values()).length, b = 0; b < i; ) { BukkitVersion version = arrayOfBukkitVersion[b];
/* 28 */       if (versionNumber == version.identifier)
/* 29 */         return version;  b++; }
/*    */     
/* 31 */     if (versionNumber < (values()[1]).identifier)
/* 32 */       return values()[0]; 
/* 33 */     if (versionNumber > (values()[(values()).length - 2]).identifier) {
/* 34 */       return values()[(values()).length - 1];
/*    */     }
/* 36 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\version\BukkitVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */