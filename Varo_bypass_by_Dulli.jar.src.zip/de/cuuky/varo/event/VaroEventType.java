/*    */ package de.cuuky.varo.event;
/*    */ 
/*    */ public enum VaroEventType
/*    */ {
/*  5 */   EXPOSED("§cExposed"),
/*  6 */   MASS_RECORDING("§aMassRecording"),
/*  7 */   MOON_GRAVITY("§2MoonGravity"),
/*  8 */   POISON_RAIN("§4Poisened Rain"),
/*  9 */   POISON_WATER("§bPoisoned Water");
/*    */   private String name;
/*    */   
/*    */   VaroEventType(String name) {
/* 13 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 17 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\event\VaroEventType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */