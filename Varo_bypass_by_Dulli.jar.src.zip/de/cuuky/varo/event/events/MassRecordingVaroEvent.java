/*     */ package de.cuuky.varo.event.events;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*     */ import de.cuuky.varo.event.VaroEvent;
/*     */ import de.cuuky.varo.event.VaroEventType;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class MassRecordingVaroEvent
/*     */   extends VaroEvent
/*     */ {
/*     */   private ArrayList<Integer[]> countdowns;
/*     */   private int scheduler;
/*     */   private int timer;
/*     */   private boolean timerEnd = false;
/*     */   
/*     */   public MassRecordingVaroEvent() {
/*  25 */     super(VaroEventType.MASS_RECORDING, Material.DIAMOND_SWORD, (ConfigSetting.MASS_RECORDING_TIME.getValueAsInt() == 1) ? "Laesst alle Spieler fuer eine Minute zusaetzlich zu den normalen Folgen auf den Server" : ("Laesst alle Spieler fuer " + ConfigSetting.MASS_RECORDING_TIME.getValueAsInt() + " Minuten zusaetzlich zu den normalen Folgen auf den Server"));
/*     */     
/*  27 */     this.timerEnd = false;
/*  28 */     this.countdowns = (ArrayList)new ArrayList<>();
/*     */   }
/*     */   
/*     */   public int getCountdown(VaroPlayer vp) {
/*  32 */     for (Integer[] Countdown : this.countdowns) {
/*  33 */       if (vp.getId() == Countdown[0].intValue()) {
/*  34 */         return Countdown[1].intValue();
/*     */       }
/*     */     } 
/*  37 */     return 0;
/*     */   }
/*     */   
/*     */   public int getTimer() {
/*  41 */     return this.timer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  46 */     Bukkit.getScheduler().cancelTask(this.scheduler);
/*     */     
/*  48 */     for (Integer[] Speicher : this.countdowns) {
/*  49 */       VaroPlayer vp = VaroPlayer.getPlayer(Speicher[0].intValue());
/*  50 */       vp.getStats().setCountdown(Speicher[1].intValue());
/*  51 */       if (Speicher[1].intValue() == ConfigSetting.PLAY_TIME.getValueAsInt() * 60 && 
/*  52 */         vp.isOnline()) {
/*  53 */         vp.setMassRecordingKick(true);
/*     */         
/*  55 */         Bukkit.broadcastMessage(ConfigMessages.QUIT_KICK_BROADCAST.getValue(vp));
/*  56 */         vp.onEvent(BukkitEventType.KICKED);
/*  57 */         vp.getPlayer().kickPlayer(ConfigMessages.KICK_MASS_REC_SESSION_OVER.getValue(vp));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  62 */     if (!this.timerEnd) {
/*  63 */       for (VaroPlayer vp : VaroPlayer.getOnlinePlayer()) {
/*  64 */         vp.getNetworkManager().sendTitle("Ende", "Die Massenaufnahme wurde beendet.");
/*     */         
/*  66 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, "Die Massenaufnahme wurde vorzeitig beendet.");
/*     */       } 
/*     */     } else {
/*  69 */       for (VaroPlayer vp : VaroPlayer.getOnlinePlayer()) {
/*  70 */         vp.getNetworkManager().sendTitle("Ende", "Die Massenaufnahme ist zu Ende.");
/*     */         
/*  72 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, "Die Massenaufnahme ist zu Ende.");
/*     */       } 
/*     */     } 
/*     */     
/*  76 */     this.countdowns.clear();
/*  77 */     this.timerEnd = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  82 */     this.countdowns.clear();
/*  83 */     this.timerEnd = false;
/*     */     
/*  85 */     for (VaroPlayer vp : VaroPlayer.getVaroPlayer()) {
/*  86 */       Integer[] save = { Integer.valueOf(vp.getId()), Integer.valueOf(vp.getStats().getCountdown()) };
/*  87 */       this.countdowns.add(save);
/*  88 */       vp.getStats().setCountdown(vp.getStats().getCountdown() + 60 * ConfigSetting.MASS_RECORDING_TIME.getValueAsInt());
/*     */       
/*  90 */       vp.setalreadyHadMassProtectionTime(false);
/*     */     } 
/*     */     
/*  93 */     for (VaroPlayer vp : VaroPlayer.getOnlinePlayer()) {
/*  94 */       vp.setalreadyHadMassProtectionTime(true);
/*     */     }
/*     */     
/*  97 */     for (VaroPlayer vp : VaroPlayer.getOnlineAndAlivePlayer()) {
/*  98 */       vp.getStats().addSessionPlayed();
/*  99 */       Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.JOIN_LEAVE, String.valueOf(vp.getName()) + " ist auf dem Server und nimmt an der Massenaufnahme teil.");
/*     */     } 
/*     */     
/* 102 */     this.timer = ConfigSetting.MASS_RECORDING_TIME.getValueAsInt() * 60;
/*     */     
/* 104 */     Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, (ConfigSetting.MASS_RECORDING_TIME.getValueAsInt() == 1) ? "DIE MASSENAUFNAHME WURDE GESTARTET UND DAUERT EINE MINUTE!" : ("DIE MASSENAUFNAHME WURDE GESTARTET UND DAUERT " + ConfigSetting.MASS_RECORDING_TIME.getValueAsInt() + " MINUTEN!"));
/* 105 */     for (VaroPlayer vp : VaroPlayer.getOnlinePlayer()) {
/* 106 */       vp.getNetworkManager().sendTitle("Massenaufnahme", (ConfigSetting.MASS_RECORDING_TIME.getValueAsInt() == 1) ? "Alle koennen fuer eine Minute joinen." : ("Alle koennen fuer" + ConfigSetting.MASS_RECORDING_TIME.getValueAsInt() + " Minuten joinen."));
/*     */     }
/*     */     
/* 109 */     this.scheduler = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run() {
/* 112 */             if (MassRecordingVaroEvent.this.timer < 1) {
/* 113 */               MassRecordingVaroEvent.this.timerEnd = true;
/* 114 */               MassRecordingVaroEvent.this.setEnabled(false);
/*     */             } 
/*     */             
/* 117 */             MassRecordingVaroEvent.this.timer = MassRecordingVaroEvent.this.timer - 1;
/*     */           }
/* 119 */         },  0L, 20L);
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\event\events\MassRecordingVaroEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */