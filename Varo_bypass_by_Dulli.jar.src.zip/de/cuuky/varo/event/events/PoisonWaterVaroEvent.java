/*    */ package de.cuuky.varo.event.events;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.event.VaroEvent;
/*    */ import de.cuuky.varo.event.VaroEventType;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class PoisonWaterVaroEvent
/*    */   extends VaroEvent {
/*    */   private int sched;
/*    */   
/*    */   public PoisonWaterVaroEvent() {
/* 17 */     super(VaroEventType.POISON_WATER, Material.WATER_BUCKET, "Bei Kontakt mit Wasser erhaelt man Schaden");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 23 */     Bukkit.getScheduler().cancelTask(this.sched);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 28 */     this.sched = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 32 */             for (Player p : VersionUtils.getOnlinePlayer()) {
/* 33 */               if (p.getLocation().getBlock().getType().toString().contains("WATER"))
/* 34 */                 p.damage(0.75D); 
/*    */             } 
/*    */           }
/* 37 */         },  1L, 20L);
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\event\events\PoisonWaterVaroEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */