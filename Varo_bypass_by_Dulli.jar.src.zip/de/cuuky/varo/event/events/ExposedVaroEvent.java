/*    */ package de.cuuky.varo.event.events;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.event.VaroEvent;
/*    */ import de.cuuky.varo.event.VaroEventType;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Color;
/*    */ import org.bukkit.FireworkEffect;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.EntityType;
/*    */ import org.bukkit.entity.Firework;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.meta.FireworkMeta;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ 
/*    */ public class ExposedVaroEvent
/*    */   extends VaroEvent {
/*    */   private int scheduler;
/*    */   private PotionEffectType type;
/*    */   
/*    */   public ExposedVaroEvent() {
/* 26 */     super(VaroEventType.EXPOSED, Material.REDSTONE, "Laesst die Spieler auffliegen!\n\n1.9+: Gibt allen 'GLOWING'-Effekt\n<1.9: Spawnt alle 10 Sekunden eine Rakete");
/*    */     
/* 28 */     this.type = PotionEffectType.getByName("GLOWING");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 33 */     if (this.type != null)
/* 34 */       for (Player pl : VersionUtils.getOnlinePlayer()) {
/* 35 */         pl.removePotionEffect(this.type);
/*    */       } 
/* 37 */     Bukkit.getScheduler().cancelTask(this.scheduler);
/* 38 */     super.onDisable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 43 */     this.scheduler = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 47 */             FireworkEffect effect = FireworkEffect.builder().withColor(new Color[] { Color.RED, Color.WHITE }, ).withFade(Color.PURPLE).with(FireworkEffect.Type.BURST).trail(false).flicker(true).build();
/*    */             
/* 49 */             for (VaroPlayer vpl : VaroPlayer.getOnlineAndAlivePlayer()) {
/* 50 */               Player pl = vpl.getPlayer();
/*    */               
/* 52 */               if (ExposedVaroEvent.this.type != null) {
/* 53 */                 pl.getPlayer().addPotionEffect(new PotionEffect(ExposedVaroEvent.this.type, 11, 1)); continue;
/*    */               } 
/* 55 */               Firework fw = (Firework)pl.getWorld().spawnEntity(pl.getLocation(), EntityType.FIREWORK);
/* 56 */               FireworkMeta meta = fw.getFireworkMeta();
/* 57 */               meta.addEffect(effect);
/* 58 */               meta.setPower(1);
/* 59 */               fw.setFireworkMeta(meta);
/*    */             
/*    */             }
/*    */           
/*    */           }
/* 64 */         }200L, 200L);
/* 65 */     super.onEnable();
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\event\events\ExposedVaroEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */