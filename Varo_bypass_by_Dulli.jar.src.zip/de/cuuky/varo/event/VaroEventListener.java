/*    */ package de.cuuky.varo.event;
/*    */ 
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerMoveEvent;
/*    */ 
/*    */ public class VaroEventListener
/*    */   implements Listener {
/*    */   @EventHandler
/*    */   public void onPlayerMove(PlayerMoveEvent event) {
/* 11 */     for (VaroEvent event1 : VaroEvent.getEnabledEvents())
/* 12 */       event1.onMove(event); 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\event\VaroEventListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */