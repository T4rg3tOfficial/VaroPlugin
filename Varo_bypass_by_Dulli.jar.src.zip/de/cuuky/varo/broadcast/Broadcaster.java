/*    */ package de.cuuky.varo.broadcast;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Random;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Broadcaster
/*    */ {
/*    */   private ArrayList<String> messages;
/*    */   
/*    */   public Broadcaster() {
/* 25 */     if (ConfigSetting.SUPPORT_PLUGIN_ADS.getValueAsBoolean()) {
/* 26 */       startPluginAd();
/*    */     }
/* 28 */     loadMessages();
/*    */     
/* 30 */     if (!ConfigSetting.BROADCAST_INTERVAL_IN_SECONDS.isIntActivated()) {
/*    */       return;
/*    */     }
/* 33 */     starteSchedule();
/*    */   }
/*    */   
/*    */   private void loadMessages() {
/* 37 */     this.messages = new ArrayList<>();
/*    */     
/* 39 */     File file = new File("plugins/Varo/config", "broadcasts.yml");
/* 40 */     YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
/*    */     
/* 42 */     if (!file.exists()) {
/* 43 */       ArrayList<String> sb = new ArrayList<>();
/* 44 */       sb.add("&7Testnachricht Nummer 1");
/* 45 */       sb.add("&7Du kannst hier unendlich viele Nachrichten einfuegen, die dann Random ausgewaehlt werden.");
/*    */       
/* 47 */       if (!cfg.contains("messages"))
/* 48 */         cfg.addDefault("messages", sb); 
/* 49 */       cfg.options().copyDefaults(true);
/*    */       
/*    */       try {
/* 52 */         cfg.save(file);
/* 53 */       } catch (IOException e) {
/* 54 */         e.printStackTrace();
/*    */       } 
/*    */     } 
/*    */     
/* 58 */     this.messages.addAll(cfg.getStringList("messages"));
/*    */   }
/*    */   
/*    */   private void starteSchedule() {
/* 62 */     int interval = ConfigSetting.BROADCAST_INTERVAL_IN_SECONDS.getValueAsInt() * 20;
/* 63 */     Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 67 */             int random = (new Random()).nextInt(Broadcaster.this.messages.size() - 1 - 0 + 1) + 0;
/* 68 */             Bukkit.broadcastMessage(ConfigMessages.getValue(Broadcaster.this.messages.get(random)));
/*    */           }
/* 70 */         },  interval, interval);
/*    */   }
/*    */   
/*    */   private void startPluginAd() {
/* 74 */     int delay = (ConfigSetting.PLAY_TIME.getValueAsInt() * 60 > 0) ? ((ConfigSetting.PLAY_TIME.getValueAsInt() * 60 - 30 > 0) ? ((ConfigSetting.PLAY_TIME.getValueAsInt() * 60 - 30) * 20) : 18000) : 18000;
/* 75 */     Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 79 */             if (VersionUtils.getOnlinePlayer().size() == 0)
/*    */               return;  byte b; int i;
/*    */             String[] arrayOfString;
/* 82 */             for (i = (arrayOfString = Broadcaster.getAdMessage()).length, b = 0; b < i; ) { String m = arrayOfString[b];
/* 83 */               Bukkit.broadcastMessage(m.replaceAll("&", "§"));
/*    */               b++; }
/* 85 */              } }delay, delay);
/*    */   }
/*    */   
/*    */   private static String[] getAdMessage() {
/* 89 */     String[] messages = { "", "", "" };
/* 90 */     messages[0] = "&7-----------------------------------------";
/* 91 */     messages[1] = "&7Du moechtest auch ein &5(OneDay)Varo's &7veranstalten? Link zum Plugin: https://discord.gg/CnDSVVx";
/* 92 */     messages[2] = "&7-----------------------------------------";
/* 93 */     return messages;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\broadcast\Broadcaster.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */