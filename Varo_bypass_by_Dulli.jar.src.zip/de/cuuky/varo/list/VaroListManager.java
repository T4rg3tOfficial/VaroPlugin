/*    */ package de.cuuky.varo.list;
/*    */ 
/*    */ import de.cuuky.varo.list.enchantment.lists.BlockedEnchantments;
/*    */ import de.cuuky.varo.list.item.lists.BlockedItems;
/*    */ import de.cuuky.varo.list.item.lists.BlockedRecipes;
/*    */ import de.cuuky.varo.list.item.lists.ChestItems;
/*    */ import de.cuuky.varo.list.item.lists.DeathItems;
/*    */ import de.cuuky.varo.list.item.lists.LogDestroyedBlocks;
/*    */ import de.cuuky.varo.list.item.lists.StartItems;
/*    */ 
/*    */ public class VaroListManager
/*    */ {
/*    */   private BlockedEnchantments blockedEnchantments;
/*    */   private BlockedItems blockedItems;
/*    */   private BlockedRecipes blockedRecipes;
/*    */   private ChestItems chestItems;
/*    */   private DeathItems deathItems;
/*    */   private LogDestroyedBlocks destroyedBlocks;
/*    */   private StartItems startItems;
/*    */   
/*    */   public VaroListManager() {
/* 22 */     this.blockedEnchantments = new BlockedEnchantments();
/* 23 */     this.blockedItems = new BlockedItems();
/* 24 */     this.blockedRecipes = new BlockedRecipes();
/* 25 */     this.chestItems = new ChestItems();
/* 26 */     this.destroyedBlocks = new LogDestroyedBlocks();
/* 27 */     this.startItems = new StartItems();
/* 28 */     this.deathItems = new DeathItems();
/*    */     
/* 30 */     VaroList.saveLists();
/*    */   }
/*    */   
/*    */   public BlockedEnchantments getBlockedEnchantments() {
/* 34 */     return this.blockedEnchantments;
/*    */   }
/*    */   
/*    */   public BlockedItems getBlockedItems() {
/* 38 */     return this.blockedItems;
/*    */   }
/*    */   
/*    */   public BlockedRecipes getBlockedRecipes() {
/* 42 */     return this.blockedRecipes;
/*    */   }
/*    */   
/*    */   public ChestItems getChestItems() {
/* 46 */     return this.chestItems;
/*    */   }
/*    */   
/*    */   public DeathItems getDeathItems() {
/* 50 */     return this.deathItems;
/*    */   }
/*    */   
/*    */   public LogDestroyedBlocks getDestroyedBlocks() {
/* 54 */     return this.destroyedBlocks;
/*    */   }
/*    */   
/*    */   public StartItems getStartItems() {
/* 58 */     return this.startItems;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\list\VaroListManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */