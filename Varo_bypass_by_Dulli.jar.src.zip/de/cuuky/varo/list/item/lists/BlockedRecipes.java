/*    */ package de.cuuky.varo.list.item.lists;
/*    */ 
/*    */ import de.cuuky.varo.list.item.ItemList;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class BlockedRecipes
/*    */   extends ItemList
/*    */ {
/*    */   public BlockedRecipes() {
/* 11 */     super("BlockedRecipes");
/*    */     
/* 13 */     if (!this.items.isEmpty()) {
/*    */       return;
/*    */     }
/* 16 */     this.items.add(new ItemStack(Material.AIR));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBlocked(ItemStack itemstack) {
/* 21 */     itemstack = fixItem(itemstack);
/* 22 */     for (ItemStack stack : this.items) {
/* 23 */       if (stack.equals(itemstack))
/* 24 */         return true; 
/*    */     } 
/* 26 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\list\item\lists\BlockedRecipes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */