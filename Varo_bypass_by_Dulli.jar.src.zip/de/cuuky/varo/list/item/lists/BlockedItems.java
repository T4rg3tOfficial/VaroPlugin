/*    */ package de.cuuky.varo.list.item.lists;
/*    */ 
/*    */ import de.cuuky.varo.list.item.ItemList;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class BlockedItems
/*    */   extends ItemList
/*    */ {
/*    */   public BlockedItems() {
/* 12 */     super("BlockedItems");
/*    */     
/* 14 */     if (!this.items.isEmpty()) {
/*    */       return;
/*    */     }
/* 17 */     this.items.add(Materials.AIR.parseItem());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBlocked(ItemStack itemstack) {
/* 22 */     itemstack = fixItem(itemstack);
/* 23 */     for (ItemStack stack : this.items) {
/* 24 */       if (stack.equals(itemstack))
/* 25 */         return true; 
/*    */     } 
/* 27 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\list\item\lists\BlockedItems.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */