/*    */ package de.cuuky.varo.list;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ 
/*    */ public abstract class VaroList
/*    */ {
/*    */   private static YamlConfiguration config;
/*    */   private static File file;
/*    */   private static ArrayList<VaroList> lists;
/*    */   private String location;
/*    */   
/*    */   static {
/* 17 */     reloadConfig();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public VaroList(String location) {
/* 23 */     this.location = location;
/* 24 */     config.options().copyDefaults(true);
/*    */     
/* 26 */     List<?> loadList = config.getList(location);
/* 27 */     if (loadList == null) {
/* 28 */       loadList = new ArrayList();
/*    */     }
/* 30 */     onLoad(loadList);
/*    */     
/* 32 */     lists.add(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract ArrayList<?> getAsList();
/*    */   
/*    */   public String getLocation() {
/* 39 */     return this.location;
/*    */   }
/*    */   public abstract void onLoad(List<?> paramList);
/*    */   public void saveList() {
/* 43 */     config.set(this.location, null);
/* 44 */     config.set(this.location, getAsList());
/*    */     
/*    */     try {
/* 47 */       config.save(file);
/* 48 */     } catch (IOException iOException) {}
/*    */   }
/*    */   
/*    */   private static void reloadConfig() {
/* 52 */     file = new File("plugins/Varo/config", "lists.yml");
/* 53 */     config = YamlConfiguration.loadConfiguration(file);
/* 54 */     lists = new ArrayList<>();
/*    */   }
/*    */   
/*    */   public static ArrayList<VaroList> getLists() {
/* 58 */     return lists;
/*    */   }
/*    */   
/*    */   public static void reloadLists() {
/* 62 */     saveLists();
/* 63 */     reloadConfig();
/*    */     
/* 65 */     for (VaroList list : lists)
/* 66 */       list.onLoad(config.getStringList(list.getLocation())); 
/*    */   }
/*    */   
/*    */   public static void saveLists() {
/* 70 */     for (VaroList list : lists) {
/* 71 */       config.set(list.getLocation(), null);
/* 72 */       config.set(list.getLocation(), list.getAsList());
/*    */     } 
/*    */     
/*    */     try {
/* 76 */       config.save(file);
/* 77 */     } catch (IOException e) {
/* 78 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\list\VaroList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */