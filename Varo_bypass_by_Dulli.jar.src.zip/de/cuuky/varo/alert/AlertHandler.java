/*    */ package de.cuuky.varo.alert;
/*    */ 
/*    */ import de.cuuky.varo.serialize.VaroSerializeObject;
/*    */ 
/*    */ public class AlertHandler extends VaroSerializeObject {
/*    */   static {
/*  7 */     VaroSerializeObject.registerEnum(AlertType.class);
/*    */   }
/*    */   
/*    */   public AlertHandler() {
/* 11 */     super(Alert.class, "/stats/alerts.yml");
/*    */     
/* 13 */     load();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onSave() {
/* 18 */     clearOld();
/*    */     
/* 20 */     for (Alert alert : Alert.getAlerts()) {
/* 21 */       save(String.valueOf(alert.getId()), alert, getConfiguration());
/*    */     }
/* 23 */     saveFile();
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\alert\AlertHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */