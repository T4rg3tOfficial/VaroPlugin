/*    */ package de.cuuky.varo.alert;
/*    */ 
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ 
/*    */ public enum AlertType
/*    */   implements VaroSerializeable {
/*  8 */   BLOODLUST(
/*  9 */     "BLOODLUST"),
/*    */   
/* 11 */   COMBATLOG(
/* 12 */     "COMBATLOG"),
/*    */   
/* 14 */   DISCONNECT(
/* 15 */     "DISCONNECT"),
/*    */   
/* 17 */   INVENTORY_CLEAR(
/* 18 */     "INVENTORY_CLEAR"),
/*    */   
/* 20 */   NAME_SWITCH(
/* 21 */     "NAME_SWITCH"),
/*    */   
/* 23 */   NO_JOIN(
/* 24 */     "NO_JOIN"),
/*    */   
/* 26 */   NO_YOUTUBE_UPLOAD(
/* 27 */     "NO_YOUTUBE_UPLOAD"),
/*    */   
/* 29 */   STRIKE(
/* 30 */     "STRIKE"),
/*    */   
/* 32 */   UPDATE_AVAILABLE(
/* 33 */     "UPDATE_AVAILABLE");
/*    */   
/*    */   private String name;
/*    */   
/*    */   AlertType(String name) {
/* 38 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 42 */     return this.name;
/*    */   }
/*    */   
/*    */   public void onDeserializeEnd() {}
/*    */   
/*    */   public void onSerializeStart() {}
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\alert\AlertType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */