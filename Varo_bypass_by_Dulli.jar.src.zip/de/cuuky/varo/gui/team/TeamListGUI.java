/*     */ package de.cuuky.varo.gui.team;
/*     */ 
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.team.VaroTeam;
/*     */ import de.cuuky.varo.gui.SuperInventory;
/*     */ import de.cuuky.varo.gui.utils.PageAction;
/*     */ import de.cuuky.varo.item.ItemBuilder;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ 
/*     */ public class TeamListGUI extends SuperInventory {
/*     */   private TeamGUIType type;
/*     */   
/*     */   public enum TeamGUIType {
/*  19 */     ALIVE("§aALIVE", Material.POTION),
/*  20 */     DEAD("§4DEAD", Materials.REDSTONE.parseMaterial()),
/*  21 */     ONLINE("§eONLINE", Material.EMERALD),
/*  22 */     REGISTERED("§bREGISTERED", Material.BOOK);
/*     */     
/*     */     private Material icon;
/*     */     private String typeName;
/*     */     
/*     */     TeamGUIType(String typeName, Material icon) {
/*  28 */       this.typeName = typeName;
/*  29 */       this.icon = icon;
/*     */     }
/*     */     
/*     */     public Material getIcon() {
/*  33 */       return this.icon;
/*     */     }
/*     */     
/*     */     public ArrayList<VaroTeam> getList() {
/*  37 */       switch (this) {
/*     */         case DEAD:
/*  39 */           return VaroTeam.getDeadTeams();
/*     */         case REGISTERED:
/*  41 */           return VaroTeam.getTeams();
/*     */         case null:
/*  43 */           return VaroTeam.getAliveTeams();
/*     */         case ONLINE:
/*  45 */           return VaroTeam.getOnlineTeams();
/*     */       } 
/*     */       
/*  48 */       return null;
/*     */     }
/*     */     
/*     */     public String getTypeName() {
/*  52 */       return this.typeName;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TeamListGUI(Player opener, TeamGUIType type) {
/*  59 */     super("§7Choose Team", opener, 45, false);
/*     */     
/*  61 */     this.type = type;
/*  62 */     open();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBackClick() {
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClick(InventoryClickEvent event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClose(InventoryCloseEvent event) {}
/*     */ 
/*     */   
/*     */   public void onInventoryAction(PageAction action) {}
/*     */ 
/*     */   
/*     */   public boolean onOpen() {
/*  84 */     ArrayList<VaroTeam> list = this.type.getList();
/*     */     
/*  86 */     int start = getSize() * (getPage() - 1);
/*  87 */     for (int i = 0; i != getSize(); i++) {
/*     */       final VaroTeam team;
/*     */       try {
/*  90 */         team = list.get(start);
/*  91 */       } catch (IndexOutOfBoundsException e) {
/*     */         break;
/*     */       } 
/*     */       
/*  95 */       linkItemTo(i, (new ItemBuilder()).displayname(team.getDisplay()).playername(((VaroPlayer)team.getMember().get(0)).getName()).buildSkull(), new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/*  99 */               if (!TeamListGUI.this.opener.hasPermission("varo.admin")) {
/*     */                 return;
/*     */               }
/*     */             }
/*     */           });
/*     */ 
/*     */       
/* 106 */       start++;
/*     */     } 
/*     */     
/* 109 */     return (calculatePages(list.size(), getSize()) == this.page);
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\team\TeamListGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */