/*    */ package de.cuuky.varo.gui.team;
/*    */ 
/*    */ import de.cuuky.varo.entity.team.VaroTeam;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class TeamGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private VaroTeam team;
/*    */   
/*    */   public TeamGUI(Player opener, VaroTeam team) {
/* 19 */     super("§7Team §2" + team.getId(), opener, 9, false);
/*    */     
/* 21 */     this.team = team;
/* 22 */     open();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 27 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 41 */     linkItemTo(1, (new ItemBuilder()).displayname("§cRemove").itemstack(new ItemStack(Material.BUCKET)).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 45 */             TeamGUI.this.team.delete();
/*    */           }
/*    */         });
/* 48 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\team\TeamGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */