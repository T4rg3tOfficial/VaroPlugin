/*    */ package de.cuuky.varo.gui.youtube;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.stats.stat.YouTubeVideo;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ 
/*    */ 
/*    */ public class YouTubeVideoListGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public YouTubeVideoListGUI(Player opener) {
/* 18 */     super("§5Videos", opener, 45, false);
/*    */     
/* 20 */     open();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 25 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 39 */     ArrayList<YouTubeVideo> list = YouTubeVideo.getVideos();
/*    */     
/* 41 */     int start = getSize() * (getPage() - 1);
/* 42 */     for (int i = 0; i != getSize(); i++) {
/*    */       final YouTubeVideo video;
/*    */       try {
/* 45 */         video = list.get(start);
/* 46 */       } catch (IndexOutOfBoundsException e) {
/*    */         break;
/*    */       } 
/*    */ 
/*    */ 
/*    */       
/* 52 */       linkItemTo(i, (new ItemBuilder()).displayname("§5" + video.getTitle()).lore(new String[] { "§7Detected at: " + (new SimpleDateFormat("dd.MMM.yyyy HH:mm")).format(video.getDetectedAt()), "§7User: " + ((video.getOwner() != null) ? video.getOwner().getName() : "/"), "§7" + video.getDuration(), "§7Link: " + video.getLink() }, ).playername((video.getOwner() != null) ? video.getOwner().getName() : "UNKNOWN").build(), new Runnable()
/*    */           {
/*    */             public void run()
/*    */             {
/* 56 */               if (!YouTubeVideoListGUI.this.opener.hasPermission("varo.player")) {
/* 57 */                 YouTubeVideoListGUI.this.opener.sendMessage("§7Video: " + video.getLink());
/*    */                 
/*    */                 return;
/*    */               } 
/*    */             }
/*    */           });
/*    */       
/* 64 */       start++;
/*    */     } 
/* 66 */     return (calculatePages(YouTubeVideo.getVideos().size(), getSize()) == getPage());
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\youtube\YouTubeVideoListGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */