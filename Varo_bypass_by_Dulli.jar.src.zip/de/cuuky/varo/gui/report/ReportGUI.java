/*    */ package de.cuuky.varo.gui.report;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.report.ReportReason;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReportGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private VaroPlayer reported;
/*    */   private VaroPlayer reporter;
/*    */   
/*    */   public ReportGUI(Player opener, VaroPlayer reported) {
/* 24 */     super("§cReport", opener, 9, false);
/*    */     
/* 26 */     this.reporter = VaroPlayer.getPlayer(opener);
/* 27 */     this.reported = reported;
/*    */     
/* 29 */     open();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 34 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {
/* 39 */     close(true);
/*    */     
/* 41 */     String reportName = event.getCurrentItem().getItemMeta().getDisplayName().replace("§7", "");
/* 42 */     ReportReason reason = ReportReason.getByName(reportName);
/*    */     
/* 44 */     this.reporter.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + this.reported.getName() + " §7wurde erfolgreich reportet!");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 55 */     int i = -1; byte b; int j; ReportReason[] arrayOfReportReason;
/* 56 */     for (j = (arrayOfReportReason = ReportReason.values()).length, b = 0; b < j; ) { ReportReason reasons = arrayOfReportReason[b];
/* 57 */       i++;
/* 58 */       ArrayList<String> lore = new ArrayList<>(); byte b1; int k; String[] arrayOfString;
/* 59 */       for (k = (arrayOfString = reasons.getDescription().split("\n")).length, b1 = 0; b1 < k; ) { String strin = arrayOfString[b1];
/* 60 */         lore.add("§c" + strin); b1++; }
/*    */       
/* 62 */       getInventory().setItem(i, (new ItemBuilder()).displayname("§7" + reasons.getName()).itemstack(new ItemStack(reasons.getMaterial())).lore(lore).build());
/*    */       b++; }
/*    */     
/* 65 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\report\ReportGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */