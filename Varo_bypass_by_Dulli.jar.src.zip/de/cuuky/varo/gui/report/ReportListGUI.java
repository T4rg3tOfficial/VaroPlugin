/*    */ package de.cuuky.varo.gui.report;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.report.Report;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReportListGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public ReportListGUI(Player player) {
/* 22 */     super("§cReport List", player, 27, false);
/* 23 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void update() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 33 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {
/* 38 */     List<String> lore = event.getCurrentItem().getItemMeta().getLore();
/* 39 */     int id = Integer.parseInt(((String)lore.get(0)).replace("§c", ""));
/* 40 */     Report report = Report.getReport(id);
/* 41 */     close(true);
/*    */     
/* 43 */     if (report == null) {
/* 44 */       update();
/*    */       
/*    */       return;
/*    */     } 
/* 48 */     VaroPlayer vp = VaroPlayer.getPlayer(getOpener());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 61 */     int start = getSize() * (getPage() - 1);
/* 62 */     for (int i = 0; i < getSize(); i++) {
/*    */       Report reports;
/*    */       try {
/* 65 */         reports = Report.getReports().get(start);
/* 66 */       } catch (IndexOutOfBoundsException e) {
/*    */         break;
/*    */       } 
/*    */       
/* 70 */       ArrayList<String> lore = new ArrayList<>();
/* 71 */       lore.add("§c" + reports.getId());
/*    */       
/* 73 */       getInventory().setItem(i, (new ItemBuilder()).displayname("§7" + reports.getReported().getName()).itemstack(new ItemStack(Material.PAPER)).lore(lore).build());
/* 74 */       start++;
/*    */     } 
/*    */     
/* 77 */     return (calculatePages(Report.getReports().size(), getSize()) == this.page);
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\report\ReportListGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */