/*    */ package de.cuuky.varo.gui.report;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.report.Report;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class ReportPickGUI
/*    */   extends SuperInventory {
/*    */   private Report report;
/*    */   private VaroPlayer varoPlayer;
/*    */   
/*    */   public ReportPickGUI(VaroPlayer opener, Report report) {
/* 22 */     super("§cReport " + report.getId(), opener.getPlayer(), 9, false);
/*    */     
/* 24 */     this.report = report;
/* 25 */     this.varoPlayer = opener;
/*    */     
/* 27 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 33 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 47 */     linkItemTo(0, (new ItemBuilder()).displayname("§5Teleport").itemstack(new ItemStack(Material.ENDER_PEARL)).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 51 */             if (ReportPickGUI.this.report.getReported().isOnline()) {
/* 52 */               ReportPickGUI.this.varoPlayer.getPlayer().teleport((Entity)ReportPickGUI.this.report.getReported().getPlayer());
/* 53 */               ReportPickGUI.this.varoPlayer.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du wurdest zum reporteten Spieler teleportiert!");
/*    */               
/*    */               return;
/*    */             } 
/* 57 */             ReportPickGUI.this.varoPlayer.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der reportete Spieler ist nicht mehr online!");
/*    */           }
/*    */         });
/*    */     
/* 61 */     linkItemTo(8, (new ItemBuilder()).displayname("§cClose").itemstack(Materials.REDSTONE.parseItem()).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 65 */             ReportPickGUI.this.varoPlayer.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du hast den Report §c" + ReportPickGUI.this.report.getId() + " §7geschlossen");
/* 66 */             ReportPickGUI.this.report.close();
/*    */           }
/*    */         });
/*    */ 
/*    */     
/* 71 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\report\ReportPickGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */