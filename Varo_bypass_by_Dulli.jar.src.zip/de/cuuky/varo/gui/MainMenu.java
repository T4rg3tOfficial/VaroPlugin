/*     */ package de.cuuky.varo.gui;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.stat.YouTubeVideo;
/*     */ import de.cuuky.varo.entity.player.stats.stat.inventory.VaroSaveable;
/*     */ import de.cuuky.varo.entity.team.VaroTeam;
/*     */ import de.cuuky.varo.gui.utils.PageAction;
/*     */ import de.cuuky.varo.item.ItemBuilder;
/*     */ import de.cuuky.varo.utils.varo.LocationFormat;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MainMenu
/*     */   extends SuperInventory
/*     */ {
/*     */   public MainMenu(Player opener) {
/*  30 */     super(Main.getProjectName(), opener, 36, true);
/*     */     
/*  32 */     open();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onBackClick() {
/*  37 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onClick(InventoryClickEvent event) {}
/*     */ 
/*     */   
/*     */   public void onClose(InventoryCloseEvent event) {}
/*     */ 
/*     */   
/*     */   public void onInventoryAction(PageAction action) {}
/*     */ 
/*     */   
/*     */   public boolean onOpen() {
/*  51 */     linkItemTo(4, (new ItemBuilder()).displayname("§5Events").itemstack(new ItemStack(Material.APPLE)).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  59 */     linkItemTo(10, (new ItemBuilder()).displayname("§bSpawn").itemstack(new ItemStack(Material.DIAMOND_BLOCK)).lore(new String[] { (new LocationFormat(this.opener.getWorld().getSpawnLocation())).format(String.valueOf(Main.getColorCode()) + "x§7, " + Main.getColorCode() + "y§7, " + Main.getColorCode() + "z") }, ).build(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  63 */             if (!MainMenu.this.opener.hasPermission("varo.teleportSpawn")) {
/*     */               return;
/*     */             }
/*  66 */             MainMenu.this.opener.teleport(MainMenu.this.opener.getWorld().getSpawnLocation());
/*     */           }
/*     */         });
/*     */     
/*  70 */     linkItemTo(16, (new ItemBuilder()).player(this.opener).amount(getFixedSize(VaroPlayer.getVaroPlayer().size())).displayname("§aSpieler").buildSkull(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     linkItemTo(18, (new ItemBuilder()).displayname("§6Strikes").itemstack(new ItemStack(Material.PAPER)).amount(getFixedSize(VaroPlayer.getPlayer(this.opener).getStats().getStrikes().size())).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     linkItemTo(22, (new ItemBuilder()).displayname("§eKisten/Öfen").itemstack(new ItemStack(Material.CHEST)).amount(getFixedSize(VaroSaveable.getSaveable(VaroPlayer.getPlayer(this.opener)).size())).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     linkItemTo(26, (new ItemBuilder()).displayname("§2Teams").itemstack(new ItemStack(Material.DIAMOND_HELMET)).amount(getFixedSize(VaroTeam.getTeams().size())).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     linkItemTo(34, (new ItemBuilder()).displayname("§5Videos").itemstack(new ItemStack(Material.COMPASS)).amount(getFixedSize(YouTubeVideo.getVideos().size())).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     if (this.opener.hasPermission("varo.admin")) {
/* 111 */       linkItemTo(36, (new ItemBuilder()).displayname("§cAdmin-Section").itemstack(new ItemStack(Materials.OAK_FENCE_GATE.parseMaterial())).build(), new Runnable()
/*     */           {
/*     */             public void run() {}
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     if (ConfigSetting.SUPPORT_PLUGIN_ADS.getValueAsBoolean()) {
/* 121 */       linkItemTo(this.inv.getSize() - 1, (new ItemBuilder()).displayname("§5Info").itemstack(new ItemStack(Materials.MAP.parseMaterial())).build(), new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/* 125 */               MainMenu.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "§l" + Main.getPluginName());
/* 126 */               MainMenu.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "§7Version: " + Main.getColorCode() + Main.getInstance().getDescription().getVersion());
/* 127 */               MainMenu.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "§7Discordserver: " + Main.getColorCode() + "https://discord.gg/CnDSVVx");
/* 128 */               MainMenu.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "§7All rights reserved!");
/*     */             }
/*     */           });
/*     */     }
/* 132 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\MainMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */