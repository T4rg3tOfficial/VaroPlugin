/*    */ package de.cuuky.varo.gui.saveable;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.VaroSaveable;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.utils.varo.LocationFormat;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerSaveableChooseGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private VaroPlayer target;
/*    */   
/*    */   public PlayerSaveableChooseGUI(Player opener, VaroPlayer target) {
/* 25 */     super("§eÖfen/Kisten", opener, 45, false);
/*    */     
/* 27 */     this.target = target;
/*    */     
/* 29 */     open();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 34 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 48 */     ArrayList<VaroSaveable> list = VaroSaveable.getSaveable(this.target);
/*    */     
/* 50 */     int start = getSize() * (getPage() - 1);
/* 51 */     for (int i = 0; i != getSize(); i++) {
/*    */       final VaroSaveable saveable;
/*    */       try {
/* 54 */         saveable = list.get(start);
/* 55 */       } catch (IndexOutOfBoundsException e) {
/*    */         break;
/*    */       } 
/*    */       
/* 59 */       linkItemTo(i, (new ItemBuilder()).displayname(String.valueOf(Main.getColorCode()) + String.valueOf(saveable.getId())).itemstack(new ItemStack((saveable.getType() == VaroSaveable.SaveableType.CHEST) ? Material.CHEST : Material.FURNACE)).lore("§7Location§8: " + (new LocationFormat(saveable.getBlock().getLocation())).format(String.valueOf(Main.getColorCode()) + "x§7, " + Main.getColorCode() + "y§7, " + Main.getColorCode() + "z§7 in " + Main.getColorCode() + "world")).build(), new Runnable()
/*    */           {
/*    */             public void run() {}
/*    */           });
/*    */ 
/*    */ 
/*    */       
/* 66 */       start++;
/*    */     } 
/*    */     
/* 69 */     return (calculatePages(list.size(), getSize()) == this.page);
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\saveable\PlayerSaveableChooseGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */