/*    */ package de.cuuky.varo.gui.saveable;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.VaroSaveable;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ 
/*    */ public class PlayerSaveableGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private VaroSaveable saveable;
/*    */   
/*    */   public PlayerSaveableGUI(Player opener, VaroSaveable saveable) {
/* 18 */     super("§7Saveable §e" + saveable.getId(), opener, 0, false);
/*    */     
/* 20 */     this.saveable = saveable;
/*    */     
/* 22 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 28 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 42 */     linkItemTo(1, (new ItemBuilder()).displayname("§cDelete").itemstack(Materials.REDSTONE.parseItem()).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 46 */             PlayerSaveableGUI.this.saveable.remove();
/* 47 */             PlayerSaveableGUI.this.back();
/*    */           }
/*    */         });
/* 50 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\saveable\PlayerSaveableGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */