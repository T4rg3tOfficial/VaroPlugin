/*    */ package de.cuuky.varo.gui.admin.alert;
/*    */ 
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AlertTypeChooseGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public AlertTypeChooseGUI(Player opener) {
/* 17 */     super("§eChoose Alert", opener, 9, false);
/*    */     
/* 19 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 25 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 39 */     int i = 2; byte b; int j; AlertChooseGUI.AlertGUIType[] arrayOfAlertGUIType;
/* 40 */     for (j = (arrayOfAlertGUIType = AlertChooseGUI.AlertGUIType.values()).length, b = 0; b < j; ) { final AlertChooseGUI.AlertGUIType type = arrayOfAlertGUIType[b];
/* 41 */       linkItemTo(i, (new ItemBuilder()).displayname(type.getTypeName()).itemstack(new ItemStack(type.getIcon())).amount(getFixedSize(type.getList().size())).build(), new Runnable()
/*    */           {
/*    */             public void run() {}
/*    */           });
/*    */ 
/*    */ 
/*    */       
/* 48 */       i += 2; b++; }
/*    */     
/* 50 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\admin\alert\AlertTypeChooseGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */