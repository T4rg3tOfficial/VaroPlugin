/*    */ package de.cuuky.varo.gui.admin.alert;
/*    */ 
/*    */ import de.cuuky.varo.alert.Alert;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class AlertOptionGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private Alert alert;
/*    */   private AlertChooseGUI.AlertGUIType type;
/*    */   
/*    */   public AlertOptionGUI(Player opener, Alert alert, AlertChooseGUI.AlertGUIType type) {
/* 22 */     super("§7Alert §c" + alert.getId(), opener, 9, false);
/*    */     
/* 24 */     this.type = type;
/* 25 */     this.alert = alert;
/* 26 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 32 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {
/* 37 */     updateInventory();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 48 */     linkItemTo(4, (new ItemBuilder()).displayname(this.alert.isOpen() ? "§cClose" : "§aOpen").itemstack(new ItemStack(this.alert.isOpen() ? Materials.REDSTONE.parseMaterial() : Material.EMERALD)).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 52 */             AlertOptionGUI.this.alert.switchOpenState();
/*    */           }
/*    */         });
/*    */     
/* 56 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\admin\alert\AlertOptionGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */