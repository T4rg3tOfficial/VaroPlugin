/*    */ package de.cuuky.varo.gui.admin.orelogger;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OreLoggerListGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public OreLoggerListGUI(Player opener) {
/* 23 */     super("§6OreLogger", opener, 45, false);
/*    */     
/* 25 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 31 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 45 */     ArrayList<String> list = Main.getDataManager().getVaroLoggerManager().getBlockLogger().getLogs();
/* 46 */     Collections.reverse(list);
/*    */     
/* 48 */     int start = getSize() * (getPage() - 1);
/* 49 */     for (int i = 0; i != getSize(); i++) {
/*    */       String str;
/*    */       try {
/* 52 */         str = list.get(start);
/* 53 */       } catch (IndexOutOfBoundsException e) {
/*    */         break;
/*    */       } 
/*    */       
/* 57 */       String name = str.split("\\] ")[1].split(" ")[0];
/* 58 */       ArrayList<String> lore = new ArrayList<>();
/*    */       
/* 60 */       String minedAt = str.split("at ")[1].replace("!", "");
/*    */       
/* 62 */       Material blocktype = Material.matchMaterial(str.split("mined ")[1].split(" ")[0]);
/* 63 */       final Location loc = new Location(Bukkit.getWorld(minedAt.split("\\'")[1]), Integer.valueOf(minedAt.split("x:")[1].split(" ")[0]).intValue(), Integer.valueOf(minedAt.split("y:")[1].split(" ")[0]).intValue(), Integer.valueOf(minedAt.split("z:")[1].split(" ")[0]).intValue());
/*    */       
/* 65 */       lore.add("Block Type: §c" + blocktype.name());
/* 66 */       lore.add("Mined at: §c" + minedAt);
/* 67 */       lore.add("Time mined: §c" + str.split("\\]")[0].split("\\[")[1]);
/* 68 */       lore.add("Mined by: " + Main.getColorCode() + name);
/* 69 */       lore.add(" ");
/* 70 */       lore.add("§cClick to teleport!");
/*    */       
/* 72 */       linkItemTo(i, (new ItemBuilder()).displayname(name).itemstack(new ItemStack(blocktype)).lore(lore).build(), new Runnable()
/*    */           {
/*    */             public void run()
/*    */             {
/* 76 */               OreLoggerListGUI.this.opener.teleport(loc);
/*    */             }
/*    */           });
/*    */       
/* 80 */       start++;
/*    */     } 
/*    */     
/* 83 */     return (calculatePages(list.size(), getSize()) == this.page);
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\admin\orelogger\OreLoggerListGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */