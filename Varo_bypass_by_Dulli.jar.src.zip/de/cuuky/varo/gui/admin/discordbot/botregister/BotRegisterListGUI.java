/*    */ package de.cuuky.varo.gui.admin.discordbot.botregister;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.bot.discord.register.BotRegister;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BotRegisterListGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public BotRegisterListGUI(Player opener) {
/* 19 */     super("§cBotVerify", opener, 45, false);
/*    */     
/* 21 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 27 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 41 */     ArrayList<BotRegister> list = BotRegister.getBotRegister();
/*    */     
/* 43 */     int start = getSize() * (getPage() - 1);
/* 44 */     for (int i = 0; i != getSize(); i++) {
/*    */       final BotRegister register;
/*    */       try {
/* 47 */         register = list.get(start);
/* 48 */       } catch (IndexOutOfBoundsException e) {
/*    */         break;
/*    */       } 
/*    */       
/* 52 */       linkItemTo(i, (new ItemBuilder()).playername(register.getPlayerName()).lore(new String[] { "§7Player Name: " + Main.getColorCode() + register.getUUID(), "§7Player Name: " + Main.getColorCode() + register.getPlayerName(), "§7Is Bypassing: " + Main.getColorCode() + register.isBypass(), "§7Discord User: " + Main.getColorCode() + register.getMember().getAsMention() }, ).amount(getFixedSize(list.size())).buildSkull(), new Runnable()
/*    */           {
/*    */             public void run() {}
/*    */           });
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 60 */       start++;
/*    */     } 
/*    */     
/* 63 */     return (calculatePages(list.size(), getSize()) == this.page);
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\admin\discordbot\botregister\BotRegisterListGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */