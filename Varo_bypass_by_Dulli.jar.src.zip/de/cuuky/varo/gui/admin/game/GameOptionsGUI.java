/*    */ package de.cuuky.varo.gui.admin.game;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.utils.varo.LocationFormat;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class GameOptionsGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public GameOptionsGUI(Player opener) {
/* 20 */     super("Game", opener, 9, false);
/*    */     
/* 22 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 28 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {
/* 33 */     updateInventory();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 44 */     linkItemTo(1, (new ItemBuilder()).displayname("§aChange GameState").itemstack(new ItemStack(Material.EMERALD)).lore(new String[] { "§7Current: §c" + Main.getVaroGame().getGameState().getName() }, ).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 48 */             switch (Main.getVaroGame().getGameState()) {
/*    */               case STARTED:
/* 50 */                 Main.getVaroGame().setGamestate(GameState.END);
/*    */                 break;
/*    */               case null:
/* 53 */                 Main.getVaroGame().setGamestate(GameState.LOBBY);
/*    */                 break;
/*    */               case LOBBY:
/* 56 */                 Main.getVaroGame().setGamestate(GameState.STARTED);
/*    */                 break;
/*    */             } 
/*    */           
/*    */           }
/*    */         });
/* 62 */     linkItemTo(7, (new ItemBuilder()).displayname("§bSet Lobby Location").itemstack(new ItemStack(Material.DIAMOND_BLOCK)).lore(new String[] { "§7Current: " + ((Main.getVaroGame().getLobby() != null) ? (new LocationFormat(Main.getVaroGame().getLobby())).format("x, y, z in world") : "§c-") }, ).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 66 */             Main.getVaroGame().setLobby(GameOptionsGUI.this.opener.getLocation());
/*    */           }
/*    */         });
/*    */     
/* 70 */     linkItemTo(4, (new ItemBuilder()).displayname("§2Set World Spawn").itemstack(new ItemStack(Material.BEACON)).lore(new String[] { "§7Current: " + ((this.opener.getWorld().getSpawnLocation() != null) ? (new LocationFormat(this.opener.getWorld().getSpawnLocation())).format("x, y, z in world") : "§c-") }, ).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 74 */             GameOptionsGUI.this.opener.getWorld().setSpawnLocation(GameOptionsGUI.this.opener.getLocation().getBlockX(), GameOptionsGUI.this.opener.getLocation().getBlockY(), GameOptionsGUI.this.opener.getLocation().getBlockZ());
/*    */           }
/*    */         });
/* 77 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\admin\game\GameOptionsGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */