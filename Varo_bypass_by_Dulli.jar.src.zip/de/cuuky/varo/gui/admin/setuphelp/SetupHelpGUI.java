/*    */ package de.cuuky.varo.gui.admin.setuphelp;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class SetupHelpGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public enum SetupCheckList
/*    */   {
/* 19 */     BORDER_SETUP("Border Setup", "Haben sie die Border entsprechend gesetzt?", (String)Material.STICK),
/* 20 */     CONFIG_SETUP("Config Setup", "Haben sie die Config augesetzt? (GUI)", (String)Materials.SIGN.parseMaterial()),
/* 21 */     DISCORD_SETUP("Discord Setup", "Haben sie den DiscordBot aufgesetzt?", (String)Material.ANVIL),
/* 22 */     LOBBY_SETUP("Lobby Setup", "Haben sie die Lobby gesetzt? (GUI) (/Lobby)", (String)Material.DIAMOND),
/* 23 */     PORTAL_SETUP("Portal Setup", "Haben sie das Portal gesetzt?", (String)Material.OBSIDIAN),
/* 24 */     SCOREBOARD_SETUP("Scoreboard Setup", "Haben sie das Scoreboard aufgesetzt?", (String)Material.REDSTONE),
/* 25 */     SPAWN_SETUP("Spawn Setup", "Haben sie die Spawns gesetzt? /varo spawns", (String)Materials.OAK_SLAB.parseMaterial()),
/* 26 */     TEAM_SETUP("Team Setup", "Haben sie alle Teams oder Spieler eingetragen? /varo team", (String)Material.DIAMOND_HELMET),
/* 27 */     WORLDSPAWN_SETUP("Worlspawn Setup", "Haben sie den Worldspawn in der Mitte\ngesetzt? /setworldspawn", (String)Material.BEACON);
/*    */     
/*    */     private boolean checked;
/*    */     private String[] description;
/*    */     private Material icon;
/*    */     private String name;
/*    */     
/*    */     SetupCheckList(String name, String description, Material icon) {
/* 35 */       this.name = name;
/* 36 */       this.description = description.split("\n");
/* 37 */       this.icon = icon;
/* 38 */       this.checked = false;
/*    */     }
/*    */     
/*    */     public String[] getDescription() {
/* 42 */       return this.description;
/*    */     }
/*    */     
/*    */     public Material getIcon() {
/* 46 */       return this.icon;
/*    */     }
/*    */     
/*    */     public String getName() {
/* 50 */       return this.name;
/*    */     }
/*    */     
/*    */     public boolean isChecked() {
/* 54 */       return this.checked;
/*    */     }
/*    */     
/*    */     public void setChecked(boolean checked) {
/* 58 */       this.checked = checked;
/*    */     }
/*    */   }
/*    */   
/*    */   public SetupHelpGUI(Player opener) {
/* 63 */     super("§eSetup Assistant", opener, 9, false);
/*    */     
/* 65 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 71 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {
/* 76 */     updateInventory();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 87 */     for (int i = 0; i < (SetupCheckList.values()).length; i++) {
/* 88 */       final SetupCheckList check = SetupCheckList.values()[i];
/*    */       
/* 90 */       linkItemTo(i, (new ItemBuilder()).displayname(String.valueOf(Main.getColorCode()) + check.getName()).itemstack(new ItemStack(check.isChecked() ? Materials.GUNPOWDER.parseMaterial() : check.getIcon())).lore(check.getDescription()).build(), new Runnable()
/*    */           {
/*    */             public void run()
/*    */             {
/* 94 */               check.setChecked(!check.isChecked());
/*    */             }
/*    */           });
/*    */     } 
/*    */     
/* 99 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\admin\setuphelp\SetupHelpGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */