/*    */ package de.cuuky.varo.gui.admin.inventory;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.InventoryBackup;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ 
/*    */ public class InventoryBackupShowGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private InventoryBackup backup;
/*    */   
/*    */   public InventoryBackupShowGUI(Player opener, InventoryBackup backup) {
/* 16 */     super("§7Inventory: §c" + backup.getVaroPlayer().getName(), opener, 45, false);
/*    */     
/* 18 */     this.backup = backup;
/*    */     
/* 20 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 26 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */   
/*    */   public boolean onOpen() {
/*    */     int i;
/* 40 */     for (i = 0; i < (this.backup.getInventory().getInventory().getContents()).length; i++) {
/* 41 */       this.inv.setItem(i, this.backup.getInventory().getInventory().getContents()[i]);
/*    */     }
/* 43 */     for (i = 0; i < this.backup.getArmor().size(); i++)
/* 44 */       this.inv.setItem(41 + i, this.backup.getArmor().get(i)); 
/* 45 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\admin\inventory\InventoryBackupShowGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */