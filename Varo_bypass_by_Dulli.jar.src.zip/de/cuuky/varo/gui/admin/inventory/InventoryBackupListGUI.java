/*    */ package de.cuuky.varo.gui.admin.inventory;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.InventoryBackup;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InventoryBackupListGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private VaroPlayer target;
/*    */   
/*    */   public InventoryBackupListGUI(Player opener, VaroPlayer target) {
/* 25 */     super("§7Backups: §b" + target.getName(), opener, 45, false);
/*    */     
/* 27 */     this.target = target;
/*    */     
/* 29 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 35 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 49 */     ArrayList<InventoryBackup> backups = this.target.getStats().getInventoryBackups();
/*    */     
/* 51 */     int start = getSize() * (getPage() - 1);
/* 52 */     if (start != 0) {
/* 53 */       start -= 2;
/*    */     }
/* 55 */     for (int i = 0; i != getSize() - 2; i++) {
/*    */       final InventoryBackup backup;
/*    */       try {
/* 58 */         backup = backups.get(start);
/* 59 */       } catch (IndexOutOfBoundsException e) {
/*    */         break;
/*    */       } 
/*    */       
/* 63 */       linkItemTo(i, (new ItemBuilder()).displayname((new SimpleDateFormat("dd.MM.yyyy HH:mm:ss")).format(backup.getDate())).itemstack(new ItemStack(Material.BOOK)).build(), new Runnable()
/*    */           {
/*    */             public void run() {}
/*    */           });
/*    */ 
/*    */ 
/*    */       
/* 70 */       start++;
/*    */     } 
/*    */     
/* 73 */     linkItemTo(getSize() - 1, (new ItemBuilder()).displayname("§aCreate Backup").itemstack(new ItemStack(Material.EMERALD)).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 77 */             if (!InventoryBackupListGUI.this.target.isOnline()) {
/* 78 */               InventoryBackupListGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "Dieser Spieler ist nicht online!");
/*    */               
/*    */               return;
/*    */             } 
/* 82 */             InventoryBackupListGUI.this.target.getStats().addInventoryBackup(new InventoryBackup(InventoryBackupListGUI.this.target));
/* 83 */             InventoryBackupListGUI.this.updateInventory();
/*    */           }
/*    */         });
/*    */     
/* 87 */     return (calculatePages(backups.size(), getSize() - 2) == getPage());
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\admin\inventory\InventoryBackupListGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */