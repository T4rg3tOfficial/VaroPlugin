/*     */ package de.cuuky.varo.gui.player;
/*     */ 
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.gui.SuperInventory;
/*     */ import de.cuuky.varo.gui.utils.PageAction;
/*     */ import de.cuuky.varo.item.ItemBuilder;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ 
/*     */ public class PlayerListGUI extends SuperInventory {
/*     */   private boolean showStats;
/*     */   private PlayerGUIType type;
/*     */   
/*     */   public enum PlayerGUIType {
/*  19 */     ALIVE("§aALIVE", Material.POTION),
/*  20 */     DEAD("§4DEAD", Materials.SKELETON_SKULL_17.parseMaterial()),
/*  21 */     ONLINE("§eONLINE", Material.EMERALD),
/*  22 */     REGISTERED("§bREGISTERED", Material.BOOK),
/*  23 */     SPECTATOR("§fSPECTATOR", Materials.REDSTONE.parseMaterial());
/*     */     
/*     */     private Material icon;
/*     */     private String typeName;
/*     */     
/*     */     PlayerGUIType(String typeName, Material icon) {
/*  29 */       this.typeName = typeName;
/*  30 */       this.icon = icon;
/*     */     }
/*     */     
/*     */     public Material getIcon() {
/*  34 */       return this.icon;
/*     */     }
/*     */     
/*     */     public ArrayList<VaroPlayer> getList() {
/*  38 */       switch (this) {
/*     */         case SPECTATOR:
/*  40 */           return VaroPlayer.getSpectator();
/*     */         case DEAD:
/*  42 */           return VaroPlayer.getDeadPlayer();
/*     */         case REGISTERED:
/*  44 */           return VaroPlayer.getVaroPlayer();
/*     */         case null:
/*  46 */           return VaroPlayer.getAlivePlayer();
/*     */         case ONLINE:
/*  48 */           return VaroPlayer.getOnlinePlayer();
/*     */       } 
/*     */       
/*  51 */       return null;
/*     */     }
/*     */     
/*     */     public String getTypeName() {
/*  55 */       return this.typeName; } public static PlayerGUIType getType(String name) {
/*     */       byte b;
/*     */       int i;
/*     */       PlayerGUIType[] arrayOfPlayerGUIType;
/*  59 */       for (i = (arrayOfPlayerGUIType = values()).length, b = 0; b < i; ) { PlayerGUIType type = arrayOfPlayerGUIType[b];
/*  60 */         if (type.getTypeName().equals(name))
/*  61 */           return type;  b++; }
/*     */       
/*  63 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlayerListGUI(Player opener, boolean showstats, PlayerGUIType type) {
/*  72 */     super("§cPlayer", opener, 45, false);
/*     */     
/*  74 */     this.showStats = showstats;
/*  75 */     this.type = type;
/*  76 */     open();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBackClick() {
/*  82 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onClick(InventoryClickEvent event) {}
/*     */ 
/*     */   
/*     */   public void onClose(InventoryCloseEvent event) {}
/*     */ 
/*     */   
/*     */   public void onInventoryAction(PageAction action) {}
/*     */ 
/*     */   
/*     */   public boolean onOpen() {
/*  96 */     ArrayList<VaroPlayer> list = this.type.getList();
/*     */     
/*  98 */     int start = getSize() * (getPage() - 1);
/*  99 */     for (int i = 0; i != getSize(); i++) {
/*     */       final VaroPlayer players;
/*     */       try {
/* 102 */         players = list.get(start);
/* 103 */       } catch (IndexOutOfBoundsException e) {
/*     */         break;
/*     */       } 
/*     */       
/* 107 */       linkItemTo(i, (new ItemBuilder()).playername(players.getName()).lore(this.showStats ? players.getStats().getStatsListed() : new String[0]).buildSkull(), new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/* 111 */               if (!PlayerListGUI.this.opener.hasPermission("varo.player")) {
/*     */                 return;
/*     */               }
/*     */             }
/*     */           });
/*     */       
/* 117 */       start++;
/*     */     } 
/*     */     
/* 120 */     return (calculatePages(list.size(), getSize()) == this.page);
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\player\PlayerListGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */