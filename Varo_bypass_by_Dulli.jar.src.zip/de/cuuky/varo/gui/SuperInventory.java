/*     */ package de.cuuky.varo.gui;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.gui.utils.PageAction;
/*     */ import de.cuuky.varo.item.ItemBuilder;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SuperInventory
/*     */ {
/*     */   private static boolean fill_inventory;
/*     */   private static boolean animations;
/*     */   private static ItemStack forward;
/*     */   private static ItemStack backwards;
/*     */   protected String firstTitle;
/*     */   protected String title;
/*     */   private HashMap<ItemMeta, Runnable> itemlinks;
/*  35 */   private static ArrayList<SuperInventory> guis = new ArrayList<>();
/*     */   static {
/*  37 */     forward = (new ItemBuilder()).displayname("§aSeite vorwaerts").itemstack(new ItemStack(Material.ARROW)).build();
/*  38 */     backwards = (new ItemBuilder()).displayname("§cSeite rueckwaerts").itemstack(new ItemStack(Material.ARROW)).build();
/*     */     
/*  40 */     fill_inventory = ConfigSetting.GUI_FILL_INVENTORY.getValueAsBoolean();
/*  41 */     animations = ConfigSetting.GUI_INVENTORY_ANIMATIONS.getValueAsBoolean();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ArrayList<Integer> modifier;
/*     */   
/*     */   protected boolean hasMorePages;
/*     */   
/*     */   protected boolean isLastPage;
/*     */   protected boolean homePage;
/*     */   
/*     */   public SuperInventory(String title, Player opener, int size, boolean homePage) {
/*  53 */     this.firstTitle = title;
/*  54 */     this.opener = opener;
/*  55 */     this.page = 1;
/*  56 */     this.homePage = homePage;
/*  57 */     this.size = size;
/*  58 */     this.title = getPageUpdate();
/*  59 */     this.inv = Bukkit.createInventory(null, (size != 54) ? (size + 9) : size, getPageUpdate());
/*  60 */     this.itemlinks = new HashMap<>();
/*     */     
/*  62 */     this.modifier = new ArrayList<>(Arrays.asList(new Integer[] { Integer.valueOf(this.inv.getSize() - 1), Integer.valueOf(this.inv.getSize() - 9), Integer.valueOf(this.inv.getSize() - 5) }));
/*     */     
/*  64 */     SuperInventory inv = getInventory(opener);
/*  65 */     if (inv != null) {
/*  66 */       inv.close(true);
/*     */     }
/*  68 */     guis.add(this);
/*     */   }
/*     */   protected boolean ignoreNextClose; protected Inventory inv; protected Player opener; protected int page; protected int size;
/*     */   
/*     */   private void doAnimation() {
/*  73 */     if (!animations) {
/*     */       return;
/*     */     }
/*  76 */     final HashMap<Integer, ItemStack> itemlist = new HashMap<>(); int i;
/*  77 */     for (i = 0; i < this.inv.getSize() - 9; i++) {
/*  78 */       itemlist.put(Integer.valueOf(i), this.inv.getItem(i));
/*     */     }
/*  80 */     for (i = 0; i < this.inv.getSize() - 9; i++)
/*  81 */       this.inv.setItem(i, null); 
/*  82 */     this.opener.updateInventory();
/*     */     
/*  84 */     final int delay = 600 / getSize();
/*     */     
/*  86 */     Bukkit.getScheduler().scheduleAsyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  90 */             int middle = (int)Math.ceil((itemlist.size() / 2));
/*  91 */             for (int radius = 0; middle + radius != itemlist.size() && 
/*  92 */               SuperInventory.this.isOpen(); radius++) {
/*     */ 
/*     */               
/*     */               try {
/*  96 */                 Thread.sleep(delay);
/*  97 */               } catch (InterruptedException e) {
/*  98 */                 e.printStackTrace();
/*     */               } 
/*     */               
/* 101 */               SuperInventory.this.inv.setItem(middle + radius, (ItemStack)itemlist.get(Integer.valueOf(middle + radius)));
/* 102 */               SuperInventory.this.opener.updateInventory();
/*     */               
/*     */               try {
/* 105 */                 Thread.sleep(delay);
/* 106 */               } catch (InterruptedException e) {
/* 107 */                 e.printStackTrace();
/*     */               } 
/*     */               
/* 110 */               SuperInventory.this.inv.setItem(middle - radius, (ItemStack)itemlist.get(Integer.valueOf(middle - radius)));
/* 111 */               SuperInventory.this.opener.updateInventory();
/*     */             } 
/*     */             
/* 114 */             if ((SuperInventory.this.inv.getSize() - 9) % 2 == 0 && SuperInventory.this.isOpen()) {
/*     */               try {
/* 116 */                 Thread.sleep(delay);
/* 117 */               } catch (InterruptedException e) {
/* 118 */                 e.printStackTrace();
/*     */               } 
/* 120 */               SuperInventory.this.inv.setItem(0, (ItemStack)itemlist.get(Integer.valueOf(0)));
/* 121 */               SuperInventory.this.opener.updateInventory();
/*     */             } 
/*     */           }
/* 124 */         }0L);
/*     */   }
/*     */   
/*     */   private void fillSpace() {
/* 128 */     if (!fill_inventory) {
/*     */       return;
/*     */     }
/* 131 */     for (int i = 0; i < this.inv.getSize(); i++) {
/* 132 */       if (this.inv.getItem(i) == null) {
/* 133 */         this.inv.setItem(i, (new ItemBuilder()).displayname("§c").itemstack(new ItemStack(Materials.BLACK_STAINED_GLASS_PANE.parseMaterial(), 1, (short)15)).build());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String getBack() {
/* 140 */     if (!this.homePage) {
/* 141 */       return "§4Zurueck";
/*     */     }
/* 143 */     return "§4Schliessen";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPageUpdate() {
/* 150 */     String suff = this.hasMorePages ? (" §7" + this.page) : "";
/* 151 */     return String.valueOf(this.firstTitle) + ((this.firstTitle.length() + suff.length() > 32) ? "" : suff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setSwitcher() {
/* 158 */     this.inv.setItem(((Integer)this.modifier.get(2)).intValue(), (new ItemBuilder()).displayname(getBack()).itemstack(getBack().equals("§4Zurueck") ? new ItemStack(Materials.STONE_BUTTON.parseMaterial()) : Materials.REDSTONE.parseItem()).build());
/* 159 */     if (!this.hasMorePages) {
/*     */       return;
/*     */     }
/* 162 */     if (!this.isLastPage) {
/* 163 */       this.inv.setItem(((Integer)this.modifier.get(0)).intValue(), forward);
/*     */     }
/* 165 */     if (this.page != 1)
/* 166 */       this.inv.setItem(((Integer)this.modifier.get(1)).intValue(), backwards); 
/*     */   }
/*     */   
/*     */   protected void close(boolean unregister) {
/* 170 */     if (!unregister) {
/* 171 */       this.ignoreNextClose = true;
/*     */     } else {
/* 173 */       guis.remove(this);
/*     */     } 
/* 175 */     this.opener.closeInventory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void linkItemTo(int location, ItemStack stack, Runnable runnable) {
/* 182 */     this.inv.setItem(location, stack);
/* 183 */     this.itemlinks.put(stack.getItemMeta(), runnable);
/*     */   }
/*     */   
/*     */   public void back() {
/* 187 */     close(true);
/*     */     
/* 189 */     if (!onBackClick());
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 194 */     for (int i = 0; i < (this.inv.getContents()).length; i++) {
/* 195 */       if (!this.modifier.contains(Integer.valueOf(i)))
/*     */       {
/*     */         
/* 198 */         this.inv.setItem(i, new ItemStack(Material.AIR)); } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void closeInventory() {
/* 203 */     if (this.ignoreNextClose) {
/* 204 */       this.ignoreNextClose = false;
/*     */       
/*     */       return;
/*     */     } 
/* 208 */     guis.remove(this);
/* 209 */     this.opener.closeInventory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeLink(ItemStack item) {
/* 216 */     for (ItemMeta stack : this.itemlinks.keySet()) {
/* 217 */       if (stack.getDisplayName().equals(item.getItemMeta().getDisplayName())) {
/* 218 */         ((Runnable)this.itemlinks.get(stack)).run();
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public int getFixedSize(int size) {
/* 224 */     if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_8)) {
/* 225 */       return (size < 1) ? 1 : ((size > 64) ? 64 : size);
/*     */     }
/* 227 */     return size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {
/* 234 */     this.isLastPage = onOpen();
/* 235 */     if (!this.isLastPage) {
/* 236 */       this.hasMorePages = true;
/*     */     }
/* 238 */     setSwitcher();
/* 239 */     fillSpace();
/* 240 */     this.opener.openInventory(this.inv);
/* 241 */     doAnimation();
/*     */   }
/*     */   
/*     */   public void pageActionChanged(PageAction action) {
/* 245 */     onInventoryAction(action);
/*     */   }
/*     */   
/*     */   public void pageBackwards() {
/* 249 */     this.page--;
/* 250 */     updateInventory();
/*     */   }
/*     */   
/*     */   public void pageForwards() {
/* 254 */     this.page++;
/* 255 */     updateInventory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reopenSoon() {
/* 262 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 266 */             SuperInventory.this.updateInventory();
/*     */           }
/* 268 */         },  1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateInventory() {
/* 275 */     if (this.opener.getOpenInventory() != null) {
/* 276 */       this.ignoreNextClose = true;
/* 277 */       this.opener.closeInventory();
/*     */     } 
/*     */     
/* 280 */     this.title = getPageUpdate();
/* 281 */     Inventory newInv = Bukkit.createInventory(null, (this.size != 54) ? (this.size + 9) : this.size, this.title);
/*     */     
/* 283 */     this.itemlinks = new HashMap<>();
/* 284 */     this.inv = newInv;
/* 285 */     open();
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract boolean onBackClick();
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public abstract void onClick(InventoryClickEvent paramInventoryClickEvent);
/*     */ 
/*     */   
/*     */   public abstract void onClose(InventoryCloseEvent paramInventoryCloseEvent);
/*     */ 
/*     */   
/*     */   public abstract void onInventoryAction(PageAction paramPageAction);
/*     */ 
/*     */   
/*     */   public abstract boolean onOpen();
/*     */ 
/*     */   
/*     */   public Inventory getInventory() {
/* 306 */     return this.inv;
/*     */   }
/*     */   
/*     */   public Player getOpener() {
/* 310 */     return this.opener;
/*     */   }
/*     */   
/*     */   public int getPage() {
/* 314 */     return this.page;
/*     */   }
/*     */   
/*     */   public int getSize() {
/* 318 */     return this.size;
/*     */   }
/*     */   
/*     */   public String getTitle() {
/* 322 */     return this.title;
/*     */   }
/*     */   
/*     */   public boolean isHomePage() {
/* 326 */     return this.homePage;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 330 */     return guis.contains(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int calculatePages(int amount, int pageSize) {
/* 337 */     int res = (int)Math.ceil(amount / pageSize);
/* 338 */     if (res == 0)
/* 339 */       res = 1; 
/* 340 */     return res;
/*     */   }
/*     */   
/*     */   public static SuperInventory getInventory(Player player) {
/* 344 */     for (SuperInventory inventory : guis) {
/* 345 */       if (inventory.getOpener().equals(player))
/* 346 */         return inventory; 
/*     */     } 
/* 348 */     return null;
/*     */   }
/*     */   
/*     */   public static ArrayList<SuperInventory> getGUIS() {
/* 352 */     return guis;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\SuperInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */