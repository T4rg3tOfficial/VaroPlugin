/*    */ package de.cuuky.varo.gui.utils.chat;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChatHook
/*    */ {
/* 14 */   private static ArrayList<ChatHook> chathooks = new ArrayList<>();
/*    */   
/*    */   private ChatHookListener listener;
/*    */   
/*    */   private Player player;
/*    */   
/*    */   public ChatHook(Player player, String message, ChatHookListener chatHookListener) {
/* 21 */     this.player = player;
/* 22 */     this.listener = chatHookListener;
/*    */     
/* 24 */     if (getChatHook(player) != null) {
/* 25 */       getChatHook(player).remove();
/*    */     }
/* 27 */     player.sendMessage(String.valueOf(Main.getPrefix()) + message);
/*    */     
/* 29 */     chathooks.add(this);
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 33 */     return this.player;
/*    */   }
/*    */   
/*    */   public void remove() {
/* 37 */     chathooks.remove(this);
/*    */   }
/*    */   
/*    */   public void run(String input) {
/* 41 */     this.listener.onChat(input);
/*    */     
/* 43 */     remove();
/*    */   }
/*    */   
/*    */   public static ChatHook getChatHook(Player player) {
/* 47 */     for (ChatHook hook : chathooks) {
/* 48 */       if (hook.getPlayer().equals(player))
/* 49 */         return hook; 
/*    */     } 
/* 51 */     return null;
/*    */   }
/*    */   
/*    */   public static ArrayList<ChatHook> getChathooks() {
/* 55 */     return chathooks;
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gu\\utils\chat\ChatHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */