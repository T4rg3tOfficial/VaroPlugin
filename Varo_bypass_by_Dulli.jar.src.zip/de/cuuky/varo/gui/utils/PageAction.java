/*   */ package de.cuuky.varo.gui.utils;
/*   */ 
/*   */ public enum PageAction
/*   */ {
/* 5 */   PAGE_SWITCH_BACKWARDS,
/* 6 */   PAGE_SWITCH_FORWARDS;
/*   */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gu\\utils\PageAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */