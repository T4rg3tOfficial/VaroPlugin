/*    */ package de.cuuky.varo.gui.strike;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.stats.stat.Strike;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class StrikeListGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private Player target;
/*    */   
/*    */   public StrikeListGUI(Player opener, Player target) {
/* 23 */     super("Strikes", opener, 45, false);
/*    */     
/* 25 */     this.target = target;
/*    */     
/* 27 */     open();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 32 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 46 */     ArrayList<Strike> list = VaroPlayer.getPlayer(this.target).getStats().getStrikes();
/*    */     
/* 48 */     int start = getSize() * (getPage() - 1);
/* 49 */     for (int i = 0; i != getSize(); i++) {
/*    */       Strike strike;
/*    */       try {
/* 52 */         strike = list.get(start);
/* 53 */       } catch (IndexOutOfBoundsException e) {
/*    */         break;
/*    */       } 
/*    */       
/* 57 */       linkItemTo(i, (new ItemBuilder()).displayname("§c" + strike.getStrikeNumber()).itemstack(new ItemStack(Material.PAPER)).lore(new String[] { "§7Reason: §c" + strike.getReason(), "§7Striker: §c" + strike.getStriker(), "§7Date: §c" + (new SimpleDateFormat("dd.MM.yyyy HH:mm:ss")).format(strike.getAcquiredDate()) }, ).build(), new Runnable()
/*    */           {
/*    */             public void run()
/*    */             {
/* 61 */               if (!StrikeListGUI.this.opener.hasPermission("varo.admin")) {
/*    */                 return;
/*    */               }
/*    */             }
/*    */           });
/*    */       
/* 67 */       start++;
/*    */     } 
/*    */     
/* 70 */     return (calculatePages(list.size(), getSize()) == this.page);
/*    */   }
/*    */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\gui\strike\StrikeListGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */