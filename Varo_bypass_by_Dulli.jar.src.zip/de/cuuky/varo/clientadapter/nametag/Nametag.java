/*     */ package de.cuuky.varo.clientadapter.nametag;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.stat.Rank;
/*     */ import de.cuuky.varo.entity.team.VaroTeam;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.OfflinePlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scoreboard.Scoreboard;
/*     */ import org.bukkit.scoreboard.Team;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Nametag
/*     */ {
/*  31 */   private static ArrayList<Nametag> nametags = new ArrayList<>(); private static Class<?> teamClass; private static Object configVisibility; private static Method setVisibilityMethod;
/*     */   static {
/*  33 */     if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7))
/*     */       try {
/*  35 */         Class<?> visibilityClass = Class.forName("org.bukkit.scoreboard.NameTagVisibility");
/*     */         
/*  37 */         configVisibility = !ConfigSetting.NAMETAGS.getValueAsBoolean() ? visibilityClass.getDeclaredField("NEVER").get(null) : visibilityClass.getDeclaredField("ALWAYS").get(null);
/*  38 */         teamClass = Class.forName("org.bukkit.scoreboard.Team");
/*  39 */         setVisibilityMethod = teamClass.getDeclaredMethod("setNameTagVisibility", new Class[] { configVisibility.getClass() });
/*  40 */         getVisibilityMethod = teamClass.getDeclaredMethod("getNameTagVisibility", new Class[0]);
/*  41 */       } catch (Exception e) {
/*  42 */         e.printStackTrace();
/*     */       }  
/*     */   }
/*     */   private static Method getVisibilityMethod; private boolean init; private boolean hearts;
/*     */   private Player player;
/*     */   private String prefix;
/*     */   private String suffix;
/*     */   private String name;
/*     */   private Rank rank;
/*     */   private VaroTeam varoTeam;
/*     */   private UUID uniqueID;
/*     */   
/*     */   public Nametag(UUID uniqueID, Player p) {
/*  55 */     this.hearts = ConfigMessages.NAMETAG_SUFFIX.getValue().contains("%hearts%");
/*  56 */     this.player = p;
/*  57 */     this.uniqueID = uniqueID;
/*     */     
/*  59 */     for (Team t : p.getScoreboard().getTeams()) {
/*  60 */       if (!t.getName().startsWith("team-"))
/*  61 */         t.unregister(); 
/*     */     } 
/*  63 */     startDelayedRefresh();
/*     */     
/*  65 */     nametags.add(this);
/*     */   }
/*     */   
/*     */   private void startDelayedRefresh() {
/*  69 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  73 */             Nametag.this.init = true;
/*  74 */             Nametag.this.refresh();
/*     */           }
/*  76 */         },  1L);
/*     */   }
/*     */   
/*     */   private void refreshPrefix() {
/*  80 */     VaroPlayer varoPlayer = VaroPlayer.getPlayer(this.player);
/*     */     
/*  82 */     this.rank = varoPlayer.getRank();
/*  83 */     this.varoTeam = varoPlayer.getTeam();
/*  84 */     this.name = checkName();
/*     */     
/*  86 */     this.prefix = (this.varoTeam == null) ? ConfigMessages.NAMETAG_NORMAL.getValue(varoPlayer) : ConfigMessages.NAMETAG_TEAM_PREFIX.getValue(varoPlayer);
/*     */     
/*  88 */     if (this.prefix.length() > 16) {
/*  89 */       this.prefix = ConfigMessages.NAMETAG_NORMAL.getValue();
/*     */     }
/*  91 */     this.suffix = String.valueOf(ConfigMessages.NAMETAG_SUFFIX.getValue(varoPlayer).replace("%hearts%", String.valueOf(VersionUtils.getHearts(this.player))));
/*     */     
/*  93 */     if (this.suffix.length() > 16)
/*  94 */       this.suffix = ""; 
/*     */   }
/*     */   
/*     */   private String checkName() {
/*  98 */     String name = getPlayer().getName();
/*     */     
/* 100 */     int teamsize = VaroTeam.getHighestNumber() + 1;
/* 101 */     int ranks = Rank.getHighestLocation() + 1;
/*     */     
/* 103 */     if (this.varoTeam != null) {
/* 104 */       name = String.valueOf(this.varoTeam.getId()) + name;
/*     */     } else {
/* 106 */       name = String.valueOf(teamsize) + name;
/*     */     } 
/* 108 */     if (this.rank != null) {
/* 109 */       name = String.valueOf(this.rank.getTablistLocation()) + name;
/*     */     } else {
/* 111 */       name = String.valueOf(ranks) + name;
/*     */     } 
/* 113 */     if (name.length() > 16)
/* 114 */       name = name.substring(0, 16); 
/* 115 */     return name;
/*     */   }
/*     */   
/*     */   private Object getVisibility(Team team) {
/*     */     try {
/* 120 */       return getVisibilityMethod.invoke(team, new Object[0]);
/* 121 */     } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/* 122 */       e.printStackTrace();
/*     */ 
/*     */       
/* 125 */       return null;
/*     */     } 
/*     */   }
/*     */   private void setVisibility(Team team) {
/* 129 */     if (configVisibility == null || getVisibility(team).equals(configVisibility)) {
/*     */       return;
/*     */     }
/*     */     try {
/* 133 */       setVisibilityMethod.invoke(team, new Object[] { configVisibility });
/* 134 */     } catch (Exception e) {
/* 135 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateFor(Scoreboard board, Nametag nametag) {
/* 140 */     Team team = board.getTeam(nametag.getName());
/*     */     
/* 142 */     if (team == null) {
/* 143 */       team = board.registerNewTeam(nametag.getName());
/* 144 */       team.addPlayer((OfflinePlayer)nametag.getPlayer());
/*     */     } 
/*     */     
/* 147 */     if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/* 148 */       setVisibility(team);
/*     */     }
/* 150 */     if (nametag.getPrefix() != null) {
/* 151 */       if (team.getPrefix() == null) {
/* 152 */         team.setPrefix(nametag.getPrefix());
/* 153 */       } else if (!team.getPrefix().equals(nametag.getPrefix())) {
/* 154 */         team.setPrefix(nametag.getPrefix());
/*     */       } 
/*     */     }
/* 157 */     if (nametag.getSuffix() != null)
/* 158 */       if (team.getSuffix() == null) {
/* 159 */         team.setSuffix(nametag.getSuffix());
/* 160 */       } else if (!team.getSuffix().equals(nametag.getSuffix())) {
/* 161 */         team.setSuffix(nametag.getSuffix());
/*     */       }  
/*     */   }
/*     */   
/*     */   public void giveAll() {
/* 166 */     if (!this.init) {
/*     */       return;
/*     */     }
/* 169 */     Player toSet = this.player;
/* 170 */     Scoreboard board = toSet.getScoreboard();
/* 171 */     for (Nametag nametag : nametags) {
/* 172 */       if (!nametag.isOnline() || nametag.getName() == null) {
/*     */         continue;
/*     */       }
/* 175 */       updateFor(board, nametag);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setToAll() {
/* 180 */     if (!this.init) {
/*     */       return;
/*     */     }
/* 183 */     for (Player toSet : Bukkit.getOnlinePlayers())
/* 184 */       updateFor(toSet.getScoreboard(), this); 
/*     */   }
/*     */   
/*     */   public void heartsChanged() {
/* 188 */     if (!this.init || !this.hearts) {
/*     */       return;
/*     */     }
/* 191 */     this.suffix = String.valueOf(ConfigMessages.NAMETAG_SUFFIX.getValue(VaroPlayer.getPlayer(this.player)).replace("%hearts%", String.valueOf((int)VersionUtils.getHearts(this.player))).replace("%heart%", "♥"));
/* 192 */     setToAll();
/*     */   }
/*     */   
/*     */   public void refresh() {
/* 196 */     refreshPrefix();
/* 197 */     setToAll();
/* 198 */     giveAll();
/*     */   }
/*     */   
/*     */   public void remove() {
/* 202 */     nametags.remove(this);
/*     */   }
/*     */   
/*     */   public String getName() {
/* 206 */     return this.name;
/*     */   }
/*     */   
/*     */   public Player getPlayer() {
/* 210 */     return this.player;
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/* 214 */     return this.prefix;
/*     */   }
/*     */   
/*     */   public Rank getRank() {
/* 218 */     return this.rank;
/*     */   }
/*     */   
/*     */   public String getSuffix() {
/* 222 */     return this.suffix;
/*     */   }
/*     */   
/*     */   public UUID getUniqueId() {
/* 226 */     return this.uniqueID;
/*     */   }
/*     */   
/*     */   public boolean isOnline() {
/* 230 */     return (this.player != null);
/*     */   }
/*     */   
/*     */   public static void refreshAll() {
/* 234 */     for (Nametag nametag : nametags) {
/* 235 */       if (!nametag.isOnline()) {
/*     */         continue;
/*     */       }
/* 238 */       nametag.refresh();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void refreshGroups(Rank rank) {
/* 243 */     for (Nametag nametag : nametags) {
/* 244 */       if (!nametag.isOnline()) {
/*     */         continue;
/*     */       }
/* 247 */       if (!nametag.getRank().equals(rank)) {
/*     */         continue;
/*     */       }
/* 250 */       nametag.refresh();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void refreshUser(String user) {
/* 255 */     for (Nametag nametag : nametags) {
/* 256 */       if (!nametag.isOnline()) {
/*     */         continue;
/*     */       }
/* 259 */       if (!nametag.getPlayer().getName().equalsIgnoreCase(user)) {
/*     */         continue;
/*     */       }
/* 262 */       nametag.refresh();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void resendAll() {
/* 267 */     for (Nametag nametag : nametags) {
/* 268 */       if (!nametag.isOnline()) {
/*     */         continue;
/*     */       }
/* 271 */       nametag.setToAll();
/* 272 */       nametag.giveAll();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\clientadapter\nametag\Nametag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */