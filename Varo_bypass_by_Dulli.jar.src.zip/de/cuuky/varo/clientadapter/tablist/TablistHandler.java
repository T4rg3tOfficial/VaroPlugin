/*     */ package de.cuuky.varo.clientadapter.tablist;
/*     */ 
/*     */ import de.cuuky.varo.clientadapter.BoardHandler;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.utils.JavaUtils;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TablistHandler
/*     */   implements BoardHandler
/*     */ {
/*     */   private HashMap<Player, ArrayList<String>> headerReplaces;
/*     */   private ArrayList<String> headerLines;
/*     */   private HashMap<Player, ArrayList<String>> footerReplaces;
/*     */   private ArrayList<String> footerLines;
/*     */   
/*     */   public TablistHandler() {
/*  25 */     updateList();
/*     */   }
/*     */   
/*     */   private Object[] updateList(VaroPlayer player, boolean header) {
/*  29 */     ArrayList<String> tablistLines = header ? this.headerLines : this.footerLines, oldList = null;
/*     */     
/*  31 */     if (header) {
/*  32 */       oldList = this.headerReplaces.get(player.getPlayer());
/*  33 */       if (oldList == null)
/*  34 */         this.headerReplaces.put(player.getPlayer(), oldList = new ArrayList<>()); 
/*     */     } else {
/*  36 */       oldList = this.footerReplaces.get(player.getPlayer());
/*  37 */       if (oldList == null) {
/*  38 */         this.footerReplaces.put(player.getPlayer(), oldList = new ArrayList<>());
/*     */       }
/*     */     } 
/*  41 */     boolean changed = false;
/*  42 */     for (int index = 0; index < tablistLines.size(); index++) {
/*  43 */       String line = ConfigMessages.getValue(tablistLines.get(index), player);
/*     */       
/*  45 */       if (oldList.size() < tablistLines.size()) {
/*  46 */         oldList.add(line);
/*  47 */         changed = true;
/*  48 */       } else if (!((String)oldList.get(index)).equals(line)) {
/*  49 */         oldList.set(index, line);
/*  50 */         changed = true;
/*     */       } 
/*     */     } 
/*     */     
/*  54 */     return new Object[] { Boolean.valueOf(changed), oldList };
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateList() {
/*  59 */     this.headerReplaces = new HashMap<>();
/*  60 */     this.headerLines = new ArrayList<>();
/*     */     
/*  62 */     this.footerReplaces = new HashMap<>();
/*  63 */     this.footerLines = new ArrayList<>();
/*     */     
/*  65 */     File file = new File("plugins/Varo/config", "tablist.yml");
/*  66 */     YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
/*     */     
/*  68 */     ArrayList<String> header = new ArrayList<>();
/*  69 */     header.add(" ");
/*  70 */     header.add("%projectname%");
/*  71 */     header.add(" ");
/*     */     
/*  73 */     ArrayList<String> footer = new ArrayList<>();
/*  74 */     footer.add("&7------------------------");
/*  75 */     footer.add("&7Registriert: %colorcode%%players%");
/*  76 */     footer.add("&7Lebend: %colorcode%%remaining%");
/*  77 */     footer.add("&7Online: %colorcode%%online%");
/*  78 */     footer.add(" ");
/*  79 */     footer.add("&7Plugin by %colorcode%Cuuky");
/*  80 */     footer.add(" ");
/*  81 */     footer.add("%colorcode%%currDay%&7.%colorcode%%currMonth%&7.%colorcode%%currYear%");
/*  82 */     footer.add("%colorcode%%currHour%&7:%colorcode%%currMin%&7:%colorcode%%currSec%");
/*  83 */     footer.add(" ");
/*  84 */     footer.add("&7------------------------");
/*     */     
/*  86 */     if (!cfg.contains("header")) {
/*  87 */       cfg.set("header", header);
/*  88 */       cfg.set("footer", footer);
/*     */       
/*     */       try {
/*  91 */         cfg.save(file);
/*  92 */       } catch (IOException e) {
/*  93 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */     
/*  97 */     this.headerLines.addAll(cfg.getStringList("header"));
/*  98 */     this.footerLines.addAll(cfg.getStringList("footer"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updatePlayer(VaroPlayer player) {
/* 104 */     Object[] headerUpdate = updateList(player, true);
/* 105 */     Object[] footerUpdate = updateList(player, false);
/*     */     
/* 107 */     if (((Boolean)headerUpdate[0]).booleanValue() || ((Boolean)footerUpdate[0]).booleanValue())
/* 108 */       player.getNetworkManager().sendTablist(JavaUtils.getArgsToString((ArrayList)headerUpdate[1], "\n"), JavaUtils.getArgsToString((ArrayList)footerUpdate[1], "\n")); 
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\clientadapter\tablist\TablistHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */