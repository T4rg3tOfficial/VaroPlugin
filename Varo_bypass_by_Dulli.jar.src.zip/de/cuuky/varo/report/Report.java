/*     */ package de.cuuky.varo.report;
/*     */ 
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*     */ import de.cuuky.varo.utils.JavaUtils;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Report
/*     */   implements VaroSerializeable
/*     */ {
/*  15 */   private static ArrayList<Report> reports = new ArrayList<>();
/*     */   
/*     */   @VaroSerializeField(path = "id")
/*     */   private int id;
/*     */   
/*     */   @VaroSerializeField(path = "open")
/*     */   private boolean open;
/*     */   
/*     */   @VaroSerializeField(path = "reason")
/*     */   private ReportReason reason;
/*     */   
/*     */   @VaroSerializeField(path = "reportedId")
/*     */   private int reportedId;
/*     */   
/*     */   private VaroPlayer reporter;
/*     */   
/*     */   private VaroPlayer reported;
/*     */   @VaroSerializeField(path = "reporterId")
/*     */   private int reporterId;
/*     */   
/*     */   public Report() {
/*  36 */     reports.add(this);
/*     */   }
/*     */   
/*     */   public Report(VaroPlayer reporter, VaroPlayer reported, ReportReason reason) {
/*  40 */     this.reported = reported;
/*  41 */     this.reporter = reporter;
/*  42 */     this.reason = reason;
/*  43 */     this.open = true;
/*  44 */     this.id = generateId();
/*     */     
/*  46 */     reports.add(this);
/*     */   }
/*     */   
/*     */   private int generateId() {
/*  50 */     int id = JavaUtils.randomInt(1000, 9999999);
/*  51 */     while (getReport(id) != null) {
/*  52 */       generateId();
/*     */     }
/*  54 */     return id;
/*     */   }
/*     */   
/*     */   public void close() {
/*  58 */     this.open = false;
/*  59 */     reports.remove(this);
/*     */   }
/*     */   
/*     */   public int getId() {
/*  63 */     return this.id;
/*     */   }
/*     */   
/*     */   public ReportReason getReason() {
/*  67 */     return this.reason;
/*     */   }
/*     */   
/*     */   public VaroPlayer getReported() {
/*  71 */     return this.reported;
/*     */   }
/*     */   
/*     */   public VaroPlayer getReporter() {
/*  75 */     return this.reporter;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/*  79 */     return this.open;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {
/*  84 */     this.reported = VaroPlayer.getPlayer(this.reportedId);
/*  85 */     this.reporter = VaroPlayer.getPlayer(this.reporterId);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSerializeStart() {
/*  90 */     if (this.reporter != null)
/*  91 */       this.reporterId = this.reporter.getId(); 
/*  92 */     if (this.reported != null)
/*  93 */       this.reportedId = this.reported.getId(); 
/*     */   }
/*     */   
/*     */   public static Report getReport(int id) {
/*  97 */     for (Report r : reports) {
/*  98 */       if (r.getId() == id)
/*  99 */         return r; 
/*     */     } 
/* 101 */     return null;
/*     */   }
/*     */   
/*     */   public static ArrayList<Report> getReports() {
/* 105 */     return reports;
/*     */   }
/*     */ }


/* Location:              C:\Users\micha\Downloads\Varo_bypass_by_Dulli.jar!\de\cuuky\varo\report\Report.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */